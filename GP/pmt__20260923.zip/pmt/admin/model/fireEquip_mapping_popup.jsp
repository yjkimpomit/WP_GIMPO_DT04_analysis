<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%--<!-- 3d 모델의 소화기 연결 화면 -->--%>
<%-- 모델 정보 --%>
<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <c:choose>
            <c:when test="${empty adminModelVO.modelId}"><h1 class="page-content__heading">소화기 추가</h1></c:when>
            <c:otherwise><h1 class="page-content__heading">소화기 정보</h1></c:otherwise>
        </c:choose>

        <div class="result-panel" id="_FIREEQUIP_MAPPING_LIST">
            <%-- FIREEQUIP 리스트 --%>
        </div>
        
        <section class="content-section">
            <h2 class="page-content__subheading">모델 정보 <span>(아래의 정보를 복사하여 매핑정보에 붙여넣기를 하시면 됩니다.)</span></h2>
            <dl class="model-info">
                <div>
                    <dt>모델위치: </dt>
                    <dd>${adminModelVO.modelTarget}</dd>
                </div>
                <div>
                    <dt>좌표: </dt>
                    <dd>${adminModelVO.position}</dd>
                </div>
            </dl>
        </section>
    </div>
</main>

<script>
    /**
     * 연결 정보 조회
     */
    function fnPopSearchMappingList() {
        $.ajax({
            type: "POST",
            url: "/admin/model/modelMappingPopupList.do",
            data: {modelType: "fireequip", modelId: "${adminModelVO.modelId}"},
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_FIREEQUIP_MAPPING_LIST").html(data);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /* 연결 정보 수정 */
    function fnModifyMappingFireEquip() {
        var $targetInput = $("#fireequipListForm input");

        if ($targetInput.is(":disabled")) {
            $("#_TR").find('button:first').html('저장');
            $targetInput.prop('disabled', false);
            $targetInput.eq(0).focus();
        }
        else {
            $("#fireequipListForm #mode").val("U");

            var fireName = $("#fireequipListForm #fireName").val().trim();
            var modelTarget = $("#fireequipListForm #modelTarget").val().trim();
            var position = $("#fireequipListForm #position").val().trim();

            if(fireName === "" && modelTarget === "" && position === "") {
                title = "필수 입력";
                content = "1개 이상의 데이터를 입력하세요.";
                fnAlert();
                return false;
            }

            $.confirm({
                title: "정보 저장",
                content: "저장하시겠습니까?",
                type: 'blue',
                buttons: {
                    '확인': {
                        btnClass: 'btn-blue',
                        action: function () {
                            $.ajax({
                                type: "POST",
                                url: "/admin/model/saveModelMappingFireEquip.do",
                                data: $("#fireequipListForm").serialize(),
                                dataType: "json",
                                beforeSend: function () {
                                    $("#loadingBar").show();
                                },
                                success: function (data) {
                                    if (data.result === '1') {
                                        window.parent.isUpdate = true;

                                        window.parent._tagId = data.modelId;
                                        window.parent._tagName = $("#fireequipListForm #fireName").val();
                                        window.parent._tagType = "fireequip";
                                        window.parent.fnModelContentsResult(data.isModel);

                                        // 창닫기
                                        window.parent.$('.wb-close').trigger('click');

                                        title = "완료";
                                        content = "정상 처리되었습니다.";
                                        fnAlert();
                                    }
                                    else {
                                        title = "저장";
                                        content = "오류가 발생했습니다.";
                                        fnAlert();
                                    }
                                },
                                error: function (request, status, error) {
                                    title = "저장";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                },
                                complete: function () {
                                    $("#loadingBar").hide();
                                }
                            });
                        }
                    },
                    '취소': {
                        action: function () {
                        }
                    }
                }
            });
        }
    }

    /* 삭제 처리 */
    function fnRemoveMappingFireEquip() {
        $("#fireequipListForm #mode").val("D");

        $.confirm({
            title: "설비번호 삭제",
            content: "삭제하시겠습니까?",
            type: 'red',
            buttons: {
                '확인': {
                    btnClass: 'btn-red',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/model/saveModelMappingFireEquip.do",
                            data: $("#fireequipListForm").serialize(),
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result === '1') {
                                    window.parent.isUpdate = true;

                                    var fireequipId = $("#fireequipListForm #fireequipId").val();
                                    window.parent._tagId = fireequipId;
                                    window.parent._tagName = $("#fireequipListForm #fireName").val();
                                    window.parent._tagType = "fireequip";
                                    window.parent.fnModelContentsResult(data.isModel);

                                    fnPopSearchMappingList(fireequipId);
                                }
                                else {
                                    title = "삭제";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "삭제";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    $(function () {
        fnPopSearchMappingList();
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
