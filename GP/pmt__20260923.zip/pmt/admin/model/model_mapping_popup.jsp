<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%--<!-- 3d 모델의 설비번호 연결 화면 -->--%>
<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <%-- 모델 정보 --%>
        <div class="section-header">
            <h1 class="page-content__heading">모델위치 : <span>${data.modelTarget}</span> </h1>
            <div class="buttons">
                <button type="button" class="button button--secondary" onclick="window.parent.fnModelLoadFacility('${data.modelTarget}', '${data.modelId}')">해당모델 위치확인</button>
                <button type="button" class="button button--primary" onclick="fnViewModelInfo($(this))">수정</button>
            </div>
        </div>
        
        <%-- 모델 정보 --%>
        <div class="d-none" id="_MODEL_INFO">
            <form class="filter-panel" id="modelInfoForm" method="post" autocomplete="off">
                <div class="filter-panel__fields">
                    <div class="form-field">
                        <label class="form-label" for="modelId">모델 ID</label>
                        <div class="form-control-group">
                            <input class="form-control" type="text" id="modelId" name="modelId" value="${data.modelId}" readonly>
                            <input class="form-control" type="text" id="modelDescription" name="modelDescription" value="${data.modelDescription}">
                        </div>
                    </div>
                    <button type="button" class="button button--primary" onclick="fnModelModify()">수정</button>
                </div>
            </form>
        </div>
        
        <%--<!-- 검색영역 -->--%>
        <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
            <div class="filter-panel__fields">
                <div class="form-field">
                    <label class="form-label" for="iegNo">설비 검색</label>
                    <div class="form-control-group">
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호, 명 검색">
                        <input class="form-control" type="text" id="resultIegDescription" readonly="">
                        
                        <div class="buttons">
                            <button type="button" class="button button--secondary" onclick="fnViewDrawingPop()">P&ID</button>
                            <button type="button" class="button button--primary" onclick="fnAddMapping()">연결하기</button>
                        </div>
                    </div>
                    
                    <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                    <datalist class="_IEG_NO_LIST" id="iegNoList"></datalist>
                </div>
            </div>
        </form>
        
        <div class="result-panel" id="_MODEL_MAPPING_LIST">
            <%-- 연결한 설비 리스트 --%>
        </div>
        
    </div>
</main>

<form id="inputForm" method="post" autocomplete="off">
    <input type="hidden" id="inputIegNo" name="iegNo">
    <input type="hidden" id="inputTagNo" name="tagNo">
    <input type="hidden" id="mode" name="mode">
    <input type="hidden" id="modeTarget" name="modeTarget">
    <input type="hidden" id="inputModelId" name="modelId" value="${data.modelId}">
</form>

<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    function fnViewModelInfo(t) {
        var modelInfo = $("#_MODEL_INFO");

        if(modelInfo.is(":visible")) {
            $("#_MODEL_INFO").addClass('d-none');
            t.find('span').html('수정');
        }
        else {
            $("#_MODEL_INFO").removeClass('d-none');
            t.find('span').html('닫기');
        }
    }

    function fnModelModify() {
        $.confirm({
            title: "모델명 수정",
            content: "수정하시겠습니까?",
            type: 'blue',
            buttons: {
                '확인': {
                    btnClass: 'btn-blue',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/model/saveModelInfo.do",
                            data: $("#modelInfoForm").serialize(),
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result === '1') {
                                    window.parent.isUpdate = true;
                                } else {
                                    title = "모델명 수정";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "모델명 수정";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    /**
     * 연결된 설비 조회
     */
    function fnPopSearchMappingList() {
        $.ajax({
            type: "POST",
            url: "/admin/model/modelMappingPopupList.do",
            data: {modelId: "${data.modelId}", modelType: "facility"},
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_MODEL_MAPPING_LIST").html(data);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /* 설비정보 추가 */
    function fnAddMapping() {
        var iegNoVal = $("#iegNo").val().trim();
        var iegDesc = $("#resultIegDescription").val().trim();
        var equipListLen = $("._IEGNO").length;

        <%-- /* 설비번호 등록 확인 */ --%>
        if(equipListLen > 0) {
            title = "설비번호 확인";
            content = "이미 설비번호가 등록되어 있습니다.";
            fnAlert();

            isRun = false;
            return false;
        }

        if (iegDesc.length > 0) {
            var isRun = true;

            <%-- /* N개의 데이터 등록시 - 현재 1:1 관계 */
            $("._IEGNO").each(function (idx, el) {
                if ($(el).val() === iegNoVal) {
                    title = "설비번호 확인";
                    content = "이미 설비번호가 등록되어 있습니다.";
                    fnAlert();

                    isRun = false;
                    return false;
                }
            }); --%>

            if (isRun) {
                $("#inputForm #mode").val('U');
                $("#inputForm #inputIegNo").val(iegNoVal);

                $.confirm({
                    title: "설비번호 추가",
                    content: "저장하시겠습니까?",
                    type: 'blue',
                    buttons: {
                        '확인': {
                            btnClass: 'btn-blue',
                            action: function () {
                                $.ajax({
                                    type: "POST",
                                    url: "/admin/model/saveModelMapping.do",
                                    data: $("#inputForm").serialize(),
                                    dataType: "json",
                                    beforeSend: function () {
                                        $("#loadingBar").show();
                                    },
                                    success: function (data) {
                                        if (data.result === '1') {
                                            fnPopSearchMappingList();
                                            window.parent.isUpdate = true;
                                        } else {
                                            title = "저장";
                                            content = "오류가 발생했습니다.";
                                            fnAlert();
                                        }
                                    },
                                    error: function (request, status, error) {
                                        title = "저장";
                                        content = "오류가 발생했습니다.";
                                        fnAlert();
                                    },
                                    complete: function () {
                                        $("#loadingBar").hide();
                                    }
                                });
                            }
                        },
                        '취소': {
                            action: function () {
                            }
                        }
                    }
                });
            }
        } else {
            title = "입력";
            content = "설비번호를 검색하세요";
            fnAlert();
        }
    }

    /* 연결된 설비정보 수정 */
    function fnModifyMappingFacility(idx, target) {
        var title = "설비번호 저장";
        var targetNo = "#_" + target + "_NO_" + idx;
        var $targetInput = $(targetNo);

        if(target === "TAG") {
            title = "태그번호 저장";
        }

        if ($targetInput.is(":disabled")) {
            $("#_TR_" + target + "_" + idx).find('button:first').html('저장');
            $targetInput.prop('disabled', false);
            $targetInput.focus();
        } else {
            $("#inputForm #mode").val('U');
            $("#inputForm #inputIegNo").val($targetInput.val());
            $("#inputForm #inputTagNo").val($targetInput.val());
            $("#inputForm #modeTarget").val(target);

            $.confirm({
                title: title,
                content: "저장하시겠습니까?",
                type: 'blue',
                buttons: {
                    '확인': {
                        btnClass: 'btn-blue',
                        action: function () {
                            $.ajax({
                                type: "POST",
                                url: "/admin/model/saveModelMapping.do",
                                data: $("#inputForm").serialize(),
                                dataType: "json",
                                beforeSend: function () {
                                    $("#loadingBar").show();
                                },
                                success: function (data) {
                                    if (data.result === '1') {
                                        window.parent.isUpdate = true;
                                        fnPopSearchMappingList();
                                    } else {
                                        title = "저장";
                                        content = "오류가 발생했습니다.";
                                        fnAlert();
                                    }
                                },
                                error: function (request, status, error) {
                                    title = "저장";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                },
                                complete: function () {
                                    $("#loadingBar").hide();
                                }
                            });
                        }
                    },
                    '취소': {
                        action: function () {
                        }
                    }
                }
            });
        }
    }

    /* 삭제 처리 */
    function fnRemoveMappingFacility(idx, target) {
        var title = "설비번호 삭제";
        if(target === "TAG") {
            title = "태그번호 삭제";
        }

        $("#inputForm #modeTarget").val(target);

        $.confirm({
            title: title,
            content: "삭제하시겠습니까?",
            type: 'red',
            buttons: {
                '확인': {
                    btnClass: 'btn-red',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/model/removeModelMapping.do",
                            data: $("#inputForm").serialize(),
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result === '1') {
                                    window.parent.isUpdate = true;
                                    fnPopSearchMappingList();
                                } else {
                                    title = "삭제";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "삭제";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    /* p&id popup */
    function fnViewDrawingPop() {
        fnOpenPopupStandard("/admin/pnid/searchPnidInfo.do", "P&ID :: 설비 검색");
    }

    /**
     * 공통
     * js callback 처리 부분
     */
    function fnSearchResult() {
        //
    }

    $(function () {
        fnPopSearchMappingList();
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
