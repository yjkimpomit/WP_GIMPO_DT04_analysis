<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- 3d 모델의 QRCODE 연결 리스트 화면 -->--%>

<%--<div id="_QRCODE_MAPPING_LIST">--%>
<h3 class="page-content__subheading">매핑 정보</h3>
<form class="result-panel__fill" id="qrcodeListForm" name="qrcodeListForm" method="post" autocomplete="off">
    <input type="hidden" id="mode" name="mode">
    <input type="hidden" id="modelId" name="ilqQrcode" value="${data.modelId}">
    <input type="hidden" id="modelName" value="${data.qrcodeName}">

    <div class="table-responsive">
        <table class="data-table data-table--list" aria-label="모델-리스트">
            <thead>
            <tr>
                <th scope="col" data-field="모델위치">모델위치</th>
                <th scope="col" data-field="포지션">좌표 (x,y,z)</th>
                <th scope="col" data-field="연결">연결</th>
            </tr>
            </thead>
            <tbody>
            <%-- 데이터 --%>
            <tr id="_TR">
                <td data-field="모델위치" id="_LOC"><input type="text" class="form-control" id="modelTarget" name="modelTarget" value="${data.modelTarget}" maxlength="20" disabled/></td>
                <td data-field="포지션" id="_POSITION"><input type="text" class="form-control" id="position" name="position" value="${data.position}"  maxlength="30" disabled/></td>
                <td data-field="연결">
                    <div class="buttons">
                        <button type="button" class="button button--sm button--primary" onclick="fnModifyMappingQrcode();">설정</button>
                        <c:if test="${not empty data.position}">
                            <button type="button" class="button button--sm button--destructive" onclick="fnRemoveMappingQrcode();">삭제</button>
                        </c:if>
                    </div>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</form>
<%--</div>--%>
