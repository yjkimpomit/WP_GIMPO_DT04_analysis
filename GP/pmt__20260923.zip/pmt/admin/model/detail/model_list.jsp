<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 3d model 화면의 모델 리스트 --%>

<%--<h4 class="title03">3D 모델의 설비리스트</h4>--%>
<div class="result-header" id="info_list">
    <div class="result-header__title">
        <span class="result-header__count">총: <fmt:formatNumber value="${fn:length(list)}" type="number"/>개</span>
    </div>
    <div class="result-header__actions">
        <select id="selModelTarget" class="form-select" onchange="fnSearchModelTarget($(this))">
            <option value="">전체</option>
            <c:forEach var="target" items="${modelTargetList}">
                <option value="${target.modelTarget}">${target.modelTarget}</option>
            </c:forEach>
        </select>
        <select id="selType" name="searchCondition" class="form-select" onchange="fnSearchCondition($(this))">
            <option value="">전체</option>
            <option value="UM">미연결</option>
        </select>
    </div>
</div>

<form class="result-panel__fill" id="modelListForm" name="modelListForm" method="post" autocomplete="off">
    <input type="hidden" name="mode" value="U"/>
    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="모델-리스트">
            <thead>
            <tr>
                <th scope="col" data-field="연결">연결</th>
                <th scope="col" data-field="모델위치">모델위치</th>
                <th scope="col" data-field="설비명">설비명</th>
                <th scope="col" data-field="설비번호">설비번호</th>
            </tr>
            </thead>
            <tbody>
            <%-- 리스트 없을 경우 --%>
            <c:if test="${empty list}">
                <tr>
                    <td colspan="5">
                        <div class="no-data">
                            연결 정보가 없습니다.
                        </div>
                    </td>
                </tr>
            </c:if>

            <%-- 데이터 리스트 --%>
            <c:forEach var="data" items="${list}" varStatus="status">
                <c:set var="no" value="${fn:split(data.iegNo, '|')}"/>
                <c:set var="modelId" value="${data.modelId}"/>
                <c:set var="checkCnt" value=""/>

                <c:if test="${data.cnt > 1}"><c:set var="checkCnt" value="*"/></c:if>

                <c:choose>
                    <c:when test="${not empty data.iegNo}">
                        <c:set var="arrDesc" value="${fn:split(data.iegDescription, '|')}"/>
                        <c:set var="desc" value="${arrDesc[0]}"/>
                    </c:when>
                    <c:otherwise>
                        <c:set var="desc" value="${data.modelDescription}"/>
                    </c:otherwise>
                </c:choose>

                <tr id="_TR_${modelId}">
                    <td data-field="연결">
                        <input type="hidden" id="modelType" value="${data.modelTarget}"/>
                        <button type="button" class="button button--sm button--primary _BTN_SAVE" onclick="fnMappingPop('${modelId}','facility');">정보</button>
                        <%--<c:if test="${not empty data.iegNo}">
                            <button type="button" class="btn btn-xs btn-danger" id="_BTN_${modelId}" onclick="fnDisconnectMapping('${modelId}','facility');">
                                <span>삭제</span>
                            </button>
                        </c:if>--%>
                    </td>
                    <td data-field="모델위치">${checkCnt} <a href="javascript:fnModelLoadFacility('${data.modelTarget}','${data.modelId}')" title="위치확인">${data.modelTarget}</a></td>
                    <td data-field="설비명" id="_DESC_${modelId}">${desc}</td>
                    <td data-field="설비번호" id="_NO_${modelId}"><a href="javascript:fnModelLoadFacility('${data.modelTarget}','${data.modelId}')" title="위치확인">${no[0]}</a></td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</form>
<%--</div>--%>

<c:set var="paramIegNo" value="${adminModelVO.searchKeyword}"/>
<c:if test="${not empty paramIegNo}">
    <c:choose>
        <c:when test="${fn:length(no) > 1}">
            <c:forEach var="no" items="${no}" varStatus="status">
                <c:if test="${paramIegNo eq no}">
                    <c:set var="descView" value="${desc[status.index]}"/>
                </c:if>
            </c:forEach>
        </c:when>
        <c:otherwise>
            <c:set var="descView" value="${desc}"/>
        </c:otherwise>
    </c:choose>
</c:if>

<script>
    $(function () {
        <c:if test="${not empty descView}">
        $("#iegDescription").val("${descView}");
        </c:if>

        <c:if test="${not empty adminModelVO.modelTarget}">
        $("#selModelTarget").val('${adminModelVO.modelTarget}');
        </c:if>

        <c:if test="${not empty adminModelVO.searchCondition}">
        $("#selType").val('${adminModelVO.searchCondition}');
        </c:if>
    });
</script>
