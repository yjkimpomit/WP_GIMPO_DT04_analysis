<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- 3d 모델의 설비번호 연결 리스트 화면 -->--%>

<%--<div id="_MODEL_MAPPING_LIST">--%>
<%-- 연결한 설비 리스트 --%>
<form class="result-panel__fill" id="modelListForm" name="modelListForm" method="post" autocomplete="off">
    <input type="hidden" name="mode" value="U"/>
    <div class="table-responsive">
        <table class="data-table data-table--list" aria-label="모델-리스트">
            <thead>
            <tr>
                <th scope="col" data-field="설비번호">설비번호</th>
                <th scope="col" data-field="설비명">설비명</th>
                <th scope="col" data-field="연결">연결</th>
            </tr>
            </thead>
            <tbody>
            <%-- 리스트 없을 경우 --%>
            <c:if test="${empty list}">
                <tr>
                    <td colspan="3">정보가 없습니다.</td>
                </tr>
            </c:if>

            <%-- 데이터 리스트 --%>
            <c:forEach var="data" items="${list}" varStatus="status">
                <c:set var="idx" value="${data.modelId}"/>

                <tr id="_TR_FAC_${idx}">
                    <td data-field="설비번호"><input type="text" class="form-control _IEGNO" id="_FAC_NO_${idx}" value="${data.iegNo}" disabled/></td>
                    <td data-field="설비명" id="_DESC_${idx}">${data.iegDescription}</td>
                    <td data-field="연결">
                        <div class="buttons">
                            <button type="button" class="button button--sm button--primary" onclick="fnModifyMappingFacility('${idx}','FAC');">수정</button>
                            <button type="button" class="button button--sm button--destructive" onclick="fnRemoveMappingFacility('${idx}','FAC');">삭제</button>
                        </div>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>

    <%-- 태그 데이터 --%>
    <c:if test="${fn:contains(adminModelVO.modelId, 'ControlBD')}">
        <div class="table-responsive">
            <table class="data-table data-table--list" aria-label="모델태그정보">
                <thead>
                <tr>
                    <th scope="col" data-field="태그번호">태그번호</th>
                    <th scope="col" data-field="태그명">태그명</th>
                    <th scope="col" data-field="연결">연결</th>
                </tr>
                </thead>
                <tbody>
                    <c:set var="idx" value="${adminModelVO.modelId}"/>

                    <tr id="_TR_TAG_${idx}">
                        <td data-field="태그번호"><input type="text" class="form-control _TAGNO" id="_TAG_NO_${idx}" value="${tagData.tagNo}" disabled/></td>
                        <td data-field="태그명" id="_TAG_DESC_${idx}">${tagData.tagDescription}</td>
                        <td data-field="연결">
                            <button type="button" class="button button--sm button--primary" onclick="fnModifyMappingFacility('${idx}', 'TAG');">수정</button>
                            <c:if test="${not empty tagData.tagNo}">
                                <button type="button" class="button button--sm button--destructive" onclick="fnRemoveMappingFacility('${idx}', 'TAG');">삭제</button>
                            </c:if>
                            <c:if test="${empty tagData.tagNo}">
                                <script>
                                    fnModifyMappingFacility('${idx}', 'TAG');
                                </script>
                            </c:if>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </c:if>

</form>
<%--</div>--%>

