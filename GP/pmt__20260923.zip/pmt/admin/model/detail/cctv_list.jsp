<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 3d model 화면의 CCTV 리스트 --%>

<%--<h4 class="title03">3D 모델의 CCTV리스트</h4>--%>
<div class="result-header" id="info_list">
    <div class="result-header__title">
        <span class="result-header__count">총: <fmt:formatNumber value="${fn:length(list)}" type="number"/>개</span>
    </div>
    <div class="result-header__actions">
        <select id="selType" name="searchCondition" class="form-select" onchange="fnSearchContentsCondition($(this))">
            <option value="">전체</option>
            <option value="UM">미연결</option>
        </select>
    </div>
</div>

<form class="result-panel__fill" id="cctvListForm" name="cctvListForm" method="post" autocomplete="off">
    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="CCTV-리스트">
            <thead>
            <tr>
                <th scope="col" data-field="연결">연결</th>
                <th scope="col" data-field="모델위치">모델위치</th>
                <th scope="col" data-field="모델명">모델명</th>
            </tr>
            </thead>
            <tbody>
            <%-- 리스트 없을 경우 --%>
            <c:if test="${empty list}">
                <tr>
                    <td colspan="5">
                        <div class="no-data">
                            연결 정보가 없습니다.
                        </div>
                    </td>
                </tr>
            </c:if>

            <%-- 데이터 리스트 --%>
            <c:forEach var="data" items="${list}" varStatus="status">
                <c:set var="idx" value="${status.count}"/>
                <c:set var="modelId" value="${data.modelId}"/>
                <c:set var="modelName" value="${data.cctvName}"/>

                <tr id="_TR_${idx}">
                    <td data-field="연결">
                        <input type="hidden" id="modelType" value="${data.modelTarget}"/>
                        <button type="button" class="button button--sm button--primary _BTN_SAVE" onclick="fnMappingLocPop('${modelId}','cctv','','');">
                            <span>정보</span>
                        </button>
                    </td>
                    <td data-field="모델위치"><a href="javascript:fnModelLoadCctv('${data.modelTarget}','${modelId}')">${data.modelTarget}</a></td>
                    <td data-field="모델명" class="data-table__cell--start" id="_DESC_${idx}">${modelName}</td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</form>
<%--</div>--%>

<script>
    $(function () {
        <c:if test="${not empty adminModelVO.searchCondition}">
        $("#selType").val('${adminModelVO.searchCondition}');
        </c:if>
    });
</script>
