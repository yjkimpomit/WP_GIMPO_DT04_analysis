<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 3d model 화면 -->
<div class="winbox-layout page-content document-viewer-page">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">3D 모델</h1>
    
        <!-- 검색영역 -->
        <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
            <input type="hidden" name="mode" id="mode">
            <input type="hidden" name="searchCondition" id="searchCondition">
            <input type="hidden" name="modelTarget" id="modelTarget" value="TBBD9_1F">
            <input type="hidden" name="modelId" id="modelId">
            <div class="filter-panel__fields">
                <div class="form-field">
                    <label class="form-label" for="iegNo">설비 번호</label>
                    <div class="form-control-group">
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="검색어 입력 후 엔터">
                        <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly="">
                    </div>

                    <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                    <datalist id="iegNoList"></datalist>
                </div>
            </div>
        </form>
    
        <div class="splitview has-model-viewer">
            <%-- 3djs model --%>
            <script defer src="${pageContext.request.contextPath}/resources/admin/js/unity/unityUtil.js"></script>
            <script defer src="${pageContext.request.contextPath}/resources/admin/js/unity/webUtil.js"></script>
    
            <div class="splitview__pane splitview__pane--content">
                <div class="document-viewer">
                    <iframe src="${pageContext.request.contextPath}/3djs/index.html" width="100%" height="100%"></iframe>
                </div>
            </div>
    
            <div class="splitview__pane splitview__pane--sidebar">
                <div class="result-header">
                    <h2 class="result-header__title">모델</h2>
                    <div class="result-header__actions">
                        <label class="form-label" for="selWorkModel">종류 선택</label>
                        <select id="selWorkModel" class="form-select" onchange="fnSelectWorkModel($(this))">
                            <option value="model">설비</option>
                            <option value="cctv">CCTV</option>
                            <option value="qrcode">QRCode</option>
                            <option value="fireequip">소화기</option>
                            <option value="elecpanel">전기차단기판넬</option>
                        </select>
                        
                        <%-- 개발: label 의 for 값을 input의 id와 같게 맞춰주세요. --%>
                        <%--<label class="visually-hidden" for="sampleId">검색어 입력</label>
                        <input type="text" id="sampleId" class="form-control w-auto">--%>
                    </div>
                </div>
    
                <div class="result-panel" id="_LIST">
                    <%-- 모델리스트 정보 --%>
                </div>
            </div>
            
        </div>
    </div>
</div>

<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    /* 리스트 업데이트 조건 */
    var isUpdate = false;
    var isModelView = false;

    /* 리스트 */
    function fnModelMappingList() {
        $.ajax({
            type: "POST",
            url: "/admin/model/modelList.do",
            data: $("#searchForm").serialize(),
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_LIST").html(data);
                $("._DIV_BTN_AREA").removeClass("d-none");
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /* 작업 모델 선택 */
    function fnSelectWorkModel(t) {
        fnSearchReset();

        /* 열려있는 창 모두 닫기 */
        $('.wb-close').trigger('click');

        var workModel = t.val();
        $("#searchForm #mode").val(workModel);

        if(t.val() === 'model') {
            $("#searchForm #modelTarget").val('TBBD9_1F');
        }

        fnModelMappingList();
    }

    /* 모델로 이동 */
    function fnModelView() {
        var modelType = $("#modelType").val();
        var iegNo = $("#iegNo").val().trim();

        if (iegNo !== '') {
            isModelView = true;
            modelLoadToUnity(modelType, iegNo);
        }

        isModelView = false;
    }

    /* 모델로 이동 */
    function fnModelLoadFacility(modelType, iegNo) {
        isModelView = true;
        modelLoadToUnity(modelType, iegNo);
        isModelView = false;
    }

    /* cctv 이동 */
    function fnModelLoadCctv(modelTarget, cctvId) {
        isModelView = true;
        cctvToUnity(modelTarget, cctvId);
        isModelView = false;
    }

    /* qrcode 이동 */
    function fnModelLoadQrcode(modelTarget, tagId) {
        isModelView = true;
        qrcodeToUnity(modelTarget, tagId);
        isModelView = false;
    }

    /* 소화기 이동 */
    function fnModelLoadFireEquip(modelTarget, tagId) {
        isModelView = true;
        fireEquipToUnity(modelTarget, tagId);
        isModelView = false;
    }

    /**
     * 공통: 설비번호 검색
     * js callback 처리 부분
     */
    function fnSearchResult() {
        if (isFacilityNo) {
            $("#searchForm #searchCondition").val('');
            $("#searchForm #modelId").val('');
            fnModelView();
        }
        fnModelMappingList();
    }

    /* 검색 조건 초기화 */
    function fnSearchReset() {
        $('#searchForm input').val('');
        $('#iegNoList').empty();
    }

    /* 전체 검색 */
    function fnModelAllList() {
        fnSearchReset();
        fnModelMappingList();
    }

    /* 모델타켓 검색 */
    function fnSearchModelTarget(t) {
        fnSearchReset();

        var modelTarget = $("#selModelTarget option:selected").val();
        $("#searchForm #modelTarget").val(modelTarget);

        fnModelMappingList();
    }

    /* 연결여부 검색 */
    function fnSearchCondition(t) {
        fnSearchReset();

        var modelTarget = $("#selModelTarget option:selected").val();
        var tVal = t.val();

        $("#searchForm #modelTarget").val(modelTarget);
        $("#searchCondition").val(tVal);

        fnModelMappingList();
    }

    /* cctv, qrcode, fireequip 연결여부 검색 */
    function fnSearchContentsCondition(t) {
        fnSearchReset();

        var workModel = $("#selWorkModel option:selected").val();
        var tVal = t.val();

        $("#searchForm #mode").val(workModel);
        $("#searchCondition").val(tVal);

        fnModelMappingList();
    }

    /* callback unity js */
    function fnViewMappingData(modelId) {
        fnSearchReset();

        $("#selModelTarget").val('');

        $("#modelId").val(modelId);
        fnModelMappingList();
    }

    /* 설비번호 연결 팝업 */
    function fnMappingPop(modelId, modelType) {
        var url;
        var title = "설비번호 연결";

        url = "/admin/model/modelMappingPopup.do?modelType=" + modelType + "&modelId=" + modelId;

        var box = new WinBox(title, {
            url: url,
            width: "760px",
            height: "640px",
            class: ["app-winbox"],
            position: "center",
            onresize: function (w, h) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
                if (isUpdate) {
                    fnModelMappingList();
                    isUpdate = false;
                }
            }
        });

        /* 브라우저를 조절할때 처리 */
        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    /* 모델 위치 연결 팝업 */
    function fnMappingLocPop(modelId, modelType, modelTarget, position) {
        var url;
        var title;

        if (modelType === 'cctv') {
            title = "CCTV 연결";
        } else if (modelType === 'qrcode') {
            title = "QRCode 연결";
        } else if (modelType === 'fireequip') {
            title = "소화기 연결";
        } else if (modelType === 'elecpanel') {
            title = "전기차단기판넬 연결";
        }

        url = "/admin/model/modelMappingPopup.do?modelType=" + modelType + "&modelId=" + modelId + "&modelTarget=" + modelTarget + "&position=" + position;

        var box = new WinBox(title, {
            url: url,
            width: "760px",
            height: "480px",
			class: ["app-winbox"],
            position: "center",
            onresize: function (w, h) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
                if (isUpdate) {
                    fnModelMappingList();
                    isUpdate = false;
                }
            }
        });

        /* 브라우저를 조절할때 처리 */
        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    /* 삭제 처리 */
    function fnDisconnectMapping(modelId, modelType) {
        $.confirm({
            title: "설비번호 삭제",
            content: "삭제하시겠습니까?",
            type: 'blue',
            buttons: {
                '확인': {
                    btnClass: 'btn-blue',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/model/removeModelMapping.do",
                            data: {modelId: modelId},
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result === '1') {
                                    $("#_DESC_" + modelId).html('');
                                    $("#_NO_" + modelId).html('');
                                    $("#_INPUT_IEGNO_" + modelId).val('');
                                    $("#_BTN_" + modelId).remove();

                                    title = "삭제 완료";
                                    content = "정상적으로 처리되었습니다.";
                                    fnAlert();
                                } else {
                                    title = "삭제";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "삭제";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    $(function () {
        var iegNo = $("#iegNo").val();

        if (iegNo !== '') {
            isModelView = true;
        }

        fnModelMappingList();
    });
</script>
