<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%--<!-- 3d 모델의 QRCODE 연결 화면 -->--%>
<%-- 모델 정보 --%>
<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <div class="section-header">
            <h1 class="page-content__heading">QRCODE 정보</h1>
            
            <div class="form-field">
                <label class="form-label" for="selQrcodeId">공간선택</label>
                <select id="selQrcodeId" class="form-select">
                    <c:forEach var="data" items="${list}" varStatus="status">
                        <option value="${data.modelId}">${data.qrcodeName}</option>
                    </c:forEach>
                </select>
            </div>
        </div>
    
        <div class="result-panel" id="_QRCODE_MAPPING_LIST">
            <%-- QRCODE 리스트 --%>
        </div>
    
        <section class="content-section">
            <h2 class="page-content__subheading">모델 정보 <span>(아래의 정보를 복사하여 매핑정보에 붙여넣기를 하시면 됩니다.)</span></h2>
            <dl class="model-info">
                <div>
                    <dt>모델위치: </dt>
                    <dd>${adminModelVO.modelTarget}</dd>
                </div>
                <div>
                    <dt>좌표: </dt>
                    <dd>${adminModelVO.position}</dd>
                </div>
            </dl>
        </section>
    </div>
</main>
<script>
    /**
     * 연결 정보 조회
     */
    function fnPopSearchMappingList(qrcodeId) {
        $.ajax({
            type: "POST",
            url: "/admin/model/modelMappingPopupList.do",
            data: {modelType: "qrcode", modelId: qrcodeId},
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_QRCODE_MAPPING_LIST").html(data);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /* 연결 정보 수정 */
    function fnModifyMappingQrcode() {
        var $targetInput = $("#qrcodeListForm input");

        if ($targetInput.is(":disabled")) {
            $("#_TR").find('button:first').html('저장');
            $targetInput.prop('disabled', false);
            $targetInput.eq(0).focus();
        } else {
            $("#qrcodeListForm #mode").val("U");

            $.confirm({
                title: "정보 저장",
                content: "저장하시겠습니까?",
                type: 'blue',
                buttons: {
                    '확인': {
                        btnClass: 'btn-blue',
                        action: function () {
                            $.ajax({
                                type: "POST",
                                url: "/admin/model/saveModelMappingQrcode.do",
                                data: $("#qrcodeListForm").serialize(),
                                dataType: "json",
                                beforeSend: function () {
                                    $("#loadingBar").show();
                                },
                                success: function (data) {
                                    if (data.result === '1') {
                                        window.parent.isUpdate = true;

                                        window.parent._tagId = $("#qrcodeListForm #modelId").val();
                                        window.parent._tagName = $("#qrcodeListForm #modelName").val();
                                        window.parent._tagType = "qrcode";
                                        window.parent.fnModelContentsResult(data.isModel);

                                        title = "완료";
                                        content = "정상 처리되었습니다.";
                                        fnAlert();
                                    } else {
                                        title = "저장";
                                        content = "오류가 발생했습니다.";
                                        fnAlert();
                                    }
                                },
                                error: function (request, status, error) {
                                    title = "저장";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                },
                                complete: function () {
                                    $("#loadingBar").hide();
                                }
                            });
                        }
                    },
                    '취소': {
                        action: function () {
                        }
                    }
                }
            });
        }
    }

    /* 삭제 처리 */
    function fnRemoveMappingQrcode() {
        $("#qrcodeListForm #mode").val("D");

        $.confirm({
            title: "설비번호 삭제",
            content: "삭제하시겠습니까?",
            type: 'red',
            buttons: {
                '확인': {
                    btnClass: 'btn-red',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/model/saveModelMappingQrcode.do",
                            data: $("#qrcodeListForm").serialize(),
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result === '1') {
                                    window.parent.isUpdate = true;

                                    var qrcodeId = $("#qrcodeListForm #modelId").val();
                                    window.parent._tagId = qrcodeId;
                                    window.parent._tagName = $("#qrcodeListForm #modelName").val();
                                    window.parent._tagType = "qrcode";
                                    window.parent.fnModelContentsResult(data.isModel);

                                    fnPopSearchMappingList(qrcodeId);
                                } else {
                                    title = "삭제";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "삭제";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    $(function () {
        $("#selQrcodeId").on("change", function () {
            var qrcodeId = $(this).val();
            fnPopSearchMappingList(qrcodeId);
        });

        <c:if test="${not empty adminModelVO.modelId}">
            $("#selQrcodeId").val('${adminModelVO.modelId}');
        </c:if>

        $("#selQrcodeId").trigger("change");
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
