<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">P&amp;ID 정보등록</h1>
        <div class="table-responsive">
            <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="pnid-정보등록">
                <colgroup>
                    <col style="width: 128px;">
                    <col>
                </colgroup>
                <tbody>
                <tr>
                    <th scope="row">호기</th>
                    <td data-field="호기">
                        <label class="visually-hidden" for="hoki">호기선택</label>
                        <select class="form-select" id="hoki" name="hoki">
                            <option value="" selected>호기선택</option>
                            <option value="51909">9호기</option>
                            <option value="51910">10호기</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Tag Text</th>
                    <td data-field="Tag Text">
                        <label class="visually-hidden" for="pnidTextValue">Tag Text 입력</label>
                        <input type="text" class="form-control" id="pnidTextValue" name="pnidTextValue" placeholder="Tag Text를 입력하세요" required/>
                    </td>
                </tr>
                <tr>
                    <th scope="row">설비번호</th>
                    <td data-field="설비번호">
                        <form id="searchForm" method="post" autocomplete="off">
                            <div class="row g-2" aria-labelledby="facilityNo">
                                <div class="col">
                                    <label class="visually-hidden" for="iegNo">설비번호 입력 후 엔터</label>
                                    <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호 입력 후 엔터">
                                </div>
                                <!-- 설비정보가 2개 이상인 경우 보여줌 -->
                                <datalist class="_IEG_NO_LIST" id="iegNoList"></datalist>
                            </div>
                        </form>
                    </td>
                </tr>
                <tr>
                    <th scope="row">설비명</th>
                    <td data-field="설비명">
                        <label class="visually-hidden" for="iegDescription">설비명</label>
                        <input class="form-control" id="iegDescription" readonly>
                    </td>
                </tr>
                <tr>
                    <th scope="row">Tag No</th>
                    <td data-field="Tag No">
                        <label class="visually-hidden" for="iegTagNo">Tag No</label>
                        <input class="form-control" id="iegTagNo" readonly>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="popup-footer">
        <button type="button" id="insBtn" class="btn btn-primary" onclick="fnInsIegNo()">
            등록
        </button>
        <input type="hidden" value="${detailInfo.pnidDescription}" id="pnidDescription">
        <input type="hidden" value="${detailInfo.pnidNo}" id="pnidNo">
        <input type="hidden" value="${detailInfo.pnidSvgFileName}" id="pnidSvgFileName">
        <input type="hidden" id="dataPath" value="${not empty param.svgPath ? fn:escapeXml(param.svgPath) : fn:escapeXml(param.data)}">
        <input type="hidden" id="targetTransform" value="${fn:escapeXml(param.targetTransform)}">
    </div>
</main>

<%-- 설비검색 공통 --%>
<script src="${pageContext.request.contextPath}/resources/admin/js/pnid/custom-pnid-search.js"></script>
<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    $(document).ready(function () {
        $("#iegNo").on("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                fnSearchFacilityList();
            }
        });
    });

    /**
     * 공통
     * js callback 처리 부분
     */
    function fnSearchResult(tagNo) {
        $("[id=iegTagNo]").val(tagNo);
    }

    function fnInsIegNo() {
        var hoki = $("#hoki").val();
        var pnidTextValue = $("input[name='pnidTextValue']").val().trim();
        var iegNo = $("#iegNo").val().trim();
        var iegDescription = $("#iegDescription").val().trim();
        var pnidDescription = $("#pnidDescription").val();
        var pnidNo = $("#pnidNo").val();
        var pnidSvgFileName = $("#pnidSvgFileName").val();
        var pnidTagNo = $("#iegTagNo").val();

        // 호기 선택 체크
        if (hoki === "") {
            alert("호기를 선택하세요.");
            $("#hoki").focus();
            return;
        }

        // Tag Text 체크
        if (pnidTextValue === "") {
            alert("Tag Text를 입력하세요.");
            $("input[name='pnidTextValue']").focus();
            return;
        }

        // 설비번호 체크
        if (iegNo === "") {
            alert("설비번호를 입력하세요.");
            $("#iegNo").focus();
            return;
        }
        $("#loadingBar").show();

        $.ajax({
            type: "POST",
            url: "/admin/pnid/insPnidInfo.do",
            data: {
                hoki: hoki,
                pnidTextValue: pnidTextValue,
                iegNo: iegNo,
                iegDescription: iegDescription,
                pnidDescription: pnidDescription,
                pnidNo: pnidNo,
                pnidSvgFileName: pnidSvgFileName,
                pnidTagNo: pnidTagNo
            },
            dataType: "json",
            success: function (data) {
                if (data.result == "1") {
                    fnInsertSvgGId(pnidTagNo);
                } else if (data.result == "2") {
                    fnInsertSvgGId(pnidTagNo);
                } else {
                    $("#loadingBar").hide();
                    alert("등록에 실패했습니다.");
                }
            },
            error: function () {
                $("#loadingBar").hide();
                alert("등록 중 오류가 발생했습니다.");
            }
        });
    }

    function fnInsertSvgGId(pnidTagNo) {
        var dataPath = $("#dataPath").val().split("?")[0];
        var targetTransform = $("#targetTransform").val();

        if (!pnidTagNo) {
            $("#loadingBar").hide();
            alert("등록할 g id를 입력하세요.");
            return;
        }

        if (!dataPath) {
            $("#loadingBar").hide();
            alert("SVG 경로(dataPath)가 없습니다.");
            return;
        }

        if (!targetTransform) {
            $("#loadingBar").hide();
            alert("클릭한 텍스트의 transform 값이 없습니다.");
            return;
        }

        $.ajax({
            type: "POST",
            url: "/admin/pnid/updateSvgTagId.do",
            data: {
                dataPath: dataPath,
                targetTransform: targetTransform,
                newTagId: pnidTagNo
            },
            dataType: "json",
            success: function (data) {
                console.log("updateSvgTagId result:", data);

                if (data.result === "success") {
                    try {
                        var iframeEl = window.parent.$("#_VIEW_IFRAME")[0];
                        var viewerWin = iframeEl.contentWindow;

                        if (viewerWin && typeof viewerWin.createAndLoadSVG === "function") {
                            var reloadUrl = dataPath + (dataPath.indexOf("?") > -1 ? "&" : "?") + "_ts=" + Date.now();

                            setTimeout(function () {
                                viewerWin.createAndLoadSVG(reloadUrl, pnidTagNo);
                                $("#loadingBar").hide();
                                alert("등록에 성공했습니다 ");
                                window.parent._pnidWinbox?.close();
                            }, 8000);

                        }
                    } catch (e) {
                        $("#loadingBar").hide();
                        console.error("도면 새로고침 중 오류:", e);
                    }
                } else {
                    $("#loadingBar").hide();
                    alert("등록에 실패했습니다.");
                }
            },
            error: function (xhr, status, err) {
                console.error("updateSvgTagId ajax error:", status, err);
                $("#loadingBar").hide();
                alert("요청 중 오류가 발생했습니다.");
            }
        });
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>