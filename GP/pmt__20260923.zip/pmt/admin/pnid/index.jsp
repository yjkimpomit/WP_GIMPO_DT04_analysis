<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>
<%--<c:import url="/admin/common/header.do" />--%>
<!-- P&ID 화면 -->
<div class="winbox-layout page-content document-viewer-page">
	<div class="page-content__placeholder">
		<h1 class="page-content__heading visually-hidden">P&ID</h1>
	
		<!-- 검색영역 -->
		<form class="filter-panel" id="searchForm" method="post" autocomplete="off" aria-label="설비-태그-검색">
			<input type="hidden" name="searchCondition" id="searchCondition">
			<div class="filter-panel__fields">
				<div class="form-field">
					<label class="form-label" for="iegNo">설비, P&ID 검색</label>
					<div class="form-control-group">
						<input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="">
						<input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly aria-label="선택된 설비명">
						<div class="buttons">
							<button type="button" class="button button--secondary" id="btnList" onclick="toggleDocuList()" disabled>목록보기</button>
							<button type="button" class="button button--accent-mint" id="btnEdit" onclick="fnEditPageAdmin(editorUrl)" disabled>수정하기</button>
							<button type="button" class="button button--accent-teal" id="btnBack" onclick="fnViewPageAdmin(url)" style="display:none">돌아가기</button>
						</div>
					</div>
					<%-- 설비정보가 2개 이상인 경우 보여줌 --%>
					<datalist id="iegNoList"></datalist>
				</div>
			</div>
		</form>
		
		<div class="document-viewer">
			<iframe class="pnid-iframe" id="_VIEW_IFRAME" src=""></iframe>
			<iframe class="pnid-iframe" id="_EDIT_IFRAME" src="" style="display:none"></iframe>
		</div>
		<!-- 연계문서 -->
		<div class="doc-box active d-none" id="_DOC_VIEW">
			<div class="doc-header">
				<strong>연계문서</strong>
				<span class="icon icon-close" title="닫기" onclick="toggleDocuList();"></span>
			</div>
			<div class="linked-data" id="_DOC_LIST">
				<%-- 문서 리스트 --%>
			</div>
		</div>
		
		<div class="winbox-layout page-content page-content--popup" id="editorGuidePopup" tabindex="-1" hidden>
			<div class="page-content__placeholder">
				<div class="section-header">
					<h2 class="page-content__subheading">P&ID 에디터 사용 가이드</h2>
					<button type="button" class="btn close">닫기</button>
				</div>
			
				<div class="pid-manual">
					<ul>
						<li>
							<strong>카메라 이동</strong>
							<ul>
								<li>마우스를 드래그하여 시점을 이동할 수 있습니다.</li>
								<li>마우스 휠을 굴려 확대/축소 할 수 있습니다.</li>
							</ul>
						</li>
						<li>
							<strong>개체 선택</strong>
							<ul>
								<li>개체를 클릭하여 선택할 수 있습니다.</li>
								<li>Shift 키를 누른 채로 개체를 클릭하여 다중 선택할 수 있습니다.</li>
								<li>우클릭한 채로 드래그하여 범위 내 여러 개체를 한 번에 선택할 수 있습니다.</li>
							</ul>
						</li>
						<li>
							<strong>개체 편집 (개체 선택 상태에서만 사용 가능)</strong>
							<ul>
								<li>선택된 개체 위에 커서를 놓고 드래그하여 개체를 이동시킬 수 있습니다.</li>
								<li>키보드 방향키를 눌러 선택된 개체를 이동시킬 수 있습니다.</li>
								<li>R키를 누르거나 '회전' 버튼을 클릭하여 개체를 회전시킬 수 있습니다.</li>
								<li>Delete키 또는 Backspace 키를 누르거나 '삭제' 버튼을 클릭하여 개체를 삭제할 수 있습니다.</li>
								<li>Ctrl+z, Ctrl+y 키를 누르거나 버튼을 클릭하여 실행취소/복구할 수 있습니다.</li>
								<li>텍스트 편집 버튼을 클릭하여 개체의 텍스트를 편집할 수 있습니다.</li>
								<li>'뒤로', '앞으로' 버튼을 클릭하여 개체 순서를 뒤로 보내거나 앞으로 가져올 수 있습니다.</li>
							</ul>
						</li>
						<li>
							<strong>저장</strong>
							<ul>
								<li>'로컬 저장' 버튼을 클릭하여 편집된 SVG 파일을 다운로드할 수 있습니다.</li>
								<li>'서버 저장' 버튼을 클릭하여 편집한 도면을 서버로 반영할 수 있습니다.</li>
							</ul>
						</li>
					</ul>
				</div>
			</div>
			
		</div>
		
	</div>
</div>

<script>
	/* pnid 팝업화면 전역 선언 */
	window._pnidWinbox = null;

    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    function toggleDocuList() {
        $("#_DOC_VIEW").toggleClass("d-none");
        $("#_DOC_VIEW").toggleClass("active");
    }
    
    function showEditorGuide() {
    	
    	$("#editorGuidePopup").bPopup({
            modalClose: false,
            position: [0, 0],
            opacity: .4,
            speed: 450,
            closeClass: "close",
            onOpen: function () {
                $(this).addClass('show');
            },
            onClose: function () {
                // 모달이 닫힐 때 초기화 작업 수행
                $("#trendModal .modal-content").empty();

                // 모달이 닫힐 때 추가된 클래스 제거
                $(this).removeClass('show');
            }
        });
    }

    // 뷰어 로드
    function fnViewPageAdmin(url, t) {
        /*if (!isFacilityNo) {
            $("#iegDescription").val($(t).data("desc"));
        }*/
        
        $("#_VIEW_IFRAME").show();
        $("#_EDIT_IFRAME").hide();
        $("#_VIEW_IFRAME").attr("src", url);
        $("#btnEdit").show();
        $("#btnBack").hide();

        fnSetEditorAttr(url)
    }
    
    // 에디터 설정
    function fnSetEditorAttr(url) {
        var editorUrl = url.replace("viewer", "editor");
        
        $("#btnEdit").attr({
        	"disabled": false,
        	"data-url": editorUrl,
        	"onclick": "fnEditPageAdmin('" + editorUrl + "')"
        });
        $("#btnBack").attr({
        	"data-url": url,
        	"onclick": "fnViewPageAdmin('" + url + "')"
        });
    }
    
    // 에디터 로드
    function fnEditPageAdmin(url, t) {        
    	$("#_VIEW_IFRAME").hide();
    	$("#_EDIT_IFRAME").show();
    	$("#_EDIT_IFRAME").attr("src", url);
    	$("#btnEdit").hide();
    	$("#btnBack").show();
    	
    	showEditorGuide();
    }

    // 문서 목록 렌더링
    function renderPnidDocList(list) {
        const html = [];

        $.each(list, function (i, item) {
            var text = (item && item.text) || "";

            const viewerUrl = "${pageContext.request.contextPath}/admin/pnid/viewer.do"
                + "?dataPath=" + encodeURIComponent(item.data || "")
                + "&searchTag=" + encodeURIComponent(item.tagNo || "");

            html.push(
                '<div class="doc-link" onclick="fnViewPageAdmin(\'' + viewerUrl + '\', this); toggleDocuList();" data-desc="[' + item.iegNo + '] ' + text + '">' +
                '<span>' + (item.fileName || '') + ' [' + item.iegNo + ']</span> ' +
                '<span>' + text + '</span>' +
                '</div>'
            );
        });

        $("#_DOC_LIST").html(html.join(""));
    }

    // pnid 검색 리스트
    function fnSearchPnidList(searchKeyword) {
        $("#btnList").attr("disabled", false);

        $.ajax({
            url: "${pageContext.request.contextPath}/admin/pnid/selectPnidListAjax.do",
            type: "GET",
            dataType: "json",
            data: {searchKeyword: searchKeyword},
            success: function (list) {
                console.log("[fnSearchDataAdmin] 조회 결과:", list);
                console.log("[fnSearchDataAdmin] 조회 건수:", list ? list.length : 0);

                if (!list || list.length === 0) {
                    $("#_VIEW_IFRAME").attr("src", "about:blank");
                    $("#_DOC_LIST").empty();
                    $("#btnList").attr("disabled", true);
                    $("#_DOC_VIEW").addClass("d-none").removeClass("active");

                    title = "검색";
                    content = "해당 설비의 P&ID 정보가 없습니다.";
                    fnAlert();
                    return false;
                }

                /* doc list */
                renderPnidDocList(list);

                // 첫 번째 문서 우선 로드
                const first = list[0];
                const firstViewerUrl = "${pageContext.request.contextPath}/admin/pnid/viewer.do"
                    + "?dataPath=" + encodeURIComponent(first.data || "")
                    + "&searchTag=" + encodeURIComponent(first.tagNo || "");

                fnViewPageAdmin(firstViewerUrl);

                /* 설비번호가 이니면 tagno descripton */
                /*if (!isFacilityNo) {
                    var pnidIegNo = "[" + first.iegNo + "] ";
                    $("#iegDescription").val(pnidIegNo + first.text);
                }*/

                if (list.length === 1) {
                    $("#_DOC_VIEW").addClass("d-none").removeClass("active");
                } else {
                    $("#_DOC_VIEW").removeClass("d-none").addClass("active");
                }
            },
            error: function (xhr, status, error) {
                console.log("[fnSearchDataAdmin] P&ID 조회 오류:", error);
                console.log("[fnSearchDataAdmin] responseText:", xhr.responseText);
                alert("P&ID 조회 중 오류가 발생했습니다.");
            }
        });
    }

    function fnPnidView(info) {
        info = info || {};

        var iegNo = info.iegNo || "";
        var text = info.text || "";
        var dataPath = info.data || "";
        var targetTransform = info.targetTransform || "";
        var pnidTagNo = info.pnidTagNo || "";
        var fileName = (info.fileName || "").split("?")[0];

        var url = "/admin/pnid/pnidInfoPop.do"
            + "?iegNo=" + encodeURIComponent(iegNo)
            + "&text=" + encodeURIComponent(text)
            + "&data=" + encodeURIComponent(dataPath)
            + "&targetTransform=" + encodeURIComponent(targetTransform)
            + "&pnidTagNo=" + encodeURIComponent(pnidTagNo)
            + "&pnidSvgFileName=" + encodeURIComponent(fileName);

        console.log("[fnPnidView info]", {
            iegNo: iegNo,
            text: text,
            dataPath: dataPath,
            targetTransform: targetTransform,
            pnidTagNo: pnidTagNo,
            fileName: fileName
        });

        window._pnidWinbox = new WinBox("P&ID 정보", {
            url: url,
            width: "640px",
            height: "264px",
            class: ["no-full", "app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, h) {
                if (this.min) return;
                this.move("center", "center");
            }
        });

        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    function fnMovePageEdit(info) {
        info = info || {};

        var dataPath = info.dataPath || "";
        var gId = info.gId || "";
        var pmtId = info.pmtId || "";
        var currentPoint = info.currentPoint || "";
        var drawingFile = info.drawingFile || "";
        var drawingTagNo = info.drawingTagNo || "";
        var rawMovePage = info.rawMovePage || "";
        var targetTransform = info.targetTransform || "";
        var movePoint = info.movePoint || "";

        var url = "${pageContext.request.contextPath}/admin/pnid/movePageEditPop.do"
            + "?dataPath=" + encodeURIComponent(dataPath)
            + "&gId=" + encodeURIComponent(gId)
            + "&pmtId=" + encodeURIComponent(pmtId)
            + "&currentPoint=" +  encodeURIComponent(currentPoint)
            + "&drawingFile=" + encodeURIComponent(drawingFile)
            + "&drawingTagNo=" + encodeURIComponent(drawingTagNo)
            + "&rawMovePage=" + encodeURIComponent(rawMovePage)
            + "&targetTransform=" + encodeURIComponent(targetTransform)
            + "&movePoint=" + encodeURIComponent(movePoint)

        console.log("[fnMovePageEdit info]", {
            dataPath: dataPath,
            gId: gId,
            pmtId: pmtId,
            drawingFile: drawingFile,
            drawingTagNo: drawingTagNo,
            rawMovePage: rawMovePage,
            targetTransform: targetTransform
        });

        window._pnidWinbox = new WinBox("movepage 수정", {
            url: url,
            width: "640px",
            height: "400px",
            class: ["no-full", "app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function () {
                if (this.min) return;
                this.move("center", "center");
            }
        });

        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
        
        
    }

    /**
     * 공통: 설비번호 검색
     * js callback 처리 부분
     */
    function fnSearchResult() {
        var iegNo = $("#iegNo").val().trim();
        var iegDescription = $("#iegDescription").val();

        if (iegNo) {
            $("#iegdescription").val("");
            fnSearchPnidList(iegNo);
        } else {
            $("#_DOC_LIST").empty();
            $("#iegNoList").empty();
            $("#btnList").attr("disabled", true);

            if(iegDescription) {
                fnSearchPnidList(iegDescription);
            }
        }
    }

    $(function () {
        var iegNo = $("#iegNo").val().trim();
        if (iegNo) {
            fnSearchPnidList(iegNo);
        }
    });
</script>
