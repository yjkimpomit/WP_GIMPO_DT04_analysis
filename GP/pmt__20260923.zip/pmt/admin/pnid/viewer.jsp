<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script src="${pageContext.request.contextPath}/resources/admin/js/jquery/jquery-3.6.1.min.js"></script>
<script>
	function loadCss(url) {
		if (!document.querySelector(`link[href="${url}"]`)) {
			const link = document.createElement("link");
			link.rel = "stylesheet";
			link.href = url;
			document.head.appendChild(link);
		}
	}
	loadCss('${pageContext.request.contextPath}/resources/js/svgviewer/css/style.css');
	loadCss('${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.min.css');
	loadCss('${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.override.css');
</script>

<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="page-content__placeholder">
    <div id="svgarea">
        <div id="center-guide" aria-hidden="true">
            <div class="cg-line cg-vertical"></div>
            <div class="cg-line cg-horizontal"></div>
        </div>
    </div>

    <div class="pnid-history-box">
        <div class="pnid-history-header">
            <strong>최근 도면<span id="pnidHistoryCount"></span></strong>
            <button
                    type="button"
                    id="pnidToggleBtn"
                    class="pnid-toggle-btn"
                    aria-expanded="true"
                    aria-label="최근 도면 접기/펼치기">
                <span class="visually-hidden">도면리스트</span>
            </button>
        </div>
    
        <div class="pnid-history-body" id="pnidHistoryBody">
            <ul class="pnid-history-list" id="navHistoryList">
            </ul>
        </div>
    </div>
</div>

<script src="${pageContext.request.contextPath}/resources/admin/js/pnid/svg-pan-zoom.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/pnid/svg.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/pnid/svgViewerUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/pnid/svgTableUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.min.js"></script>
<script>
    const dataPath = "${fn:escapeXml(param.dataPath)}";
    const searchTag = "${fn:escapeXml(param.searchTag)}";
    let parser = new DOMParser();
    let svgDoc = null;
    let svgElement = null;
    let panZoom = null;
    let svgType = null;
    let ckType = null;
    let checkeClickEvent = false;
    const NAV_HISTORY_KEY = "admin_pnid_nav_history";
    const svgns = 'http://www.w3.org/2000/svg';

    window.addEventListener("DOMContentLoaded", function () {
        console.log("dataPath =", dataPath);
        console.log("searchTag =", searchTag);
        initFromUrlParams();

    });

    /* 팝업 - DB 수정 */
    function fnPnidInfo(info) {
        parent.fnPnidView(info);
    }

    /* 팝업 -movepage */
    function fnMovePageEdit(info) {
        parent.fnMovePageEdit(info);
    }
</script>