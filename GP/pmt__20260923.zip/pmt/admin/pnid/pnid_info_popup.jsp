<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">P&amp;ID 정보</h1>
        <div class="table-responsive">
            <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="pnid-정보">
                <colgroup>
                    <col style="width: 128px;">
                    <col>
                </colgroup>
                <tbody>
                <tr>
                    <th scope="row">태그 No</th>
                    <td data-field="태그 No">${dataInfo.pnidTagNo}</td>
                </tr>
                <tr>
                    <th scope="row">Tag Text</th>
                    <td data-field="Tag Text">${dataInfo.pnidTextValue}</td>
                </tr>
                <tr>
                    <th scope="row">설비번호</th>
                    <td data-field="설비번호">
                        <form id="searchForm" method="post" autocomplete="off">
                            <div class="form-field">
                                    <label class="visually-hidden" for="iegNo">설비번호 입력</label>
                                <div class="form-control-group">
                                    <input class="form-control" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호 입력" value="${dataInfo.iegNo}" readonly>
                                    <button type="button" id="editBtn" class="button button--primary" onclick="fnEditPnidIegNo()">수정</button>
                                </div>
                                <!-- 설비정보가 2개 이상인 경우 보여줌 -->
                                <datalist class="_IEG_NO_LIST" id="iegNoList"></datalist>
                            </div>
                        </form>
                    </td>
                </tr>
                <tr>
                    <th scope="row">설비명</th>
                    <td data-field="설비명">
                        <label class="visually-hidden" for="iegDescription">설비명 입력</label>
                        <input class="form-control" id="iegDescription" readonly value="${dataInfo.iegDecription}">
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        <input type="hidden" value="${dataInfo.iempIdx}" id="iempIdx">
    </div>
</main>

<%-- 설비검색 공통 --%>
<script src="${pageContext.request.contextPath}/resources/admin/js/pnid/custom-pnid-search.js"></script>
<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    /**
     * 공통
     * js callback 처리 부분
     */
    function fnSearchResult() {
        $("#editBtn").removeClass("btn-primary").addClass("btn-danger").text("저장");
    }

    function fnEditPnidIegNo() {
        var $btn = $("#editBtn");

        // btn-danger 상태면 수정 저장(update)
        if ($btn.hasClass("btn-danger")) {
            fnUpdatePnidInfo();
            return;
        }
        document.getElementById("iegNo").removeAttribute("readonly");
        document.getElementById("iegNo").focus();
    }

    function fnUpdatePnidInfo() {
        var iegNo = $("#iegNo").val().trim();

        // 필수값 체크
        if (iegNo === "") {
            alert("설비번호는 필수 입력값입니다.");
            $("#iegNo").focus();
            return;
        }

        $.ajax({
            type: "POST",
            url: "/admin/pnid/updateInfo.do",
            data: {
                iegNo: iegNo,
                iegDecription: $("#iegDescription").val(),
                iempIdx: $("#iempIdx").val()
            },
            dataType: "json",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                if (data.result > 0) {
                    alert("수정이 완료되었습니다.");
                    window.parent._pnidWinbox?.close();
                    
                    $("#iegNo").prop("readonly", true);

                    $("#editBtn")
                        .removeClass("btn-danger")
                        .addClass("btn-primary")
                        .text("수정");
                }

            },
            error: function () {
                alert("수정 중 오류가 발생했습니다.");
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>