<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">P&amp;ID 검색</h1>
        <!-- P&ID 검색 화면 -->
        <h2 class="title02">P&ID</h2>
    
        <!-- 검색영역 -->
        <div class="search-box">
            <form id="searchForm" method="post" autocomplete="off">
                <input type="hidden" name="searchCondition" id="searchCondition">
                <div class="row">
                    <div class="col-12 col-md-4">
                        <label class="form-label" for="iegNo">설비, 태그 번호</label>
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="설비, 태그 번호 입력 후 엔터">
                    </div>
                    <div class="col-12 col-md">
                        <label class="visually-hidden" for="iegDescription">설비명</label>
                        <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly="">
                    </div>
    
                    <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                    <datalist id="iegNoList"></datalist>
    
                    <div class="col col-md-auto">
                        <button type="button" class="btn btn-primary" id="btnList" onclick="toggleDocuList()" disabled>목록보기</button>
                    </div>
                </div>
            </form>
        </div>
    
        <iframe class="pnid-iframe" id="_VIEW_IFRAME" src=""></iframe>
        <!-- 연계문서 -->
        <div class="doc-box active d-none" id="_DOC_VIEW">
            <div class="doc-header">
                <strong>연계문서</strong>
                <span class="icon icon-close" title="닫기" onclick="toggleDocuList();"></span>
            </div>
            <div class="linked-data" id="_DOC_LIST">
                <%-- 문서 리스트 --%>
            </div>
        </div>
    </div>
</main>

<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    function toggleDocuList() {
        $("#_DOC_VIEW").toggleClass("d-none");
        $("#_DOC_VIEW").toggleClass("active");
    }

    // 뷰어 로드
    function fnViewPageAdmin(url, t) {
        if (!isFacilityNo) {
            $("#iegDescription").val($(t).data("desc"));
        }

        $("#_VIEW_IFRAME").attr("src", url);
    }

    // 문서 목록 렌더링
    function renderPnidDocList(list) {
        const html = [];

        $.each(list, function (i, item) {
            var text = (item && item.text) || "";

            const viewerUrl = "${pageContext.request.contextPath}/admin/pnid/viewer.do"
                + "?dataPath=" + encodeURIComponent(item.data || "")
                + "&searchTag=" + encodeURIComponent(item.tagNo || "");

            html.push(
                '<div class="doc-link" onclick="fnViewPageAdmin(\'' + viewerUrl + '\', this); toggleDocuList();" data-desc="[' + item.iegNo + '] ' + text + '">' +
                '<span>' + (item.fileName || '') + ' [' + item.iegNo + ']</span> ' +
                '<span>' + text + '</span>' +
                '</div>'
            );
        });

        $("#_DOC_LIST").html(html.join(""));
    }

    // pnid 검색 리스트
    function fnSearchPnidList(iegNo) {
        $("#btnList").attr("disabled", false);

        $.ajax({
            url: "${pageContext.request.contextPath}/admin/pnid/selectPnidListAjax.do",
            type: "GET",
            dataType: "json",
            data: {searchKeyword: iegNo},
            success: function (list) {
                if (!list || list.length === 0) {
                    $("#_VIEW_IFRAME").attr("src", "about:blank");
                    $("#_DOC_LIST").empty();
                    $("#btnList").attr("disabled", true);
                    $("#_DOC_VIEW").addClass("d-none").removeClass("active");

                    title = "검색";
                    content = "해당 설비의 P&ID 정보가 없습니다.";
                    fnAlert();
                    return false;
                }

                /* doc list */
                renderPnidDocList(list);

                // 첫 번째 문서 우선 로드
                const first = list[0];
                const firstViewerUrl = "${pageContext.request.contextPath}/admin/pnid/viewer.do"
                    + "?dataPath=" + encodeURIComponent(first.data || "")
                    + "&searchTag=" + encodeURIComponent(first.tagNo || "");

                fnViewPageAdmin(firstViewerUrl);

                /* 설비번호가 이니면 tagno descripton */
                if (!isFacilityNo) {
                    var pnidIegNo = "[" + first.iegNo + "] ";
                    $("#iegDescription").val(pnidIegNo + first.text);
                }

                if (list.length === 1) {
                    $("#_DOC_VIEW").addClass("d-none").removeClass("active");
                } else {
                    $("#_DOC_VIEW").removeClass("d-none").addClass("active");
                }
            },
            error: function (xhr, status, error) {
                console.log("[fnSearchDataAdmin] P&ID 조회 오류:", error);
                console.log("[fnSearchDataAdmin] responseText:", xhr.responseText);
                alert("P&ID 조회 중 오류가 발생했습니다.");
            }
        });
    }

    function fnPnidView(info) {
        info = info || {};

        var iegNo = info.iegNo || "";
        var text = info.text || "";
        var dataPath = info.data || "";
        var targetTransform = info.targetTransform || "";
        var pnidTagNo = info.pnidTagNo || "";
        var fileName = (info.fileName || "").split("?")[0];
        
        var url = "/admin/pnid/pnidInfoPop.do"
            + "?iegNo=" + encodeURIComponent(iegNo)
            + "&text=" + encodeURIComponent(text)
            + "&data=" + encodeURIComponent(dataPath)
            + "&targetTransform=" + encodeURIComponent(targetTransform)
            + "&pnidTagNo=" + encodeURIComponent(pnidTagNo)
            + "&pnidSvgFileName=" + encodeURIComponent(fileName);

        console.log("[fnPnidView info]", {
            iegNo: iegNo,
            text: text,
            dataPath: dataPath,
            targetTransform: targetTransform,
            pnidTagNo: pnidTagNo,
            fileName: fileName
        });

        var box = new WinBox("P&ID 정보", {
            url: url,
            width: "600px",
            height: "500px",
            class: ["no-full"],
            position: "center",
            onresize: function (w, h) {
                if (this.min) return;
                this.move("center", "center");
            }
        });

        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    function fnMovePageEdit(info) {
        info = info || {};

        var dataPath = info.dataPath || "";
        var gId = info.gId || "";
        var pmtId = info.pmtId || "";
        var drawingFile = info.drawingFile || "";
        var drawingTagNo = info.drawingTagNo || "";
        var rawMovePage = info.rawMovePage || "";
        var targetTransform = info.targetTransform || "";

        var url = "${pageContext.request.contextPath}/admin/pnid/movePageEditPop.do"
            + "?dataPath=" + encodeURIComponent(dataPath)
            + "&gId=" + encodeURIComponent(gId)
            + "&pmtId=" + encodeURIComponent(pmtId)
            + "&drawingFile=" + encodeURIComponent(drawingFile)
            + "&drawingTagNo=" + encodeURIComponent(drawingTagNo)
            + "&rawMovePage=" + encodeURIComponent(rawMovePage)
            + "&targetTransform=" + encodeURIComponent(targetTransform);

        console.log("[fnMovePageEdit info]", {
            dataPath: dataPath,
            gId: gId,
            pmtId: pmtId,
            drawingFile: drawingFile,
            drawingTagNo: drawingTagNo,
            rawMovePage: rawMovePage,
            targetTransform: targetTransform
        });

        var box = new WinBox("movepage 수정", {
            url: url,
            width: "650px",
            height: "360px",
            class: ["no-full"],
            position: "center",
            onresize: function () {
                if (this.min) return;
                this.move("center", "center");
            }
        });

        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    /**
     * 공통: 설비번호 검색
     * js callback 처리 부분
     */
    function fnSearchResult() {
        var iegNo = $("#iegNo").val().trim();

        if (iegNo) {
            fnSearchPnidList(iegNo);
        } else {
            $("#_DOC_LIST").empty();
            $("#btnList").attr("disabled", true);
        }
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>