<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>

<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">P&amp;ID 보기</h1>
        <div class="table-responsive">
            <table class="data-table data-table--view data-table--detail" aria-label="pnid-movepage-정보">
                <colgroup>
                    <col style="width: 160px;">
                    <col>
                </colgroup>
                <tbody>
                <tr>
                    <th scope="row">현재 도면</th>
                    <td>
                        <label class="visually-hidden" for="dataPathName">현재 도면</label>
                        <input type="text" class="form-control" id="dataPathName" value="${fn:escapeXml(dataPathName)}" readonly>
                    </td>
                </tr>
                <tr>
                    <th scope="row">현재 TEXT</th>
                    <td>
                        <label class="visually-hidden" for="gId">현재 TEXT</label>
                        <input type="text" class="form-control" id="gId" value="${fn:escapeXml(gId)}" readonly>
                    </td>
                </tr>
                <tr>
                    <th scope="row">현재 좌표</th>
                    <td>
                        <label class="visually-hidden" for="gId">현재 좌표</label>
                        <input type="text" class="form-control" id="currentPoint" value="${fn:escapeXml(currentPoint)}" readonly>
                    </td>
                </tr>
                <tr>
                    <th scope="row">이동 도면</th>
                    <td>
                        <label class="visually-hidden" for="drawingFile">이동 도면</label>
                        <input type="text" class="form-control" id="drawingFile" value="${fn:escapeXml(drawingFile)}">
                    </td>
                </tr>
                <tr>
                    <th scope="row">이동 TEXT</th>
                    <td>
                        <label class="visually-hidden" for="drawingTagNo">이동 TEXT</label>
                        <input type="text" class="form-control" id="drawingTagNo" value="${fn:escapeXml(drawingTagNo)}">
                    </td>
                </tr>
                <tr>
                    <th scope="row">이동 좌표</th>
                    <td>
                        <label class="visually-hidden" for="gId">이동 좌표</label>
                        <input type="text" class="form-control" id="movePoint" value="${fn:escapeXml(movePoint)}">
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>

    <div class="popup-footer">
        <button type="button" class="button button--primary" onclick="fnUpdateMovePage()">저장</button>
    
        <input type="hidden" id="dataPath" value="${fn:escapeXml(dataPath)}">
        <input type="hidden" id="pmtId" value="${fn:escapeXml(pmtId)}">
        <input type="hidden" id="targetTransform" value="${fn:escapeXml(targetTransform)}">
    </div>
</main>

<script>
    function fnUpdateMovePage() {
        var dataPath = $("#dataPath").val().trim();
        var gId = $("#gId").val().trim();
        var movePoint = $("#movePoint").val().trim();
        var pmtId = $("#pmtId").val().trim();
        var drawingFile = $("#drawingFile").val().trim();
        var drawingTagNo = $("#drawingTagNo").val().trim();
        var targetTransform = $("#targetTransform").val().trim();
        console.log("popup targetTransform =", $("#targetTransform").val());

        if (targetTransform === "") {
            alert("현재 targetTransform가  없습니다.");
            return;
        }
        if (dataPath === "") {
            alert("현재 도면 경로가 없습니다.");
            return;
        }
		
        if (gId === "") {
            alert("현재 TEXT 값이 없습니다.");
            return;
        }
        
        if (drawingFile === "") {
            alert("이동 도면이 없습니다.");
            return;
        }

        if (drawingTagNo === "") {
            alert("이동 TEXT 값이 필요합니다.");
            return;
        }
        
        if(movePoint == ""){
        	alert("이동 좌표 값이 필요합니다.");
        	return;
        }

        $.ajax({
            type: "POST",
            url: "${pageContext.request.contextPath}/admin/pnid/updateMovePageAjax.do",
            data: {
                dataPath: dataPath,
                gId: gId,
                movePoint : movePoint,
                drawingFile: drawingFile,
                drawingTagNo: drawingTagNo,
                targetTransform: targetTransform
            },
            dataType: "json",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                if (data.result == "1") {
                    try {
                        if (window.parent && window.parent.document) {
                            var iframe = window.parent.document.getElementById("_VIEW_IFRAME");

                            if (iframe && iframe.contentWindow) {
                                var viewerWin = iframe.contentWindow;
                                var normalizedPath = dataPath;

                                if (normalizedPath.indexOf("/drawing/pnid/") !== 0) {
                                    var fileName = normalizedPath.split("/").pop();
                                    normalizedPath = "/drawing/pnid/" + fileName;
                                }
                                var reloadUrl = normalizedPath + (normalizedPath.indexOf("?") > -1 ? "&" : "?") + "_ts=" + Date.now();

                                setTimeout(function () {
                                    if (typeof viewerWin.createAndLoadSVG === "function") {
                                        viewerWin.createAndLoadSVG(reloadUrl, gId);
                                    } else {
                                        iframe.src = reloadUrl;
                                    }

                                    $("#loadingBar").hide();
                                    alert("movepage 수정이 완료되었습니다.");
                                    window.parent._pnidWinbox?.close();
                                    window.close();
                                }, 8000);
                            } else {
                                $("#loadingBar").hide();
                                alert("movepage 수정이 완료되었습니다.");
                                window.close();
                            }
                        } else {
                            $("#loadingBar").hide();
                            alert("movepage 수정이 완료되었습니다.");
                            window.close();
                        }
                    } catch (e) {
                        $("#loadingBar").hide();
                        console.error("도면 새로고침 중 오류:", e);
                        alert("movepage 수정은 완료되었지만 도면 새로고침 중 오류가 발생했습니다.");
                        window.close();
                    }
                } else {
                    $("#loadingBar").hide();
                    alert(data.message || "저장에 실패했습니다.");
                }
            },
            error: function (xhr) {
                $("#loadingBar").hide();
                console.log(xhr.responseText);
                alert("저장 중 오류가 발생했습니다.");
            }
        });
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>