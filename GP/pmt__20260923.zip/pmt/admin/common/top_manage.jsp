<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--
* 관리자 top 화면
--%>

<div>
    <img src="${pageContext.request.contextPath}/resources/user/images/logo-white.svg" alt="서부발전">
    <span class="branch-name">김포열병합</span>
    <span class="title">관리자 >> </span>
    <span class=""><a class="title" href="javascript:" onclick="fnOpenPopup('/serviceinfo/index.do', $(this))" data-title="개선사항">개선사항</a></span>
    <span class=""><a class="title" href="javascript:" onclick="fnOpenPopup('/log/index.do', $(this))" data-title="방문자 정보">방문자 정보</a></span>
    <span class=""><a class="title" href="javascript:" onclick="fnOpenPopup('/logsheet/logsheetCheckLogIndex.do', $(this))" data-title="로그시트 점검 정보">로그시트 점검 정보</a></span>
</div>