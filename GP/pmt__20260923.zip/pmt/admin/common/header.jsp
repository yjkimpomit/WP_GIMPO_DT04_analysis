<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--
* 관리자 > 헤더 화면
--%>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <title>서부발전 김포열병합 DT :: 관리자 페이지</title>
    <meta name="description" content="서부발전 김포열병합 DT 서비스 제공">
    <%-- <!-- favicon --> --%>
    <link rel="icon" href="${pageContext.request.contextPath}/resources/admin/images/favicon.ico" sizes="any">
    <link rel="icon" href="${pageContext.request.contextPath}/resources/admin/images/favicon.svg" type="image/svg+xml">

    <%--
        * js에 사용할 변수 선언
        * 모바일 체크
        * 사업소, 호기 정보
        * IDMS 페이지 <---> 3D MODEL
    --%>
    <script>
        // check device
        var checkDevice = "${device}";
        var eqOrgNo = "${sessionScope.eqOrgNo}";
        var hoki = "${sessionScope.hoki}";
        var _isIdmsPage = false;
    </script>

    <%-- 공통 js --%>
    <script src="${pageContext.request.contextPath}/resources/admin/js/jquery/jquery-3.6.1.js"></script>
    <script src="${pageContext.request.contextPath}/resources/admin/js/common/common.js?t=${System.currentTimeMillis()}"></script>

    <%-- ztree --%>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/resources/admin/js/ztree/css/metroStyle/metroStyle.css">
    <script src="${pageContext.request.contextPath}/resources/admin/js/ztree/js/jquery.ztree.all.min.js"></script>

    <%-- <!-- 부트스트랩 JS --> --%>
    <%--<script src="${pageContext.request.contextPath}/resources/admin/js/bootstrap/popper.min.js"></script>--%>
    <script src="${pageContext.request.contextPath}/resources/admin/js/bootstrap/bootstrap.bundle.min.js"></script>

    <%-- winbox js --%>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/resources/admin/js/winbox/winbox.min.css">
    <script src="${pageContext.request.contextPath}/resources/admin/js/winbox/winbox.min.js"></script>
    
    <%-- <!-- bPopup --> --%>
    <script src="${pageContext.request.contextPath}/resources/js/jquery/jquery.bpopup.min.js"></script>

    <%-- <!-- WP stylesheet --> --%>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/resources/admin/css/admin.css?t=${System.currentTimeMillis()}">
    <script src="${pageContext.request.contextPath}/resources/admin/js/common/admin.js" defer></script>

    <%-- unity --%>
    <%--<link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/unity3DViewer/TemplateData/style.css?t=${System.currentTimeMillis()}">
    <link rel="manifest" type="text/css" href="${pageContext.request.contextPath}/unity3DViewer/manifest.webmanifest">--%>

    <%--// jquery-alert : 팝업 --%>
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.min.css">
    <link rel="stylesheet" type="text/css" href="${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.override.css">
    <script src="${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.min.js"></script>

    <%-- 설비검색 공통 --%>
    <script src="${pageContext.request.contextPath}/resources/admin/js/facility/custom-facility-search.js?t=${System.currentTimeMillis()}"></script>

    <%-- IFRAME 공통 --%>
    <%--<script src="${pageContext.request.contextPath}/resources/admin/js/iframe/custom-iframe-load.js"></script>--%>
    
    <%-- 설비명 autocomplete --%>
    <%--<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/admin/js/jquery-ui/jquery-ui.css">
    <script src="${pageContext.request.contextPath}/resources/admin/js/jquery-ui/jquery-3.7.1.min.js"></script>
    <script src="${pageContext.request.contextPath}/resources/admin/js/jquery-ui/jquery-ui.min.js"></script>--%>
</head>
