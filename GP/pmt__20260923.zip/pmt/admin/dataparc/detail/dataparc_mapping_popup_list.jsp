<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- dataparc의 설비번호 연결 리스트 화면 -->--%>

<%--<div id="_DATAPARC_MAPPING_LIST">--%>
<%-- 연결한 설비 리스트 --%>
<div class="table-responsive">
<form id="modelListForm" name="modelListForm" method="post" autocomplete="off">
    <input type="hidden" name="mode" value="U"/>
    <table class="data-table data-table--list data-table--interactive" aria-label="dataPARC-설비리스트">
        <thead>
        <tr>
            <th scope="col" data-field="설비번호">설비번호</th>
            <th scope="col" data-field="설비명">설비명</th>
            <th scope="col" data-field="연결">연결</th>
        </tr>
        </thead>
        <tbody>
        <%-- 리스트 없을 경우 --%>
        <c:if test="${empty modelList}">
            <tr>
                <td colspan="3">정보가 없습니다.</td>
            </tr>
        </c:if>

        <%-- 데이터 리스트 --%>
        <c:forEach var="data" items="${modelList}" varStatus="status">
            <c:set var="idx" value="${data.iemdtIdx}"/>

            <tr id="_TR_${idx}">
                <td data-field="설비번호">
                    <label class="visually-hidden" for="_NO_${idx}">설비명 입력</label>
                    <input type="text" class="form-control _IEGNO" id="_NO_${idx}" name="iegNo" value="${data.iegNo}" disabled />
                </td>
                <td data-field="설비명" id="_DESC_${idx}">${data.iegDecription}</td>
                <td data-field="연결">
                    <button type="button" class="btn btn-xs btn-primary" onclick="fnModifyMapping('${idx}');">수정</button>
                    <button type="button" class="btn btn-xs btn-danger" onclick="fnRemoveMapping('${idx}');">삭제</button>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</form>
</div>
<%--</div>--%>
