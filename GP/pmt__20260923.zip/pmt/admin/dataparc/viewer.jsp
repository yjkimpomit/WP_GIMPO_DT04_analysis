<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script src="${pageContext.request.contextPath}/resources/admin/js/jquery/jquery-3.6.1.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/common/common.js"></script>
<script>
    loadCss("${pageContext.request.contextPath}/resources/admin/css/modal.css");
    loadCss("${pageContext.request.contextPath}/resources/admin/css/common.css");
    loadCss("${pageContext.request.contextPath}/resources/admin/css/bootstrap/dist/css/bootstrap.min.css");
	loadCss("${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.min.css");
	loadCss("${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.override.css");
</script>

<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="page-content__placeholder">
    <%-- dataparc 운전정보 팝업 --%>
    <%--<div class="modal fade" tabindex="-1" id="dataparcDetailBox">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-xl-down modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="title04">운전정보</h5>
                    <button type="button" class="btn close">
                        <span class="icon icon-close"></span><span>닫기</span>
                    </button>
                </div>
    
                <div class="modal-body" id="dataparcDetail">
    
                </div>
            </div>
        </div>
    </div>--%>
    
    <input class="visually-hidden" type="file" id="svgFileInput" accept=".svg"/>
    
    <div id="svgarea">
        <!-- 기존 object를 여기로 append 중 -->
        <div id="center-guide" aria-hidden="true">
            <div class="cg-line cg-vertical"></div>
            <div class="cg-line cg-horizontal"></div>
        </div>
    </div>
</div>

<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/svg-pan-zoom.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/svg.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/svgViewerUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/svgTableUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/svgDummyUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/svgUtagHandlerUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/jquery/confirm/jquery-confirm.min.js"></script>

<script>
    const dataPath = "${fn:escapeXml(param.dataPath)}";
    const searchTag = "${fn:escapeXml(param.searchTag)}";
    let parser = new DOMParser();
    let svgDoc = null;
    let svgElement = null;
    let panZoom = null;
    let svgType = null;
    let ckType = null;
    let checkeClickEvent = false;

    const svgns = 'http://www.w3.org/2000/svg';

    window.addEventListener("DOMContentLoaded", function () {
        initFromUrlParams();
        // 파일 업로드 시 작동
        /*   setupFileInputHandler(); */
    });

    /* 팝업 */
    function fnDataparcInfo(info) {
        parent.fnDataparcView(info);
    }
</script>