<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body class="winbox-layout">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="popup-body">
    <h5 class="title04">dataPARC 정보</h5>

    <div class="table-responsive">
        <table class="data-table data-table--view data-table--detail" aria-label="dataPARC-정보">
            <tbody>
            <tr>
                <th scope="row">Tag No</th>
                <td data-field="태그번호">${operInfo.utag}</td>
            </tr>
            <tr>
                <th scope="row">Tag Description</th>
                <td data-field="태그명">${operInfo.utagDes}</td>
            </tr>
            </tbody>
        </table>
    </div>

    <form method="post" autocomplete="off">
        <div class="search-box">
            <div class="row">
                <div class="col">
                    <label class="form-label" for="iegNo">설비번호 입력</label>
                    <input class="form-control" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호 입력 후 추가버튼 클릭">
                </div>
                <div class="col-auto">
                    <button type="button" class="btn btn-primary" onclick="fnAddMapping()">
                        <span>추가</span>
                    </button>
                </div>
            </div>
        </div>
    </form>

    <div id="_DATAPARC_MAPPING_LIST">
        <%-- 연결한 dataPARC 설비 리스트 --%>
    </div>
</div>

<form id="inputForm" method="post" autocomplete="off">
    <input type="hidden" id="utagDes" name="utagDes" value="${operInfo.utagDes}">
    <input type="hidden" id="utag" name="utag" value="${operInfo.utag}">
    <input type="hidden" id="iemdtIdx" name="iemdtIdx" value="0">
    <input type="hidden" id="inputIegNo" name="iegNo">
    <input type="hidden" id="mode" name="mode">
</form>

<script>
    /**
     * 연결된 설비 조회
     */
    function fnPopSearchMappingList() {
        $.ajax({
            type: "POST",
            url: "/admin/dataparc/dataparcMappingPopupList.do",
            data: {utag: "${operInfo.utag}"},
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_DATAPARC_MAPPING_LIST").html(data);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /* 설비정보 추가 */
    function fnAddMapping() {
        var iegNoVal = $("#iegNo").val().trim();

        if (iegNoVal.length > 0) {
            var isRun = true;
            $("._IEGNO").each(function (idx, el) {
                if ($(el).val() === iegNoVal) {
                    title = "설비번호 확인";
                    content = "이미 설비번호가 등록되어 있습니다.";
                    fnAlert();

                    isRun = false;
                    return false;
                }
            });

            if (isRun) {
                $("#inputForm #mode").val('I');
                $("#inputForm #inputIegNo").val(iegNoVal);

                $.confirm({
                    title: "설비번호 추가",
                    content: "저장하시겠습니까?",
                    type: 'blue',
                    buttons: {
                        '확인': {
                            btnClass: 'btn-blue',
                            action: function () {
                                $.ajax({
                                    type: "POST",
                                    url: "/admin/dataparc/saveDataparcMapping.do",
                                    data: $("#inputForm").serialize(),
                                    dataType: "json",
                                    beforeSend: function () {
                                        $("#loadingBar").show();
                                    },
                                    success: function (data) {
                                        if (data.result === '1') {
                                            fnPopSearchMappingList();
                                            //window.parent.isUpdate = true;
                                        } else {
                                            title = "저장";
                                            content = "오류가 발생했습니다.";
                                            fnAlert();
                                        }
                                    },
                                    error: function (request, status, error) {
                                        title = "저장";
                                        content = "오류가 발생했습니다.";
                                        fnAlert();
                                    },
                                    complete: function () {
                                        $("#loadingBar").hide();
                                    }
                                });
                            }
                        },
                        '취소': {
                            action: function () {
                            }
                        }
                    }
                });
            }
        } else {
            title = "입력";
            content = "설비번호를 입력하세요";
            fnAlert();
        }
    }

    /* 연결된 설비정보 수정 */
    function fnModifyMapping(idx) {
        var targetNo = "#_NO_" + idx;
        var $targetInput = $(targetNo);

        if ($targetInput.is(":disabled")) {
            $("#_TR_" + idx).find("button:first").html("저장");
            $targetInput.prop("disabled", false);
            $targetInput.focus();
        } else {
            var iegNoVal = $targetInput.val().trim();

            if (iegNoVal.length === 0) {
                title = "입력";
                content = "설비번호를 입력하세요.";
                fnAlert();
                return;
            }

            var isRun = true;
            $("._IEGNO").each(function () {
                var thisIdx = $(this).attr("id").replace("_NO_", "");
                var thisVal = $(this).val().trim();

                if (thisIdx != idx && thisVal === iegNoVal) {
                    title = "설비번호 확인";
                    content = "이미 설비번호가 등록되어 있습니다.";
                    fnAlert();
                    isRun = false;
                    return false;
                }
            });

            if (!isRun) {
                return;
            }

            $("#inputForm #mode").val("U");
            $("#inputForm #iemdtIdx").val(idx);
            $("#inputForm #inputIegNo").val(iegNoVal);

            $.confirm({
                title: "설비번호 저장",
                content: "저장하시겠습니까?",
                type: "blue",
                buttons: {
                    "확인": {
                        btnClass: "btn-blue",
                        action: function () {
                            $.ajax({
                                type: "POST",
                                url: "/admin/dataparc/saveDataparcMapping.do",
                                data: $("#inputForm").serialize(),
                                dataType: "json",
                                beforeSend: function () {
                                    $("#loadingBar").show();
                                },
                                success: function (data) {
                                    if (data.result === "1") {
                                        fnPopSearchMappingList();
                                    } else {
                                        title = "저장";
                                        content = "오류가 발생했습니다.";
                                        fnAlert();
                                    }
                                },
                                error: function () {
                                    title = "저장";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                },
                                complete: function () {
                                    $("#loadingBar").hide();
                                }
                            });
                        }
                    },
                    "취소": {
                        action: function () {
                        }
                    }
                }
            });
        }
    }

    /* 삭제 처리 */
    function fnRemoveMapping(idx) {
        $("#inputForm #iemdtIdx").val(idx);

        $.confirm({
            title: "설비번호 삭제",
            content: "삭제하시겠습니까?",
            type: 'red',
            buttons: {
                '확인': {
                    btnClass: 'btn-red',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/dataparc/removeDataparcMapping.do",
                            data: $("#inputForm").serialize(),
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result === '1') {
                                    fnPopSearchMappingList();
                                } else {
                                    title = "삭제";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "삭제";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    $(function () {
        fnPopSearchMappingList();
    });
</script>
</body>
<c:import url="/footer.do"/>
