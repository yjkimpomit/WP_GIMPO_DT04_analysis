<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- dataPARC 화면 -->
<div class="winbox-layout page-content document-viewer-page">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">dataPARC</h1>
        
        <!-- 검색영역 -->
        <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
            <input type="hidden" name="searchCondition" id="searchCondition">
            <div class="filter-panel__fields">
                <div class="form-field">
                    <label class="form-label" for="iegNo">설비, dataPARC 검색</label>
                    <div class="form-control-group">
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="">
                        <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly>
                        <div class="buttons">
                            <button type="button" class="button button--secondary" id="btnList" onclick="toggleDocuList()" disabled>목록보기</button>
                        </div>
                    </div>
                
                    <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                    <datalist id="iegNoList"></datalist>
                </div>
                
            </div>
        </form>
        
        <div class="splitview">
            <aside class="splitview__pane splitview__pane--sidebar" aria-label="dataPARC 카테고리 목록">
                <div class="filter-panel filter-panel--with-section">
                    <div class="filter-panel__section" aria-labelledby="dataparc-category-title">
                        <h2 class="filter-panel__section-title visually-hidden" id="dataparc-category-title">카테고리</h2>
                        
                        <%-- 호기별 카테고리 --%>
                        <fieldset class="form-field dataparc-unit-group">
                            <legend class="form-label">9호기</legend>
                            <div class="form-field__content dataparc-category-buttons" data-pressed-button-group="" data-pressed-button-group-initialized="true">
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/2001_MAIN_BOILER.svg')">BOILER</button>
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/2002_MAIN_BOP.svg')">BOP</button>
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/2003_MAIN_PACKAGE.svg')">PACKAGE</button>
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/3004_MAIN_COMMON.svg')">COMMON</button>
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/2005_MAIN_TURBINE.svg')">TURBINE</button>
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/9/2000_PLANT%20OVERVIEW.svg')">OVERVIEW</button>
                                <button type="button" class="button button--accent-mint" onclick="fnViewPageCategory('/drawing/dataparc/ECMS/No.01_OVERVIEW.svg')">ECMS</button>
                            </div>
                        </fieldset>
                        <fieldset class="form-field dataparc-unit-group">
                            <legend class="form-label">10호기</legend>
                            <div class="form-field__content dataparc-category-buttons" data-pressed-button-group="" data-pressed-button-group-initialized="true">
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/4001_MAIN_BOILER.svg')">BOILER</button>
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/4002_MAIN_BOP.svg')">BOP</button>
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/4003_MAIN_PACKAGE.svg')">PACKAGE</button>
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/3004_MAIN_COMMON.svg')">COMMON</button>
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/4005_MAIN_TURBINE.svg')">TURBINE</button>
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ICMS/10/4000_PLANT%20OVERVIEW.svg')">OVERVIEW</button>
                                <button type="button" class="button button--accent-teal" onclick="fnViewPageCategory('/drawing/dataparc/ECMS/No.01_OVERVIEW.svg')">ECMS</button>
                            </div>
                        </fieldset>
                    </div>
                </div>
            </aside>
            
            <div class="splitview__pane splitview__pane--content">
                <div class="document-viewer">
                    <iframe id="_VIEW_IFRAME" src=""></iframe>
                </div>
            </div>
        </div>
        
        <!-- 연계문서 -->
        <div class="doc-box active d-none" id="_DOC_VIEW">
            <div class="doc-header">
                <strong>연계문서</strong>
                <span class="icon icon-close" title="닫기" onclick="toggleDocuList();"></span>
            </div>
            <div class="linked-data" id="_DOC_LIST">
                <%-- 문서 리스트 --%>
            </div>
        </div>
    </div>
</div>

<script>
	/* dataParc 팝업화면 전역 선언 */
	window._dataParcWinbox = null;
	
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    function toggleDocuList(flag) {
        $("#_DOC_VIEW").toggleClass("d-none");
        $("#_DOC_VIEW").toggleClass("active");
    }

    // 뷰어 로드
    function fnViewPage(url, t) {
        /*if (!isFacilityNo) {
            $("#iegDescription").val($(t).data("desc"));
        }*/

        $("#_VIEW_IFRAME").attr("src", url);
    }

    /* 카테고리 페이지 로드 */
    function fnViewPageCategory(t) {
        var url = "${pageContext.request.contextPath}/admin/dataparc/viewer.do?dataPath=" + t;
        fnViewPage(url, '');
    }

    // 관리자용 문서 목록 렌더링
    function renderDataparcDocList(list) {
        const html = [];

        $.each(list, function (i, item) {
            var text = (item && item.text) || "";

            const viewerUrl = "${pageContext.request.contextPath}/admin/dataparc/viewer.do"
                + "?dataPath=" + encodeURIComponent(item.data || "")
                + "&searchTag=" + encodeURIComponent(item.tagNo || "");

            html.push(
                '<div class="doc-link" onclick="fnViewPage(\'' + viewerUrl + '\', this); toggleDocuList();" data-desc="[' + item.iegNo + '] ' + text + '">' +
                '<span>' + (item.fileName || '') + ' [' + item.iegNo + ']</span> ' +
                '<span>' + text + '</span>' +
                '</div>'
            );
        });

        $("#_DOC_LIST").html(html.join(""));
    }

    // 관리자용 검색 공용 함수
    function fnSearchDataParcList(iegNo) {
        $("#btnList").attr("disabled", false);

        $.ajax({
            url: "${pageContext.request.contextPath}/admin/dataparc/selectDataparcListAjax.do",
            type: "GET",
            dataType: "json",
            data: {searchKeyword: iegNo},
            success: function (list) {
                console.log("조회 결과 list:", list);
                console.log("조회 건수:", list ? list.length : 0);

                if (!list || list.length === 0) {
                    $("#_VIEW_IFRAME").attr("src", "about:blank");
                    $("#_DOC_LIST").empty();
                    $("#btnList").attr("disabled", true);
                    $("#_DOC_VIEW").addClass("d-none").removeClass("active");

                    title = "검색";
                    content = "해당 설비의 dataPARC 정보가 없습니다.";
                    fnAlert();
                    return false;
                }

                renderDataparcDocList(list);

                const first = list[0];
                const firstViewerUrl = "${pageContext.request.contextPath}/admin/dataparc/viewer.do"
                    + "?dataPath=" + encodeURIComponent(first.data || "")
                    + "&searchTag=" + encodeURIComponent(first.tagNo || "");

                fnViewPage(firstViewerUrl);

                /* 설비번호가 이니면 tagno descripton */
                /*if (!isFacilityNo) {
                    var pnidIegNo = "[" + first.iegNo + "] ";
                    $("#iegDescription").val(pnidIegNo + first.text);
                }*/

                if (list.length === 1) {
                    $("#_DOC_VIEW").addClass("d-none").removeClass("active");
                } else {
                    $("#_DOC_VIEW").removeClass("d-none").addClass("active");
                }
            },
            error: function (xhr, status, error) {
                console.log("dataPARC 조회 오류:", error);
                console.log("xhr.responseText:", xhr.responseText);
                alert("dataPARC 조회 중 오류가 발생했습니다.");
            }
        });
    }

    function fnDataparcView(info) {
        info = info || {};
        var url = "";
        var iegNo = info.iegNo || "";
        var fileName = info.fileName || "";
        var data = info.data || "";
        var text = info.text || "";
        var dataTagNo = info.dataTagNo || "";
        var textElementId = info.textElementId || "";
        var svgPath = info.svgPath || "";
	
        /* 운영정보추가 20260317 */
        var utag = info.utag;
        var utagVal = info.utagVal;
        var utagDes = info.utagDes;

        if (utag) {
            url = "/admin/dataparc/dataparcOperPop.do"
                + "?utag=" + encodeURIComponent(utag)
                + "&dataSvgFileName=" + encodeURIComponent(fileName)
                + "&data=" + encodeURIComponent(data)
                + "&utagVal=" + encodeURIComponent(utagVal)
                + "&utagDes=" + encodeURIComponent(utagDes)
                + "&textElementId=" + encodeURIComponent(textElementId)
               	+ "&svgPath=" + encodeURIComponent(svgPath);
        } else {
            url = "/admin/dataparc/dataparcInfoPop.do"
                + "?iegNo=" + encodeURIComponent(iegNo)
                + "&dataSvgFileName=" + encodeURIComponent(fileName)
                + "&data=" + encodeURIComponent(data)
                + "&text=" + encodeURIComponent(text)
                + "&dataTagNo=" + encodeURIComponent(dataTagNo)
                + "&textElementId=" + encodeURIComponent(textElementId)
               	+ "&svgPath=" + encodeURIComponent(svgPath);
        }

        console.log("fnDataparcView url :", url);
        window._dataParcWinbox = new WinBox("dataPARC 연결", {
            url: url,
            width: "640px",
            height: "480px",
            class: ["no-full"],
            position: "center",
            onresize: function (w, h) {
                if (this.min) return;
                this.move("center", "center");
            }
        });

        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    /**
     * 공통: 설비번호 검색
     * js callback 처리 부분
     */
    function fnSearchResult() {
        var iegNo = $("#iegNo").val().trim();

        if (iegNo) {
            fnSearchDataParcList(iegNo);
        } else {
            $("#_DOC_LIST").empty();
            $("#btnList").attr("disabled", true);
        }
    }

    $(function () {
        var iegNo = $("#iegNo").val().trim();
        if (iegNo) {
            fnSearchDataParcList(iegNo);
        }
        else {
            fnViewPageCategory('/drawing/dataparc/ICMS/2001_MAIN_BOILER.svg');
        }
    });
</script>
