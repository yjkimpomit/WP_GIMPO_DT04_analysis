<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body class="winbox-layout">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="popup-body">
    <div class="table-responsive">
        <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="dataparc-정보">
            <colgroup>
                <col style="width: 128px;">
                <col>
            </colgroup>
            <tbody>
            <tr>
                <th scope="row">Tag No</th>
                <td data-field="Tag No">${dataInfo.dataTagNo}</td>
            </tr>
            <tr>
                <th scope="row">Tag Text</th>
                <td data-field="Tag Text">${dataInfo.dataTextValue}</td>
            </tr>
            <tr>
                <th scope="row">설비번호</th>
                <td data-field="설비번호">
                    <form id="searchForm" method="post" autocomplete="off">
                        <div class="row g-2" aria-labelledby="facilityNo">
                            <div class="col">
                                <label class="visually-hidden" for="iegNo">설비번호</label>
                                <input class="form-control icon-return" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호" value="${dataInfo.iegNo}" readonly>
                            </div>
                            <div class="col-auto">
                                <button type="button" id="editBtn" class="btn btn-primary" onclick="fnEditIegNo()">
                                    수정
                                </button>
                            </div>
                            <!-- 설비정보가 2개 이상인 경우 보여줌 -->
                            <datalist class="_IEG_NO_LIST" id="iegNoList"></datalist>
                        </div>
                    </form>
                </td>
            </tr>
            <tr>
                <th scope="row">설비명</th>
                <td data-field="설비명">
                    <label class="visually-hidden" for="iegDescription">설비명</label>
                    <input class="form-control" id="iegDescription" readonly value="${dataInfo.iegDecription}">
                </td>
            </tr>
            </tbody>
        </table>
    </div>
    <input type="hidden" value="${dataInfo.iemdIdx}" id="iemdIdx">
    <input type="hidden" value="${fn:escapeXml(param.svgPath)}" id="svgPath" >
</div>

<%-- 설비검색 공통 --%>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/custom-dataparc-search.js"></script>
<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    /**
     * 공통
     * js callback 처리 부분
     */
    function fnSearchResult() {
        $("#editBtn").removeClass("btn-primary").addClass("btn-danger").text("저장");
    }

    function fnEditIegNo() {
        var $btn = $("#editBtn");

        // btn-danger 상태면 수정 저장(update)
        if ($btn.hasClass("btn-danger")) {
            fnUpdateDataparcInfo();
            return;
        }
        document.getElementById("iegNo").removeAttribute("readonly");
        document.getElementById("iegNo").focus();
    }

    function fnUpdateDataparcInfo() {
        $.ajax({
            type: "POST",
            url: "/admin/dataparc/updateInfo.do",
            data: {
                iegNo: $("#iegNo").val(),
                iegDescription: $("#iegDescription").val(),
                iemdIdx: $("#iemdIdx").val(),
                dataSvgFileName : $("#svgPath").val(),
            },
            dataType: "json",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                if (data.result > 0) {
                    alert("수정이 완료되었습니다.");
                    window.parent._dataParcWinbox?.close();
                    $("#iegNo").prop("readonly", true);

                    $("#editBtn")
                        .removeClass("btn-danger")
                        .addClass("btn-primary")
                        .text("수정");
                }else if(data.result == '-2'){
                	alert("이미 등록된 태그입니다.");
                }
            },
            error: function () {
                alert("수정 중 오류가 발생했습니다.");
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>
