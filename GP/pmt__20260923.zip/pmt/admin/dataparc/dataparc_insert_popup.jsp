<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body class="winbox-layout">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="popup-body">
    <div class="table-responsive">
        <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="dataparc-정보등록">
            <colgroup>
                <col style="width: 128px;">
                <col>
            </colgroup>
            <tbody>
            <tr>
                <th scope="row">호기</th>
                <td data-field="호기">
                    <label class="visually-hidden" for="hoki">호기 선택</label>
                    <select class="form-select" id="hoki" name="hoki">
                        <option value="" selected>호기선택</option>
                        <option value="51909">9호기</option>
                        <option value="51910">10호기</option>
                    </select>
                </td>
            </tr>
            <tr>
                <th scope="row">Tag Text</th>
                <td data-field="Tag Text">
                    <label class="visually-hidden" for="dataTextValue">Tag Text를 입력</label>
                    <input class="form-control" type="text" id="dataTextValue" name="dataTextValue" placeholder="Tag Text를 입력하세요" required/>
                </td>
            </tr>
            <tr>
                <th scope="row">설비번호</th>
                <td data-field="설비번호">
                    <form id="searchForm" method="post" autocomplete="off">
                        <div class="row g-2" aria-labelledby="facilityNo">
                            <div class="col">
                                <label class="visually-hidden" for="iegNo">설비번호 입력 후 엔터</label>
                                <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호 입력 후 엔터">
                            </div>
                            <!-- 설비정보가 2개 이상인 경우 보여줌 -->
                            <datalist class="_IEG_NO_LIST" id="iegNoList"></datalist>
                        </div>
                    </form>
                </td>
            </tr>
            <tr>
                <th scope="row">설비명</th>
                <td data-field="설비명">
                    <label class="visually-hidden" for="iegDescription">설비명</label>
                    <input class="form-control" id="iegDescription" readonly>
                </td>
            </tr>
            <tr>
                <th scope="row">Tag No</th>
                <td data-field="TagNo">
                    <label class="visually-hidden" for="iegTagNo">태그명</label>
                    <input class="form-control" id="iegTagNo" readonly>
                </td>
            </tr>
            </tbody>
        </table>
    </div>
</div>

<div class="popup-footer">
    <button type="button" id="insBtn" class="btn btn-primary" onclick="fnInsIegNo()">
        등록
    </button>
    <input type="hidden" value="${detailInfo.dataDescription}" id="dataDescription">
    <input type="hidden" value="${detailInfo.dataNo}" id="dataNo">
    <input type="hidden" value="${detailInfo.dataSvgFileName}" id="dataSvgFileName">
    <input type="hidden" id="dataPath" value="${fn:escapeXml(param.data)}">
    <input type="hidden" id="textElementId" value="${fn:escapeXml(param.textElementId)}">
    <input type="hidden" id="svgPath" value="${fn:escapeXml(param.svgPath)}">
</div>

<%-- 설비검색 공통 --%>
<script src="${pageContext.request.contextPath}/resources/admin/js/dataparc/custom-dataparc-search.js"></script>
<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    $(document).ready(function () {
        $("#iegNo").on("keydown", function (e) {
            if (e.key === "Enter") {
                e.preventDefault();
                fnSearchFacilityList();
            }
        });
    });

    /**
     * 공통
     * js callback 처리 부분
     */
    function fnSearchResult(tagNo) {
        $("[id=iegTagNo]").val(tagNo);
    }

    function fnInsIegNo() {
        var hoki = $("#hoki").val();
        var dataTextValue = $("input[name='dataTextValue']").val().trim();
        var iegNo = $("#iegNo").val().trim();
        var iegDescription = $("#iegDescription").val().trim();
        var dataDescription = $("#dataDescription").val();
        var dataNo = $("#dataNo").val();
        var dataSvgFileName = $("#dataSvgFileName").val() || $("#svgPath").val();
        var dataTagNo = $("#iegTagNo").val();

        // 호기 선택 체크
        if (hoki === "") {
            alert("호기를 선택하세요.");
            $("#hoki").focus();
            return;
        }

        // Tag Text 체크
        if (dataTextValue === "") {
            alert("Tag Text를 입력하세요.");
            $("input[name='dataTextValue']").focus();
            return;
        }

        // 설비번호 체크
        if (iegNo === "") {
            alert("설비번호를 입력하세요.");
            $("#iegNo").focus();
            return;
        }
        $("#loadingBar").show();

        $.ajax({
            type: "POST",
            url: "/admin/dataparc/insDataparcInfo.do",
            data: {
                hoki: hoki,
                dataTextValue: dataTextValue,
                iegNo: iegNo,
                iegDescription: iegDescription,
                dataDescription: dataDescription,
                dataNo: dataNo,
                dataSvgFileName: dataSvgFileName,
                dataTagNo: dataTagNo
            },
            dataType: "json",
            success: function (data) {
                if (data.result == "1") {
                    fnInsertSvgGId(dataTagNo);

                } else if (data.result == "2") {
                    $("#loadingBar").hide();
                	alert("이미 등록된 태그입니다.");
                } else {
                    $("#loadingBar").hide();
                    alert("등록에 실패했습니다.");
                }
            },
            error: function () {
                $("#loadingBar").hide();
                alert("등록 중 오류가 발생했습니다.");
            }
        });
    }

    function fnInsertSvgGId(dataTagNo) {
        var dataPath = $("#dataPath").val();
        var textElementId = $("#textElementId").val();

        if (!dataTagNo) {
            $("#loadingBar").hide();
            alert("등록할 g id를 입력하세요.");
            return;
        }

        if (!dataPath) {
            $("#loadingBar").hide();
            alert("SVG 경로(dataPath)가 없습니다.");
            return;
        }

        if (!textElementId) {
            $("#loadingBar").hide();
            alert("클릭한 텍스트의 textElementId 값이 없습니다.");
            return;
        }

        $.ajax({
            type: "POST",
            url: "/admin/dataparc/updateSvgTagId.do",
            data: {
                dataPath: dataPath,
                textElementId: textElementId,
                newTagId: dataTagNo
            },
            dataType: "json",
            success: function (data) {
                console.log("updateSvgTagId result:", data);
                if (data.result === "success") {
                    try {
                        var iframeEl = window.parent.$("#_VIEW_IFRAME")[0];
                        var viewerWin = iframeEl.contentWindow;

                        if (viewerWin && typeof viewerWin.createAndLoadSVG === "function") {
                            var reloadUrl = dataPath + (dataPath.indexOf("?") > -1 ? "&" : "?") + "_ts=" + Date.now();

                            setTimeout(function () {
                                viewerWin.createAndLoadSVG(reloadUrl, dataTagNo);
                                $("#loadingBar").hide();
                                alert("등록에 성공했습니다 ");
                                window.parent._dataParcWinbox?.close();
                            }, 5000);
                        }
                    } catch (e) {
                        $("#loadingBar").hide();
                        console.error("도면 새로고침 중 오류:", e);
                    }
                } else {
                    $("#loadingBar").hide();
                    alert("등록에 실패했습니다.");
                }
            },
            error: function (xhr, status, err) {
                console.error("updateSvgTagId ajax error:", status, err);
                $("#loadingBar").hide();
                alert("요청 중 오류가 발생했습니다.");
            }
        });
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>