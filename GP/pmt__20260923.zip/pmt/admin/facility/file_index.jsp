<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 파일관리 화면 -->
<div class="winbox-layout page-content">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">파일관리</h1>
    
        <!-- 검색영역 -->
        <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
            <input type="hidden" name="pageIndex" id="pageIndex" value="${facilityGeniVO.pageIndex}">
            <div class="filter-panel__fields">
                <div class="form-field">
                    <label class="form-label" for="iegNo">설비 번호</label>
                    <div class="form-control-group">
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="검색어 입력 후 엔터">
                        <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly="">
                        <div class="buttons">
                            <button type="button" class="button button--secondary" onclick="fnFileUploadPop();">파일업로드</button>
                        </div>
                    </div>
    
                </div>
                <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                <datalist id="iegNoList"></datalist>

            </div>
        </form>
        
        <div class="result-panel" id="_FACILITY_FILE_LIST">
            <%-- 설비 검색 파일 리스트 --%>
        </div>
    </div>
</div>

<script src="${pageContext.request.contextPath}/resources/admin/js/file/custom-file.js"></script>
<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    /* 팝업 */
    var isUpdate = false;
    function fnFileUploadPop() {
        var box = new WinBox("파일업로드", {
            url: "/admin/facility/file/fileUploadPop.do?iegNo=${data.iegNo}",
			//width: "1000px",
			//height: "600px",
			width: Math.min(1400, window.innerWidth - 20) + "px",
			height: Math.min(720, window.innerHeight - 80) + "px",
            class: ["app-winbox"],
            position: "center",
            onresize: function(w, h) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function() {
                if(isUpdate) {
                    fnSearchFacilityFileList();
                }
            }
        });

        /* 브라우저를 조절할때 처리 */
        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }

    $(function () {
        fnSearchFacilityFileList();
    });
</script>
