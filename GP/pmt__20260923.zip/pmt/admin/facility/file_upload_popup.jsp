<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="winbox-layout page-content page-content--popup file-uploader">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">파일업로드</h1>
        
        <div class="page-content__placeholder">
            <%-- 검색영역 --%>
            <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
                <input type="hidden" name="pageIndex" id="pageIndex" value="${adminFacilityFileVO.pageIndex}">
                <div class="filter-panel__fields">
                    <div class="form-field">
                        <label class="form-label" for="iegNo">설비 번호</label>
                        <div class="form-control-group">
                            <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="설비번호, 명 검색">
                            <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly="">
                        </div>
        
                        <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                        <datalist class="_IEG_NO_LIST" id="iegNoList"></datalist>
                    </div>
                </div>
            </form>
        
            <%--<!-- 파일업로드 폼 -->--%>
            <div class="splitview">
                <aside class="splitview__pane splitview__pane--sidebar">
                    <div class="filter-panel filter-panel--with-section">
                        <div class="filter-panel__search">
                            <div class="filter-panel__fields">
                                <div class="form-field">
                                    <label class="form-label" for="fileType">파일타입 선택 및 관리</label>
                                    <div class="form-control-group">
                                        <select class="form-select" id="fileType">
                                            <option value="">파일타입을 선택하세요.</option>
                                            <c:forEach var="type" items="${typeList}" varStatus="status">
                                                <option value="${type.ieftTypeCode}">${type.ieftTypeName}</option>
                                            </c:forEach>
                                        </select>
                                        <div class="buttons">
                                            <button type="button" id="btnFileTypeForm" class="button button--primary">타입관리</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="filter-panel__section">
                            <div class="form-field">
                                <label class="form-label" for="myDropzone">파일 등록</label>
                                <form class="dropzone" id="myDropzone"></form>
                            </div>
                            <button type="button" class="button button--primary" id="btnUpload">저장</button>
                        </div>
                    </div>
                </aside>
                <div class="splitview__pane splitview__pane--content">
                    <div class="result-panel" id="_FACILITY_FILE_LIST">
                        <%-- 설비 검색 파일 리스트 --%>
                    </div>
                    
                </div>
            </div>
    
        </div>
    </div>

</div>

<%-- 파일업로드 --%>
<script>
    loadCss("${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone-5.9.3.min.css");
    loadCss("${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone.override.css");
</script>
<script src="${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone-5.9.3.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/file/custom-file.js"></script>
<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    // Dropzone 설정
    Dropzone.autoDiscover = false;  // 자동 초기화 방지
    var myDropzoneInstance = new Dropzone("#myDropzone", {
        url: "${pageContext.request.contextPath}/admin/facility/file/saveFile.upload",

		// 20260522 yjkim 썸네일이미지크기조정
		thumbnailWidth: 240,
		thumbnailHeight: 135,
		// 비율 유지 여부
		resizeWidth: 16,
		resizeHeight: 9,
        
        autoProcessQueue: false,
        parallelUploads: 1,
        maxFilesize: 10480,
        acceptedFiles: "application/zip,application/x-zip-compressed,.pdf,.jpeg,.jpg,.png,.gif,.ppt,.pptx,.hwp,.hwpx,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/x-hwp,application/haansofthwp",
        timeout: 0,
        chunking: true,
        forceChunking: true,
        chunkSize: 20971520,
        addRemoveLinks: true,
        dictDefaultMessage: "파일을 이곳에 드래그하거나 클릭하여 업로드하세요.",
        dictFallbackMessage: "브라우저가 드래그 앤 드롭 업로드를 지원하지 않습니다.",
        dictFileTooBig: "파일이 너무 큽니다 ({{filesize}}MiB). 최대 허용 크기: {{maxFilesize}}MiB.",
        dictInvalidFileType: "이미지(jpg, png, gif), ZIP(압축파일), PDF, PPT, HWP 파일만 업로드 가능합니다.",
        dictResponseError: "서버 응답 오류: {{statusCode}}",
        dictCancelUpload: "업로드 취소",
        dictCancelUploadConfirmation: "업로드를 취소하시겠습니까?",
        dictRemoveFile: "파일 삭제",
        dictMaxFilesExceeded: "더 이상 파일을 업로드할 수 없습니다.",
        init: function () {
            var isError = false;

            this.on("addedfile", function (file) {
            });

            this.on("success", function (file, response) {
                isError = false;

                if (response.result === '1') {
                    // 다음 파일 자동업로드
                    if (this.getQueuedFiles().length > 0) {
                        this.processQueue();
                    }
                }
            });

            this.on("error", function (file, errorMessage) {
                isError = true;
                myDropzoneInstance.removeFile(file);

                title = "파일업로드";

                var ext = file.name.split('.').pop().toLowerCase();
                var allowedExtensions = ["zip", "pdf", "jpg", "jpeg", "png", "gif", "ppt", "pptx", "hwp", "hwpx"];

                if (allowedExtensions.indexOf(ext) === -1) {
                    content = "해당하는 파일만 업로드 가능합니다.";
                    fnMsg();
                }
                else if(errorMessage === "") {
                    content = "오류가 발생했습니다.";
                    fnMsg();
                }

                fnBtnSaveDisabled(false);
            });

            this.on("sending", function (file, xhr, formData) {
                var iegNo = $("#iegNo").val();
                var fileType = $("#fileType").val();

                formData.append("iegNo", iegNo);
                formData.append("ieftTypeCode", fileType);

                isError = false;
            });

            this.on("queuecomplete", function () {
                fnBtnSaveDisabled(false);

                if (!isError) {
                    $.alert({
                        title: "완료", content: "모든 파일의 업로드가 완료되었습니다.", type: 'green', buttons: {
                            '확인': {
                                btnClass: 'btn-green', action: function () {
                                    myDropzoneInstance.removeAllFiles(true);

                                    $("#searchForm #pageIndex").val(1);
                                    fnSearchFacilityFileList();

                                    window.parent.isUpdate = true;
                                }
                            }
                        }
                    });
                }
            });
        }
    });

    $(function () {
        $("#btnUpload").on("click", function (e) {
            e.preventDefault();

            var contentMsg = "";
            if ($("#iegNo").val().trim() === "") {
                contentMsg = "설비번호를 검색하세요";
            } else if ($("#fileType").val().trim() === "") {
                contentMsg = "파일타입을 선택하세요";
            } else if (myDropzoneInstance.getQueuedFiles().length > 0) {
                fnBtnSaveDisabled(true);
                myDropzoneInstance.processQueue();
                return false;
            } else {
                contentMsg = "업로드할 파일을 선택하세요";
            }

            $.alert({
                title: "",
                content: contentMsg,
                animation: 'scale',
                type: 'red',
                buttons: {
                    '확인': {
                        btnClass: 'btn-red',
                        action: function () {
                            // 추가작업시
                        }
                    }
                }
            });
        });

        var isUpdateType = false;
        $("#btnFileTypeForm").on("click", function () {
            var box = new WinBox("파일 타입 설정", {
                url: "/admin/facility/file/fileTypePopup.do",
                //width: "450px",
                //height: "400px",
				width: Math.min(480, window.innerWidth - 20) + "px",
				height: Math.min(400, window.innerHeight - 80) + "px",
                class: ["app-winbox"],
                position: "center",
                onresize: function (w, h) {
                    if (this.min) return;
                    this.move("center", "center");
                },
                onclose: function () {
                    if(isUpdateType) {
                        location.reload();
                    }
                }
            });

            /* 브라우저를 조절할때 처리 */
            window.addEventListener("resize", () => {
                if (!box || !box.g) return;
                if (!box.min) {
                    box.move("center", "center");
                }
            });
        });

        /* load list */
        fnSearchFacilityFileList();
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
