<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 멀티뷰 화면 -->
<div class="winbox-layout page-content document-viewer-page">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">멀티뷰</h1>
    
        <!-- 검색영역 -->
        <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
            <div class="filter-panel__fields">
                <div class="form-field">
                    <label class="form-label" for="iegNo">설비 번호</label>
                    <div class="form-control-group">
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" value="${data.iegNo}" placeholder="검색어 입력 후 엔터">
                        <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly="">
                    </div>
                    
                    <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                    <datalist id="iegNoList"></datalist>
                </div>
            </div>
        </form>
        
        <div class="document-viewer">
            <iframe id="_MULTIVIEW_IFRAME_" src="about:blank"></iframe>
        </div>
    </div>
</div>

<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    function fnLoadMultiviewPage() {
        var iegNo = $("#iegNo").val();

        if(iegNo !== "") {
            $("#_MULTIVIEW_IFRAME_").attr("src", "${pageContext.request.contextPath}/multiview/index.do?t=F&iegNo=" + iegNo);
        }

        return false;
    }

    /**
     * 공통: 설비번호 검색
     * js callback 처리 부분
     */
    function fnSearchResult() {
        if (!isFacilityNo) {
            title = "설비 검색";
            content = "정보가 없습니다.";
            fnAlert();
        } else {
            fnLoadMultiviewPage();
        }
    }

    $(function() {
        fnLoadMultiviewPage();
    });
</script>