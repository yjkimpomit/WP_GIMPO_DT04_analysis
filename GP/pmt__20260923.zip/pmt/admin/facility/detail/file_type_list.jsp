<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 파일타입 검색 결과 화면 -->

<%--<div id="_FILE_TYPE_LIST">--%>
<div class="result-header">
    <h1 class="result-header__title">타입 설정</h1>
    <button type="button" class="button button--primary" onclick="fnAddTypeForm();">추가</button>
</div>

<div class="result-panel__body">
    <div>* 일괄 등록/수정처리합니다.</div>
    
    <form class="result-panel__fill" id="typeListForm" name="typeListForm" method="post">
        <div class="table-responsive" id="fileList">
            <table id="_TBL_LIST" class="data-table data-table--list data-table--interactive" aria-label="파일타입-리스트">
                <thead>
                <tr>
                    <th scope="col" name="excelCol" data-field="타입명">타입명</th>
                    <th scope="col" name="excelCol" data-field="관리">관리</th>
                </tr>
                </thead>
                <tbody>
                <c:if test="${empty list}">
                    <tr><td colspan="2">데이터가 없습니다.</td></tr>
                </c:if>
                <c:forEach var="data" items="${list}" varStatus="status">
                    <tr id="_TR_${data.ieftIdx}">
                        <td data-field="타입">
                            <input type="hidden" id="code_${data.ieftIdx}" name="ieftTypeCode" value="${data.ieftTypeCode}" disabled>
                            <input class="form-control" type="text" id="name_${data.ieftIdx}" name="ieftTypeName" value="${data.ieftTypeName}" disabled autocomplete="off">
                        </td>
                        <td data-field="관리">
                            <button type="button" class="button button--sm button--primary" onclick="fnModifyTypeForm('${data.ieftIdx}')">수정</button>
                            <button type="button" class="button button--sm button--destructive" onclick="fnRemoveType('${data.ieftTypeCode}');">삭제</button>
                        </td>
                    </tr>
                </c:forEach>
                </tbody>
            </table>
        </div>
    </form>
</div>
<%--</div>--%>
