<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비검색 결과 정보 -->
<%--<div id="_FACILITY_DETAIL_VIEW_INFO">--%>
<c:if test="${empty data}">
    <div class="result-panel__body">
        <div class="no-data">설비번호를 검색하세요.</div>
    </div>
</c:if>

<c:if test="${not empty data}">
    <%-- 설비상세 정보 뷰 --%>
    <div class="result-panel__body" id="_DIV_FACILITY_INFO_VIEW">
        <div class="splitview panel-split-layout panel-split-layout--two-to-one">
            <div class="splitview__pane splitview__pane--sidebar panel-split-layout__sidebar" aria-label="설비상세 정보">
                <section class="panel-split-layout__group panel-split-layout__group--primary">
                    <div class="result-header">
                        <h2 class="result-header__title">설비상세 정보</h2>
                    </div>
                    <div class="table-responsive">
                        <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="설비상세">
                            <colgroup>
                                <col style="width: 200px;">
                                <col>
                            </colgroup>
                            <tbody>
                            <tr>
                                <th scope="row">설비명</th>
                                <td data-field="설비명">${data.iegDecription}</td>
                            </tr>
                            <tr>
                                <th scope="row">설비번호</th>
                                <td data-field="설비번호">${data.iegNo}</td>
                            </tr>
                            <tr>
                                <th scope="row">설비레벨</th>
                                <td data-field="설비레벨">${data.iegLevel}</td>
                            </tr>
                            <tr>
                                <th scope="row">3D 모델 연결여부</th>
                                <td data-field="3D 모델 연결여부">
                                    <c:choose>
                                        <c:when test="${not empty data.isModel}">Y</c:when>
                                        <c:otherwise>N</c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">파노라마 연결여부</th>
                                <td data-field="파노라마 연결여부">
                                    <c:choose>
                                        <c:when test="${not empty data.isPanorama}">Y</c:when>
                                        <c:otherwise>N</c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">P&ID 연결여부</th>
                                <td data-field="P&ID 연결여부">
                                    <c:choose>
                                        <c:when test="${not empty data.isPnid}">Y</c:when>
                                        <c:otherwise>N</c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">dataPARC 연결여부</th>
                                <td data-field="dataPARC 연결여부">
                                    <c:choose>
                                        <c:when test="${not empty data.isDataparc}">Y</c:when>
                                        <c:otherwise>N</c:otherwise>
                                    </c:choose>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>
                </section>
            </div>
    
            <div class="splitview__pane splitview__pane--content panel-split-layout__content" role="region" aria-label="설비사진">
                <section class="panel-split-layout__group panel-split-layout__group--primary">
                    <div class="result-header">
                        <h2 class="result-header__title">설비 사진</h2>
                    </div>
                    <div class="facility-photo">
                        <img id="equipImage" src="/modelImages/${data.iegNo}.jpg?t=${System.currentTimeMillis()}" alt="${data.iegNo}" class="img-fluid">
                    </div>
                </section>
            </div>
        </div>
    </div>
    
    <%-- 설비 상세 정보 수정 폼 --%>
    <div class="result-panel__body d-none" id="_DIV_FACILITY_INFO_FORM">
        <form class="result-panel__body" id="facilityInfoForm" name="facilityInfoForm" action="javascript:fnSaveInfo()" method="post" enctype="multipart/form-data">
            <input type="hidden" name="tmpIegNo" value="${data.iegNo}">
            <input type="hidden" name="iegNo" value="${data.iegNo}">
            <input type="hidden" name="iegLevel" value="${data.iegLevel}">
            <div class="splitview panel-split-layout panel-split-layout--two-to-one">
                <div class="splitview__pane splitview__pane--sidebar panel-split-layout__sidebar">
                    <section class="panel-split-layout__group panel-split-layout__group--primary">
                        <div class="result-header">
                            <h2 class="result-header__title">설비상세 정보 수정</h2>
                        </div>
    
                        <div class="table-responsive">
                            <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="설비상세 폼">
                                <colgroup>
                                    <col style="width: 200px;">
                                    <col>
                                </colgroup>
                                <tbody>
                                <tr>
                                    <th scope="row">설비명</th>
                                    <td data-field="설비명">
                                        <label for="iegDecription" class="visually-hidden">설비명</label>
                                        <input type="text" class="form-control" id="iegDecription" name="iegDecription" value="${data.iegDecription}" required>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">설비번호</th>
                                    <td data-field="설비번호">${data.iegNo}<%--<input type="text" class="form-control" name="iegNo" value="${data.iegNo}" readonly>--%></td>
                                </tr>
                                <tr>
                                    <th scope="row">설비레벨</th>
                                    <td data-field="설비레벨">${data.iegLevel}<%--<input type="number" class="form-control" name="iegLevel" value="${data.iegLevel}" disabled>--%></td>
                                </tr>
                                <tr>
                                    <th scope="row">3D 모델 연결여부</th>
                                    <td data-field="3D 모델 연결여부">
                                        <c:choose>
                                            <c:when test="${not empty data.isModel}">Y</c:when>
                                            <c:otherwise>N</c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">파노라마 연결여부</th>
                                    <td data-field="파노라마 연결여부">
                                        <c:choose>
                                            <c:when test="${not empty data.isPanorama}">Y</c:when>
                                            <c:otherwise>N</c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">P&ID 연결여부</th>
                                    <td data-field="P&ID 연결여부">
                                        <c:choose>
                                            <c:when test="${not empty data.isPnid}">Y</c:when>
                                            <c:otherwise>N</c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                                <tr>
                                    <th scope="row">dataPARC 연결여부</th>
                                    <td data-field="dataPARC 연결여부">
                                        <c:choose>
                                            <c:when test="${not empty data.isDataparc}">Y</c:when>
                                            <c:otherwise>N</c:otherwise>
                                        </c:choose>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </section>
                </div>

                <div class="splitview__pane splitview__pane--content panel-split-layout__content">
                    <section class="panel-split-layout__group panel-split-layout__group--primary">
                        <div class="result-header">
                            <h2 class="result-header__title">설비 사진</h2>
                            <button type="button" class="button button--attention" onclick="btnSaveFacility()">저장</button>
                        </div>
                        
                        <div class="facility-photo">
                            <div class="dropzone" id="myDropzone"></div>
                        </div>
                    </section>
                </div>
            </div>
        </form>
    </div>

    <%-- GENi 설비상세 정보 --%>
    <div class="result-group" style="flex-grow: 0;">
        <div class="result-header">
            <h2 class="result-header__title">GENi 설비상세 정보</h2>
        </div>
        <div class="table-responsive">
            <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="설비상세">
                <colgroup>
                    <col style="width: 200px;">
                    <col style="width: 240px;">
                    <col style="width: 200px;">
                    <col>
                    <col style="width: 160px;">
                    <col style="width: 200px;">
                </colgroup>
                <tbody>
                <tr>
                    <th scope="row">설비번호</th>
                    <td data-field="설비번호">${dataGeni.equipNo}</td>
                    <th scope="row">설비명</th>
                    <td data-field="설비명">${dataGeni.description}</td>
                    <th scope="row">상태</th>
                    <td data-field="상태">${dataGeni.eqStatus}</td>
                </tr>
                <tr>
                    <th scope="row">기능위치번호</th>
                    <td data-field="기능위치번호">${dataGeni.locNo}</td>
                    <th scope="row">기능위치명</th>
                    <td data-field="기능위치명" colspan="3">${dataGeni.locNm}</td>
                </tr>
                <tr>
                    <th scope="row">계통코드</th>
                    <td data-field="계통코드">${dataGeni.eqCategory}</td>
                    <th scope="row">계통코드명</th>
                    <td data-field="계통코드명" colspan="3">${dataGeni.eqCategoryNm}</td>
                </tr>
                <tr>
                    <th scope="row">종류코드</th>
                    <td data-field="종류코드">${dataGeni.eqType}</td>
                    <th scope="row">종류코드명</th>
                    <td data-field="종류코드명" colspan="3">${dataGeni.eqTypeNm}</td>
                </tr>
                <tr>
                    <th scope="row">TAG_NO</th>
                    <td data-field="TAG_NO">${dataGeni.tagNo}</td>
                    <th scope="row">PNID_NO</th>
                    <td data-field="PNID_NO" colspan="3">${dataGeni.pnidNo}</td>
                </tr>
                <tr>
                    <th scope="row">자산번호</th>
                    <td data-field="자산번호">${dataGeni.assetNo}</td>
                    <th scope="row">자산명</th>
                    <td data-field="자산명" colspan="3">${dataGeni.assetNm}</td>
                </tr>
                <tr>
                    <th scope="row">계층구조</th>
                    <td data-field="계층구조" colspan="5">${dataGeni.labelInfo}</td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
    <%--</div>--%>

    <%-- 파일업로드 --%>
    <script>
        loadCss("${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone-5.9.3.min.css");
        loadCss("${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone.override.css");
    </script>
    <script src="${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone-5.9.3.min.js"></script>
    <script src="${pageContext.request.contextPath}/resources/admin/js/file/custom-file.js"></script>
    <script>
        // Dropzone 설정
        Dropzone.autoDiscover = false;  // 자동 초기화 방지
        var myDropzoneInstance = new Dropzone("#myDropzone", {
            url: "${pageContext.request.contextPath}/admin/facility/file/saveFile.upload",

			// 20260522 yjkim 썸네일이미지크기조정
			thumbnailWidth: 400,
			thumbnailHeight: 225,
			// 비율 유지 여부
/* 			resizeWidth: 16,
			resizeHeight: 9, */
			
			// 업로드 해상도 설정
			resizeWidth: 960,
			resizeHeight: 540,
			
            maxFiles: 1,
            autoProcessQueue: false,
            parallelUploads: 1,
            maxFilesize: 5,
            acceptedFiles: ".jpeg,.jpg,.png,.gif",
            timeout: 0,
            chunking: true,
            forceChunking: true,
            chunkSize: 20971520,
            addRemoveLinks: true,
            dictDefaultMessage: "이미지 파일을 이곳에 드래그하거나 클릭하여 업로드하세요.",
            dictFallbackMessage: "브라우저가 드래그 앤 드롭 업로드를 지원하지 않습니다.",
            dictFileTooBig: "파일이 너무 큽니다 ({{filesize}}MiB). 최대 허용 크기: {{maxFilesize}}MiB.",
            dictInvalidFileType: "이미지(jpg, png, gif) 파일만 업로드 가능합니다.",
            dictResponseError: "서버 응답 오류: {{statusCode}}",
            dictCancelUpload: "업로드 취소",
            dictCancelUploadConfirmation: "업로드를 취소하시겠습니까?",
            dictRemoveFile: "파일 삭제",
            dictMaxFilesExceeded: "더 이상 파일을 업로드할 수 없습니다.",
            init: function () {
                var isError = false;

                this.on("addedfile", function (file) {
                });

                this.on("success", function (file, response) {
                    isError = false;

                    if (response.result === '1') {
                        // 다음 파일 자동업로드
                        if (this.getQueuedFiles().length > 0) {
                            this.processQueue();
                        }
                    }
                });

                this.on("error", function (file, errorMessage) {
                    isError = true;
                    myDropzoneInstance.removeFile(file);

                    title = "파일업로드";

                    var ext = file.name.split('.').pop().toLowerCase();
                    var allowedExtensions = ["jpg", "jpeg", "png", "gif"];

                    if (allowedExtensions.indexOf(ext) === -1) {
                        content = "미미지 파일만 업로드 가능합니다.";
                        fnMsg();
                    }
                    else if(errorMessage === "") {
                        content = "오류가 발생했습니다.";
                        fnMsg();
                    }
                });

                this.on("sending", function (file, xhr, formData) {
                    formData.append("actionType", "facilityImage");
                    formData.append("iegNo", "${data.iegNo}");

                    isError = false;
                });

                this.on("queuecomplete", function () {
                    if (!isError) {
                        $.alert({
                            title: "완료", content: "정상적으로 처리되었습니다.", type: 'green', buttons: {
                                '확인': {
                                    btnClass: 'btn-green', action: function () {
                                        myDropzoneInstance.removeAllFiles(true);

                                        /* reload page */
                                        fnSearchFacilityInfo();
                                    }
                                }
                            }
                        });
                    }
                });
            }
        });

        function btnSaveFacility() {
            content = "";

            if ($("#iegDecription").val().trim() === "") {
                content = "설비명을 입력하세요.";
                title = "";
                fnMsg();
            } else {
                fnSaveInfo();
            }
        }

        $(function () {
            // 수정버튼 보기
            $("#_DIV_BTN_AREA").removeClass("d-none");
        });
    </script>
</c:if>
