<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보 탭 화면 -->
<div class="winbox-layout page-content">
    <div class="page-content__placeholder">
        <h1 class="page-content__heading visually-hidden">설비정보</h1>
        
        <!-- 검색영역 -->
        <form class="filter-panel" id="searchForm" method="post" autocomplete="off">
            <div class="filter-panel__fields">
                <div class="form-field">
                    <label class="form-label" for="iegNo">설비 번호</label>
                    <div class="form-control-group">
                        <input class="form-control form-control--return" list="iegNoList" id="iegNo" name="searchKeyword" placeholder="설비번호, 명 입력 후 엔터">
                        <input type="hidden" id="iegCode">
                    
                    <%-- ul 부분은 전체 자동으로 생성되는 부분이라, 데이터 연동 후 제거하시면 됩니다. --%>
                    <%--<ul id="" tabindex="0" class="ui-menu ui-widget ui-widget-content ui-autocomplete ui-front" style="top: auto; left: auto; width: 480px; display: block; border-radius: .5rem;">
                        <li class="ui-menu-item">
                            <div id="ui-id-6" tabindex="-1" class="ui-menu-item-wrapper">
                                <strong class="fac-code">16794190</strong>
                                <span class="fac-label">#9 PSH Metal TE-1157</span>
                            </div>
                        </li>
                        <li class="ui-menu-item">
                            <div id="ui-id-7" tabindex="-1" class="ui-menu-item-wrapper">
                                <strong class="fac-code">16797800</strong>
                                <span class="fac-label">#9 Final SH Tube Metal TE-1570</span>
                            </div>
                        </li>
                        <li class="ui-menu-item">
                            <div id="ui-id-8" tabindex="-1" class="ui-menu-item-wrapper">
                                <strong class="fac-code">16797810</strong>
                                <span class="fac-label">#9 Final SH Tube Metal TE-1571</span>
                            </div>
                        </li>
                    </ul>--%>
                    <%-- 자동생성 끝 --%>
                        <input class="form-control" type="text" id="iegDescription" value="${data.iegDecription}" readonly="">
                        
                        <div class="buttons d-none" id="_DIV_BTN_AREA">
                            <button type="button" class="button button--secondary" onclick="fnModifyInfoForm(this);">수정</button>
                        </div>
                    </div>

                    <%-- 설비정보가 2개 이상인 경우 보여줌 --%>
                    <datalist id="iegNoList"></datalist>
                </div>
            </div>
        </form>
        
        <div class="result-panel result-panel--master-detail" id="_FACILITY_DETAIL_VIEW_INFO">
           <%-- 설비검색 결과 화면 --%>
        </div>
    </div>
</div>

<script>
    /* 설비검색 이벤트 */
    fnInitCustomFacilitySearch();

    function fnModifyInfoForm(button) {
        if($("#_DIV_FACILITY_INFO_FORM").hasClass("d-none")) {
            $("#_DIV_FACILITY_INFO_FORM").removeClass("d-none");
            $("#_DIV_FACILITY_INFO_VIEW").addClass("d-none");
			$(button).text("취소");
        }
        else {
            $("#_DIV_FACILITY_INFO_VIEW").removeClass("d-none");
            $("#_DIV_FACILITY_INFO_FORM").addClass("d-none");
			$(button).text("수정");
        }
    }

    /* 설비정보 저장 */
    function fnSaveInfo() {
        var form = $('#facilityInfoForm')[0];
        var formData = new FormData(form);

        $.confirm({
            title: "수정",
            content: "저장하시겠습니까?",
            type: 'blue',
            buttons: {
                '확인': {
                    btnClass: 'btn-blue',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/facility/saveInfo.do",
                            data: formData,
                            processData: false,
                            contentType: false,
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if(data.result === '1') {
                                    if (myDropzoneInstance.getQueuedFiles().length > 0) {
                                        // 파일업로드
                                        myDropzoneInstance.processQueue();
                                    }
                                    else {
                                        fnSearchFacilityInfo();

                                        title = "완료";
                                        content = "정상적으로 처리되었습니다.";
                                        fnAlert();
                                    }
                                }
                                else if(data.result === '0') {
                                    title = "수정";
                                    content = "수정할 정보가 없습니다.";
                                    fnAlert();
                                }
                                else {
                                    title = "저장";
                                    content = "오류가 발생했습니다.";
                                    fnAlert();
                                }
                            },
                            error: function (request, status, error) {
                                title = "저장";
                                content = "오류가 발생했습니다.";
                                fnAlert();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    /**
     * 설비정보 조회
     */
    function fnSearchFacilityInfo() {
        $.ajax({
            type: "POST",
            url: "/admin/facility/searchInfo.do",
            data: $("#searchForm").serialize(),
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_FACILITY_DETAIL_VIEW_INFO").html(data);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /**
     * 공통: 설비번호 검색
     * js callback 처리 부분
     */
    function fnSearchResult() {
        if (!isFacilityNo) {
            title = "설비 검색";
            content = "설비정보가 없습니다.";
            fnAlert();
        } else {
            fnSearchFacilityInfo();
        }
    }

    $(function () {
        <c:if test="${not empty facilityGeniVO.iegNo}">
            $("#iegNo").val('${facilityGeniVO.iegNo}');
        </c:if>

        // 초기 로드
        fnSearchFacilityInfo();
    });
</script>
