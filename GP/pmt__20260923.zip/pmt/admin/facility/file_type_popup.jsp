<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%--<!-- 파입타입 화면 -->--%>
<main class="winbox-layout page-content page-content--popup">
    <div class="page-content__placeholder">
        <div class="result-panel" id="_FILE_TYPE_LIST">
            <%-- 파일 타입 리스트 --%>
        </div>

        <%-- 추가 폼 양식 --%>
        <div class="d-none" id="_ADD_FORM">
            <table>
                <tbody>
                <tr>
                    <td data-field="유형">
                        <input type="hidden" name="ieftTypeCode" value="ADD">
                        <input class="form-control" type="text" name="targetName" autocomplete="off">
                    </td>
                    <td data-field="기능">
                        <button type="button" class="button button--sm button--primary" onClick="fnAddType()">등록</button>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
        
    </div>
</main>

<script>
    var title = "", content = "";
    var targetName = "", targetNameVal = "";

    function fnError() {
        $.alert({
            title: title,
            content: content,
            type: 'red',
            buttons: {
                '확인': {
                    btnClass: 'btn-red',
                    action: function () {
                    }
                }
            }
        });
    }

    function fnSearchFileTypeList() {
        $.ajax({
            type: "POST",
            url: "/admin/facility/file/fileTypeList.do",
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                $("#_FILE_TYPE_LIST").html(data);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    function fnSaveType() {
        var isRun = true;

        $("[name=ieftTypeName]").each(function () {
            var val = $(this).val().trim();

            if (val === "") {
                title = "필수입력";
                content = "타입명을 입력하세요";
                fnError();
                isRun = false;
            }
            else {
                if (val.indexOf(",") > -1) {
                    title = "필수입력";
                    content = ",(콤마)는 사용할 수 없습니다.";
                    fnError();
                    isRun = false;
                }
            }
        });

        if(!isRun) return false;

        $.confirm({
            title: title,
            content: content,
            type: 'blue',
            buttons: {
                '확인': {
                    btnClass: 'btn-blue',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/facility/file/saveFileType.do",
                            data: $("#typeListForm").serialize(),
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result > 0) {
                                    $.alert({
                                        title: "완료",
                                        content: "정상적으로 처리되었습니다.",
                                        type: 'green',
                                        buttons: {
                                            '확인': {
                                                btnClass: 'btn-green',
                                                action: function () {
                                                    fnSearchFileTypeList();
                                                }
                                            }
                                        }
                                    });
                                    window.parent.isUpdateType = true;
                                }
                                else {
                                    title = "오류";
                                    content = "오류가 발생했습니다.";
                                    fnError();
                                }
                            },
                            error: function () {
                                title = "오류";
                                content = "오류가 발생했습니다.";
                                fnError();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    function fnAddType() {
        title = "타입 등록";
        content = "등록하시겠습니까?";
        fnSaveType();
    }

    /* 등록 폼 추가 */
    function fnAddTypeForm() {
        var $newRow = $("#_ADD_FORM").find("tr").clone();
        $newRow.find("input[name=targetName]").attr("name", "ieftTypeName");
        $("#_TBL_LIST tbody").append($newRow);
        $newRow.find("input[name=ieftTypeName]").focus();
    }

    /* 수정 폼 */
    function fnModifyTypeForm(target) {
        var targetCode = $("#code_" + target);
        targetName = $("#name_" + target);

        if ($(targetName).attr('disabled')) {
            $(targetCode).attr("disabled", false);
            $(targetName).attr("disabled", false);
            $("#_TR_" + target).find('td:last').find('button:first').removeClass('btn-success').addClass('btn-danger');
        }
        else {
            title = "타입명 수정";
            content = "수정하시겠습니까?";
            fnSaveType();
        }
    }

    /* 삭제 처리 */
    function fnRemoveType(targetCode) {
        title = "타입 삭제";
        content = "삭제하시겠습니까?";

        $.confirm({
            title: title,
            content: content,
            type: 'blue',
            buttons: {
                '확인': {
                    btnClass: 'btn-blue',
                    action: function () {
                        $.ajax({
                            type: "POST",
                            url: "/admin/facility/file/removeFileType.do",
                            data: {typeCodeList: targetCode},
                            dataType: "json",
                            beforeSend: function () {
                                $("#loadingBar").show();
                            },
                            success: function (data) {
                                if (data.result > 0) {
                                    $.alert({
                                        title: "완료",
                                        content: "정상적으로 처리되었습니다.",
                                        type: 'green',
                                        buttons: {
                                            '확인': {
                                                btnClass: 'btn-green',
                                                action: function () {
                                                    fnSearchFileTypeList();
                                                }
                                            }
                                        }
                                    });
                                    window.parent.isUpdateType = true;
                                }
                                else {
                                    title = "오류";
                                    content = "오류가 발생했습니다.";
                                    fnError();
                                }
                            },
                            error: function () {
                                title = "오류";
                                content = "오류가 발생했습니다.";
                                fnError();
                            },
                            complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                },
                '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    $(function () {
        fnSearchFileTypeList();
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
