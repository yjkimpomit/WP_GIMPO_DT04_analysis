<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<script>
    /* admin global var */
    var isAdmin = true;
</script>

<body class="admin-sub">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%-- 헤더 시작 --%>
<div class="admin-header">
    <c:import url="/admin/common/topManage.do"/>
</div>
<%-- 헤더 끝 --%>

<div class="contents-panel">
</div>

<script>
    $(function () {
        var target = $('<input type="hidden" id="_openServicePopup" data-title="개선사항"/>');
        fnOpenPopup('/serviceinfo/index.do', target);
        target.remove();
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
