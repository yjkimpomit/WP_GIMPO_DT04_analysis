<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body>

<script>
	/* admin global var */
	var isAdmin = true;
</script>

<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="admin-shell">

    <%-- 헤더 시작 --%>
    <c:import url="/admin/common/top.do"/>
    <%-- 헤더 끝 --%>
    
    <main>
        
        <aside aria-label="관리 메뉴">
            <div>
                <section class="equipment-search" role="search" aria-label="관리 메뉴 탐색">
                    <div class="equipment-search__controls">
                        <label class="visually-hidden" for="facSelect">검색옵션 선택</label>
                        <select class="form-select equipment-search__type" id="facSelect">
                            <option value="1">설비</option>
                            <option value="2">부품</option>
                        </select>
                        <label for="facSearchInput" class="visually-hidden">설비명 입력</label>
                        <input type="text" class="form-control form-control--return" list="datalistOptions" id="facSearchInput" placeholder="설비 번호, 명 입력">
                        <button type="button" class="equipment-search__expand-button is-collapsed" id="facSearchButton" aria-label="트리 전체 펼치기"></button>
                        <datalist id="datalistOptions"></datalist>
                    </div>
                    <div class="jstree-box" role="region" aria-label="설비 zTree 영역">
                        <div class="loading-box" id="facLoadingBar" style="display: none;">
                            <div class="loader"></div>
                        </div>
                        <ul id="facTree" class="ztree"></ul>
                    </div>
                </section>
            </div>
            <button type="button" data-panel-toggle aria-expanded="false" aria-label="좌측 패널 열기"></button>
        </aside>
        
        <section class="admin-content" aria-label="관리 콘텐츠">
            <div class="tabs">
                
                <!-- tab-menu -->
                <ul class="nav nav-tabs" id="dataTab" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE active" id="facilityTab" data-bs-toggle="tab" data-bs-target="#facilityTabPane" type="button" role="tab" aria-controls="facilityTabPane" aria-selected="true" data-page="/admin/facility/index.do">설비정보</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="modelTab" data-bs-toggle="tab" data-bs-target="#modelTabPane" type="button" role="tab" aria-controls="modelTabPane" aria-selected="false" data-page="/admin/model/index.do" tabindex="-1">3D 모델</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="panoramaTab" data-bs-toggle="tab" data-bs-target="#panoramaTabPane" type="button" role="tab" aria-controls="panoramaTabPane" aria-selected="false" data-page="/admin/panorama/index.do" tabindex="-1">파노라마</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="pnidTab" data-bs-toggle="tab" data-bs-target="#pnidTabPane" type="button" role="tab" aria-controls="pnidTabPane" aria-selected="false" data-page="/admin/pnid/index.do" tabindex="-1">P&ID</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="dataparcTab" data-bs-toggle="tab" data-bs-target="#dataparcTabPane" type="button" role="tab" aria-controls="dataparcTabPane" aria-selected="false" data-page="/admin/dataparc/index.do" tabindex="-1">dataPARC</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="fileTab" data-bs-toggle="tab" data-bs-target="#fileTabPane" type="button" role="tab" aria-controls="fileTabPane" aria-selected="false" data-page="/admin/facility/file/index.do" tabindex="-1">파일관리</button>
                    </li>
                    <%--<li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="multiviewTab" data-bs-toggle="tab" data-bs-target="#multiviewTabPane" type="button" role="tab" aria-controls="multiviewTabPane" aria-selected="false" data-page="/admin/facility/multiview.do" tabindex="-1">멀티뷰</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _TAB_PAGE" id="logsheetTab" data-bs-toggle="tab" data-bs-target="#logsheetTabPane" type="button" role="tab" aria-controls="logsheetTabPane" aria-selected="false" data-page="/admin/logsheet/index.do" tabindex="-1">LogSheet</button>
                    </li>--%>
                </ul>
    
                <!-- tab content -->
                <div class="tab-content" id="dataTabContent">
                    <div class="tab-pane fade _TAB_CONTENT active show" id="facilityTabPane" role="tabpanel" aria-labelledby="facilityTab" tabindex="0">
                        <%-- 설비정보 화면 --%>
                        <c:import url="/admin/facility/index.do"/>
                    </div>
                    <div class="tab-pane fade _TAB_CONTENT" id="modelTabPane" role="tabpanel" aria-labelledby="modelTab" tabindex="0">
                        <%-- 3d model 화면 --%>
                    </div>
                    <div class="tab-pane fade _TAB_CONTENT" id="panoramaTabPane" role="tabpanel" aria-labelledby="panoramaTab" tabindex="0">
                        <%-- 파노라마 화면 --%>
                    </div>
                    <div class="tab-pane fade _TAB_CONTENT" id="pnidTabPane" role="tabpanel" aria-labelledby="pnidTab" tabindex="0">
                        <%-- P&ID 화면 --%>
                    </div>
                    <div class="tab-pane fade _TAB_CONTENT" id="dataparcTabPane" role="tabpanel" aria-labelledby="dataparcTab" tabindex="0">
                        <%-- dataPARC 화면 --%>
                    </div>
                    <div class="tab-pane fade _TAB_CONTENT" id="fileTabPane" role="tabpanel" aria-labelledby="fileTab" tabindex="0">
                        <%-- file&doc 화면 --%>
                    </div>
                    <%--<div class="tab-pane fade _TAB_CONTENT" id="multiviewTabPane" role="tabpanel" aria-labelledby="multiviewTab" tabindex="0">
                        &lt;%&ndash; 결과 화면 &ndash;%&gt;
                    </div>
                    <div class="tab-pane fade _TAB_CONTENT" id="logsheetTabPane" role="tabpanel" aria-labelledby="logsheetTabPane" tabindex="0">
                        &lt;%&ndash; logsheet 화면 &ndash;%&gt;
                    </div>--%>
                </div>
                
            </div>
        </section>
    </main>

</div>

<%-- 설비트리 리스트 --%>
<script src="${pageContext.request.contextPath}/resources/admin/js/facility/facility-master.js"></script>
<script>
    var iegNo = "";

    // view content
    function fnLoadTabContent($btn) {
        // 대상 탭 버튼/패널
        var targetContentId = $btn.attr('data-bs-target');
        var targetUrl = $btn.attr('data-page');

        if (!targetContentId || !targetUrl) return;

        // 기존 콘텐츠 정리
        if (typeof unityObj !== "undefined") {
            fnCloseUnity();
        }

        // winbox 모두 닫기
        if($(".winbox") !== "undefined") {
            $(".wb-close").trigger('click');
        }

        // 내용 비우기
        $('._TAB_CONTENT').empty();

        $.ajax({
            url: targetUrl,
            type: "POST",
            data: {iegNo: iegNo},
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").css("display", "");
            },
            success: function (data) {
                $(targetContentId).html(data);
            },
            error: function (request, status, error) {
                alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    function fnReloadTabPage(no) {
        iegNo = no;

        if ($("._TAB_PAGE").is(".active")) {
            // filter를 통해 active 상태인 요소만 골라내어 전달
            fnLoadTabContent($("._TAB_PAGE").filter(".active"));
        }
    }

    $(document).ready(function () {
        // 탭 클릭 시: Bootstrap 탭 전환 + Ajax 로딩
        $('._TAB_PAGE').on('click', function (e) {
            e.preventDefault();
            fnLoadTabContent($(this));
        });
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
