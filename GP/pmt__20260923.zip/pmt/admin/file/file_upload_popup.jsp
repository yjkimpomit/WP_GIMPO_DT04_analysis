<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<body class="admin-popup">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="contents-box">
    
    <div class="uploader-box">
        <div class="title-box">
            <h3 class="title03">파일업로드</h3>
            
            <button type="button" class="btn btn-primary" id="btnUpload">
                <span>저장</span>
            </button>
        </div>
    
        <%--<!-- 파일업로드 폼 -->--%>
        <div class="file-uploader" aria-label="파일업로드 폼">
            <form class="dropzone" id="myDropzone"></form>
        </div>
    </div>
    
</div>

<%-- 파일업로드 --%>
<script>
    loadCss("${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone-5.9.3.min.css");
    loadCss("${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone.override.css");
</script>
<script src="${pageContext.request.contextPath}/resources/admin/js/fileupload/dropzone-5.9.3.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/admin/js/file/custom-file.js"></script>
<script>
    // Dropzone 설정
    Dropzone.autoDiscover = false;  // 자동 초기화 방지
    var myDropzoneInstance = new Dropzone("#myDropzone", {
        url: "${pageContext.request.contextPath}/admin/file/saveUploadFile.do",
        
        // 20260522 yjkim 썸네일이미지크기조정
		thumbnailWidth: 800,
		thumbnailHeight: 450,
  
		// 비율 유지 여부
		resizeWidth: 16,
		resizeHeight: 9,
        
        autoProcessQueue: false,
        parallelUploads: 1,
        maxFilesize: 10480,
        acceptedFiles: "application/zip,application/x-zip-compressed,.alz,.pdf,.jpeg,.jpg,.png,.gif,.ppt,.pptx,.hwp,.hwpx,application/vnd.ms-powerpoint,application/vnd.openxmlformats-officedocument.presentationml.presentation,application/x-hwp,application/haansofthwp",
        timeout: 0,
        chunking: true,
        forceChunking: true,
        chunkSize: 20971520,
        addRemoveLinks: true,
        dictDefaultMessage: "파일을 이곳에 드래그하거나 클릭하여 업로드하세요.",
        dictFallbackMessage: "브라우저가 드래그 앤 드롭 업로드를 지원하지 않습니다.",
        dictFileTooBig: "파일이 너무 큽니다 ({{filesize}}MiB). 최대 허용 크기: {{maxFilesize}}MiB.",
        dictInvalidFileType: "이미지(jpg, png, gif), ZIP(압축파일), PDF, PPT, HWP 파일만 업로드 가능합니다.",
        dictResponseError: "서버 응답 오류: {{statusCode}}",
        dictCancelUpload: "업로드 취소",
        dictCancelUploadConfirmation: "업로드를 취소하시겠습니까?",
        dictRemoveFile: "파일 삭제",
        dictMaxFilesExceeded: "더 이상 파일을 업로드할 수 없습니다.",
        init: function () {
            var isError = false;

            this.on("success", function (file, response) {
                isError = false;

                if (response.result === '1') {
                    // 다음 파일 자동업로드
                    if (this.getQueuedFiles().length > 0) {
                        this.processQueue();
                    }
                }
            });

            this.on("error", function (file, errorMessage) {
                isError = true;
                myDropzoneInstance.removeFile(file);

                title = "파일업로드";

                var ext = file.name.split('.').pop().toLowerCase();
                var allowedExtensions = ["alz", "zip", "pdf", "jpg", "jpeg", "png", "gif", "ppt", "pptx", "hwp", "hwpx"];

                if (allowedExtensions.indexOf(ext) === -1) {
                    content = "해당하는 파일만 업로드 가능합니다.";
                    fnMsg();
                }
                else if(errorMessage === "") {
                    content = "오류가 발생했습니다.";
                    fnMsg();
                }

                fnBtnSaveDisabled(false);
            });

            this.on("sending", function (file, xhr, formData) {
                isError = false;
            });

            this.on("queuecomplete", function () {
                fnBtnSaveDisabled(false);

                if (!isError) {
                    $.alert({
                        title: "완료", content: "모든 파일의 업로드가 완료되었습니다.", type: 'green', buttons: {
                            '확인': {
                                btnClass: 'btn-green', action: function () {
                                    myDropzoneInstance.removeAllFiles(true);
                                }
                            }
                        }
                    });
                }
            });
        }
    });

    $(function () {
        $("#btnUpload").on("click", function (e) {
            e.preventDefault();

            var contentMsg = "업로드할 파일을 선택하세요";

            if (myDropzoneInstance.getQueuedFiles().length > 0) {
                fnBtnSaveDisabled(true);
                myDropzoneInstance.processQueue();
                return false;
            }

            $.alert({
                title: "",
                content: contentMsg,
                animation: 'scale',
                type: 'red',
                buttons: {
                    '확인': {
                        btnClass: 'btn-red',
                        action: function () {
                            // 추가작업시
                        }
                    }
                }
            });
        });
    });
</script>
</body>
<c:import url="/admin/common/footer.do"/>
