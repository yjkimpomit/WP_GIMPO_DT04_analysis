<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/admin/common/header.do"/>

<script>
    /* admin global var */
    var isAdmin = true;
</script>

<body class="admin-sub">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%-- 헤더 시작 --%>
<div class="admin-header">
    <c:import url="/admin/common/top.do"/>
</div>
<%-- 헤더 끝 --%>

<!-- 파일관리 화면 -->
<div class="contents-box">
    <h3 class="title02">파일관리</h3>

    <!-- 검색영역 -->
    <div class="text-center p-3">
        <form id="searchForm" method="post" autocomplete="off">
            <input type="hidden" name="pageIndex" id="pageIndex" value="${facilityGeniVO.pageIndex}">
            <button type="button" class="btn btn-primary" onclick="fnFileUploadPop();">
                <span class="icon-upload"></span>
                <span>파일업로드</span>
            </button>
        </form>
    </div>
</div>

<script src="${pageContext.request.contextPath}/resources/admin/js/file/custom-file.js"></script>
<script>
    /* 팝업 */
    function fnFileUploadPop() {
        var box = new WinBox("파일업로드", {
            url: "/admin/file/fileUploadPop.do",
            //width: "1000px",
            //height: "600px",
			width: Math.min(1400, window.innerWidth - 20) + "px",
			height: Math.min(600, window.innerHeight - 80) + "px",
            class: ["no-full"],
            position: "center",
            onresize: function (w, h) {
                if (this.min) return;
                this.move("center", "center");
            }
        });

        /* 브라우저를 조절할때 처리 */
        window.addEventListener("resize", () => {
            if (!box || !box.g) return;
            if (!box.min) {
                box.move("center", "center");
            }
        });
    }
</script>
</body>
<c:import url="/admin/common/footer.do"/>
