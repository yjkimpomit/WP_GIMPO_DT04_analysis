<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 파일관리 검색 결과 화면 -->

<script>
    var totalPage = ${paginationInfo.totalPageCount};
</script>

<c:if test="${empty list}">
    <div class="gray-box my-3" style="min-height: 64px;">
        <c:choose>
            <c:when test="${not empty adminFacilityFileVO.searchKeyword}">
                <span>파일이 없습니다.</span>
            </c:when>
            <c:otherwise>
                <span>설비번호를 검색하세요.</span>
            </c:otherwise>
        </c:choose>
    </div>
</c:if>

<c:if test="${not empty list}">
    <%--<div id="_FILE_LIST">--%>
    <div class="title-box my-3" id="divSearchResult">
        <h4 class="title04">조회 결과<small id="searchResultCnt">(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h4>

        <div>
            <div class="page-move">
                <label for="currentPage" class="visually-hidden">이동할 페이지</label>
                <input type="number" id="currentPage" class="form-control page" value="<c:out value='${paginationInfo.currentPageNo}'/>">
                <span class="px-1">/</span>
                <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
                <button type="button" class="btn btn-secondary" onclick="fnPageMove('M')">이동</button>
            </div>
            
            <div class="buttons">
                <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('P')">이전</button>
                <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('N')">다음</button>
            </div>
        </div>
    </div>

    <div class="table-responsive" id="fileList">
        <table class="data-table data-table--list data-table--interactive" aria-label="파일-검색결과-리스트">
            <colgroup>
                <col style="width: 10rem;">
                <col style="width: 8rem;">
                <col>
                <col style="width: 7rem;">
                <col style="width: 5rem;">
            </colgroup>
            <thead>
            <tr>
                <th scope="col" data-field="설비번호">설비번호</th>
                <th scope="col" data-field="파일타입">파일타입</th>
                <th scope="col" data-field="파일명">파일명</th>
                <th scope="col" data-field="다운로드">다운로드</th>
                <th scope="col" data-field="삭제">삭제</th>
            </tr>
            </thead>
            <tbody>
            <c:forEach var="file" items="${list}" varStatus="status">
                <tr>
                    <td data-field="설비번호">${file.iegNo}</td>
                    <td data-field="파일타입">${file.ieftTypeName}</td>
                    <td data-field="파일명">${file.fileName}</td>
                    <td data-field="다운로드">
                        <button type="button" class="btn btn-sm btn-success" onclick="fnFileDownload('${file.saveFileName}')">다운로드</button>
                    </td>
                    <td data-field="삭제">
                        <button type="button" class="btn btn-sm btn-danger" onclick="fnRemoveFile('${file.saveFileName}')">삭제</button>
                    </td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
    <%--</div>--%>

    <script>

    </script>
</c:if>
