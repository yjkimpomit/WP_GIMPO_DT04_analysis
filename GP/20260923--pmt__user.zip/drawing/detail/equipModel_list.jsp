<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<script>
    var totalPage = ${paginationInfo.totalPageCount};
</script>

<%-- 조회결과 --%>
<div class="title-box d-none" id="_VIEW_RESULT_SHOW">
    <h4 class="title03">조회결과<small>(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h4>

    <div>
        <div class="page-move">
            <label for="currentPage" class="visually-hidden">이동할 페이지</label>
            <input type="number" id="currentPage" class="form-control page" value="<c:out value='${paginationInfo.currentPageNo}'/>">
            <span class="px-1">/</span>
            <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="btn btn-secondary" onclick="fnPageMove('M')">이동</button>
        </div>
        
        <div class="buttons">
            <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('P')">이전</button>
            <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('N')">다음</button>
        </div>
    </div>
</div>

<%-- 설비검색 > 3D 리스트 --%>
<div class="thumb-board list list-3d">
    <c:if test="${listCount == 0}">
        <div class="no-data">
            조회된 데이터가 없습니다.
        </div>
    </c:if>
    <c:forEach var="data" items="${list}" varStatus="status">
        <div class="thumb-item" onclick="fnFacilityTo3D('${data.modelTarget}', '${data.modelId}')">
            <img src="${contextPath}/modelImages/${data.iegNo}.jpg?t=${System.currentTimeMillis()}" class="img-fluid" alt="${data.iegNo}">
            <div class="thumb-title">
                <small>${data.modelTarget}</small>
                <strong>${data.iegDescription}</strong>
            </div>
        </div>
    </c:forEach>
</div>
