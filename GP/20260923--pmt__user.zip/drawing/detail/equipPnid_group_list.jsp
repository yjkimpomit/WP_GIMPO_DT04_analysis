<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="contextPath" value="${pageContext.request.contextPath}"/>

<script>
    var totalPage = ${paginationInfo.totalPageCount};
</script>

<%-- 조회결과 --%>
<div class="result-header" id="_VIEW_RESULT_SHOW">
    <h2 class="result-header__title">조회결과<small class="result-header__count">(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h2>
    
    <div class="result-header__actions">
        <nav class="pagination" aria-label="페이지 이동">
            <input type="number" id="currentPage" class="form-control form-control--page" value="<c:out value='${paginationInfo.currentPageNo}'/>" aria-label="현재 페이지">
            <span aria-hidden="true">/</span>
            <span><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="button button--neutral" onclick="fnPageMove('M')">이동</button>
            <button type="button" class="button button--neutral" onclick="fnPageMove('P')">이전</button>
            <button type="button" class="button button--neutral" onclick="fnPageMove('N')">다음</button>
        </nav>
    </div>
</div>

<%-- 설비검색 > 3D 리스트 --%>
<div class="result-panel__body">
    <div class="board-list" role="group" aria-label="P&amp;ID 목록">
        <c:if test="${fn:length(list) == 0}">
            <div class="no-data">
                조회된 데이터가 없습니다.
            </div>
        </c:if>
        <c:forEach var="data" items="${list}" varStatus="status">
            <button class="board-list__item" type="button" onclick="fnBtnPnidPop('${data.pnidNo}')">
                <span class="board-list__code">${data.pnidNo}</span>
                <span class="board-list__title">${data.pnidDescription}</span>
            </button>
        </c:forEach>
    </div>
</div>
