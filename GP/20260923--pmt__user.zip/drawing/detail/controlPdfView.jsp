<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:set var="viewerPath" value="/resources/user/js/pdfjs/web/viewer.html"/>
<c:set var="pdfPath" value="${pdfPath}"/>

<c:url var="viewerUrl" value="${viewerPath}"/>
<c:url var="pdfUrl" value="${pdfPath}"/>

<%-- 주의: # 뒤의 값은 viewer.html의 해시 파라미터 --%>
<!-- 툴바의 사이드바 옵션 sidebarViewOnLoad=0&amp;-->
<c:set var="viewerSrc"
       value="${viewerUrl}?disablePreferences=true&amp;locale=ko-KR&amp;sidebarViewOnLoad=0&amp;file=${pdfUrl}#page=${page}&amp;scrollMode=page&amp;spreadMode=0"/>

<style>
    html, body {
        height: 100%;
        margin: 0;
        padding: 0;
        background: #FFF;
        overscroll-behavior: none;
    }

    .frame {
        position: fixed;
        inset: 0;
        display: flex;
        
        /* 20260128 yjkim - 반응형 */
		width: 100%;
    }

    .frame > iframe {
        width: 100%;
        height: 100%;
        border: 0;
        display: block;
    }

    ::-webkit-scrollbar {
        width: 0;
        height: 0;
    }
</style>
<div class="title-box">
    <h3 class="title02">제어로직 상세보기</h3>
</div>

<div class="frame">
    <iframe id="pdf" src="${viewerSrc}" allowfullscreen></iframe>
</div>

<script>
    /* ===========================================================
       PDF.js 5.4.394 / ES5
       - "한 페이지만 보기" 강제 + 내부 스크롤 제거
       - 대상 페이지 실측으로 'page-fit' 또는 'page-width' 자동 선택
       - pdfPage 미준비 시에도 pdfDocument.getPage()로 치수 확보
       =========================================================== */
    (function bootstrapInsideViewer() {
        var frame = document.getElementById('pdf');
        
        if (!frame) return;
        /* pdf 이동 네비게이션 부분 */

        /* 부모 창 Alt+←/→ 핸들러: iframe 포커스일 때만 개입 */
        document.addEventListener('keydown', function (e) {
            if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
            var k = e.key || e.code;
            var isArrowL = (k === 'ArrowLeft' || k === 'Left' || e.keyCode === 37);
            var isArrowR = (k === 'ArrowRight' || k === 'Right' || e.keyCode === 39);
            if ((isArrowL || isArrowR) && document.activeElement === frame) {
                e.preventDefault();
                try {
                    var api = frame.contentWindow && frame.contentWindow.__PDF_ALT_HISTORY__;
                    if (!api) return;
                    if (isArrowL) api.back();
                    else api.forward();
                } catch (_) {
                }
            }
        }, true);

        frame.addEventListener('load', function () {
            var win = frame.contentWindow;
            if (!win) return;

            // PDFViewerApplication 준비될 때까지 폴링
            var tries = 0;
            var t = setInterval(function () {
                try {
                    var app = win.PDFViewerApplication;
                    if (app && app.pdfViewer && app.pdfLinkService && app.eventBus && app.pdfViewer.container) {
                        clearInterval(t);
                        installSinglePageAutoFit(app, win);
                        disableAnnEditor(app, win);
                        installAltHistory(app, win);  // ★ 충돌 자동 초기화 포함
                    }
                } catch (e) {
                }
                if (++tries > 600) clearInterval(t); // 최대 60초
            }, 100);
        });

        /* ========== Alt 히스토리 (세션 영구화 + 자동 초기화/치유) ========== */
        function installAltHistory(app, win) {
            if (win.__ALT_HISTORY_INSTALLED__) return;
            win.__ALT_HISTORY_INSTALLED__ = true;

            var viewer = app.pdfViewer;
            var eventBus = app.eventBus;

            var ALT_HIST_MAX = 300;
            var startEpoch = Date.now(); // 새 문서 로드마다 갱신될 epoch

            // === 문서별 키 생성 ===
            var storageKey = null;
            var docFp = null;

            function computeKey() {
                try {
                    var pdfDoc = app.pdfDocument;
                    docFp = pdfDoc && (pdfDoc.fingerprints ? pdfDoc.fingerprints[0] : pdfDoc.fingerprint);
                    storageKey = 'PDF_ALT_HISTORY::' + (docFp || (app.baseUrl || win.location.href));
                } catch (e) {
                    docFp = null;
                    storageKey = 'PDF_ALT_HISTORY::' + win.location.href;
                }
            }

            computeKey();

            var backStack = [];
            var fwdStack = [];
            var current = null;

            function saveState() {
                try {
                    var o = {
                        v: 2,                // 포맷 버전
                        epoch: startEpoch,   // 이번 로드 세션 구분자
                        fp: docFp || null,   // fingerprint
                        back: backStack.slice(-ALT_HIST_MAX),
                        fwd: fwdStack.slice(-ALT_HIST_MAX),
                        current: current | 0
                    };
                    win.sessionStorage.setItem(storageKey, JSON.stringify(o));
                } catch (_) {
                }
            }

            function loadState() {
                try {
                    var s = win.sessionStorage.getItem(storageKey);
                    if (!s) return null;
                    var o = JSON.parse(s);
                    return o && typeof o === 'object' ? o : null;
                } catch (_) {
                    return null;
                }
            }

            function clearState() {
                try {
                    win.sessionStorage.removeItem(storageKey);
                } catch (_) {
                }
            }

            function inRange(pn) {
                var pc = viewer.pagesCount || 1;
                return pn >= 1 && pn <= pc;
            }

            function sanitizeStacks() {
                // 숫자화 + 범위 밖 삭제 + 연속 중복 제거
                function norm(arr) {
                    var r = [];
                    var last = null;
                    for (var i = 0; i < arr.length; i++) {
                        var n = (arr[i] | 0);
                        if (!inRange(n)) continue;
                        if (n === last) continue;
                        r.push(n);
                        last = n;
                    }
                    return r.slice(-ALT_HIST_MAX);
                }

                backStack = norm(backStack);
                fwdStack = norm(fwdStack);
            }

            function resetStacksFromCurrent(reason) {
                current = viewer.currentPageNumber || current || 1;
                backStack = [];
                fwdStack = [];
                saveState();
                try {
                    //console.log('[ALT-HIST] reset:', reason, 'current=', current);
                } catch (_) {
                }
            }

            // 초기 로드: 이전 상태 불러오되, epoch/지문 안 맞으면 무시(=초기화)
            (function initFromStorage() {
                var o = loadState();
                if (!o || o.v !== 2) {
                    resetStacksFromCurrent('no-state');
                    return;
                }
                // 지문이 다르면 다른 문서 → 초기화
                if (docFp && o.fp && o.fp !== docFp) {
                    resetStacksFromCurrent('fingerprint-changed');
                    return;
                }
                // ★ 새 로드마다 epoch 갱신: 예전 기록은 무시(충돌 방지)
                //    (원한다면 아래 조건을 주석 처리하여 이전 epoch 재사용 가능)
                resetStacksFromCurrent('new-epoch');
            })();

            // 문서 로드 완료되면(지문 확정) 한 번 더 초기화(안전)
            eventBus.on && eventBus.on('documentloaded', function () {
                computeKey();
                startEpoch = Date.now(); // 새 epoch로 시작
                resetStacksFromCurrent('documentloaded');
            });

            var mute = 0; // 프로그램 이동 중엔 기록 억제

            function goTo(pn) {
                if (!inRange(pn)) {
                    resetStacksFromCurrent('goto-oob');
                    return;
                }
                mute = 1;
                try {
                    app.pdfLinkService.goToPage(pn);
                } finally {
                    win.setTimeout(function () {
                        mute = 0;
                    }, 0);
                }
            }

            // 페이지 변경 시(사용자 주도) 기록 쌓기
            eventBus.on && eventBus.on('pagechanging', function (e) {
                if (mute) return;
                var pn = e.pageNumber | 0;
                if (!inRange(pn)) {
                    resetStacksFromCurrent('pagechanging-oob');
                    return;
                }
                if (current == null) {
                    current = pn;
                    saveState();
                    return;
                }
                if (pn === current) return;
                backStack.push(current);
                if (backStack.length > ALT_HIST_MAX) backStack.shift();
                current = pn;
                fwdStack.length = 0;
                sanitizeStacks();
                saveState();
            });

            function back() {
                // 1) 공식 히스토리 우선
                if (app.pdfHistory && typeof app.pdfHistory.back === 'function') {
                    try {
                        app.pdfHistory.back();
                        return;
                    } catch (_) {
                    }
                }
                // 2) 폴백(세션 스택)
                sanitizeStacks();
                if (!backStack.length) {
                    resetStacksFromCurrent('back-empty');
                    return;
                }
                var target = backStack.pop();
                if (!inRange(target)) {
                    resetStacksFromCurrent('back-oob');
                    return;
                }
                if (current != null) fwdStack.push(current);
                current = target;
                saveState();
                goTo(target);
            }

            function forward() {
                if (app.pdfHistory && typeof app.pdfHistory.forward === 'function') {
                    try {
                        app.pdfHistory.forward();
                        return;
                    } catch (_) {
                    }
                }
                sanitizeStacks();
                if (!fwdStack.length) {
                    resetStacksFromCurrent('fwd-empty');
                    return;
                }
                var target = fwdStack.pop();
                if (!inRange(target)) {
                    resetStacksFromCurrent('fwd-oob');
                    return;
                }
                if (current != null) backStack.push(current);
                current = target;
                saveState();
                goTo(target);
            }

            // 입력창 제외하고 Alt+←/→ 처리 (iframe 내부)
            win.document.addEventListener('keydown', function (e) {
                if (!e.altKey || e.ctrlKey || e.metaKey || e.shiftKey) return;
                var n = (e.target && e.target.nodeName) || '';
                if (n === 'INPUT' || n === 'TEXTAREA') return;
                var k = e.key || e.code;
                // Alt+0 → 수동 리셋(원치 않으면 이 블록 지우세요)
                if ((k === '0' || e.keyCode === 48)) {
                    e.preventDefault();
                    e.stopPropagation();
                    // 전체 초기화(세션 기록도 삭제)
                    clearState();
                    startEpoch = Date.now();
                    resetStacksFromCurrent('manual-alt-0');
                    return;
                }
                if (k === 'ArrowLeft' || k === 'Left' || e.keyCode === 37) {
                    e.preventDefault();
                    e.stopPropagation();
                    back();
                } else if (k === 'ArrowRight' || k === 'Right' || e.keyCode === 39) {
                    e.preventDefault();
                    e.stopPropagation();
                    forward();
                }
            }, true);

            // 부모에서 호출/초기화 가능하도록 노출
            win.__PDF_ALT_HISTORY__ = {
                back: back,
                forward: forward,
                reset: function (reason) {
                    clearState();
                    startEpoch = Date.now();
                    resetStacksFromCurrent(reason || 'api-reset');
                },
                debug: function () {
                    return {
                        storageKey: storageKey, epoch: startEpoch, current: current,
                        back: backStack.slice(), fwd: fwdStack.slice(), fp: docFp
                    };
                }
            };

            // 초기 고정
            if (current == null) {
                current = viewer.currentPageNumber || 1;
                saveState();
            }
        }

        /* ========== Annotation Editor 비활성화 (NPE 예방) ========== */
        function disableAnnEditor(app, win) {
            try {
                if (win.PDFViewerApplicationOptions &&
                    typeof win.PDFViewerApplicationOptions.set === 'function') {
                    win.PDFViewerApplicationOptions.set('enableAnnotationEditor', false);
                }
            } catch (e) {
            }

            try {
                var ui = app.pdfViewer && app.pdfViewer.annotationEditorUIManager;
                var E = win.pdfjsViewer && win.pdfjsViewer.EditorType;
                if (ui) {
                    if (typeof ui.disable === 'function') ui.disable();
                    if (E && typeof ui.setMode === 'function') ui.setMode(E.NONE);
                }
            } catch (e) {
            }

            try {
                var eb = app.eventBus;
                eb && eb.on && eb.on('documentloaded', function () {
                    try {
                        var ui = app.pdfViewer && app.pdfViewer.annotationEditorUIManager;
                        var E = win.pdfjsViewer && win.pdfjsViewer.EditorType;
                        if (ui) {
                            if (typeof ui.disable === 'function') ui.disable();
                            if (E && typeof ui.setMode === 'function') ui.setMode(E.NONE);
                        }
                    } catch (_) {
                    }
                });
            } catch (e) {
            }
        }

        /* ========== 한 페이지 보기 + 자동 맞춤 ========== */
        function installSinglePageAutoFit(app, win) {
            if (win.__SINGLE_PAGE_AUTOFIT_INSTALLED__) return;
            win.__SINGLE_PAGE_AUTOFIT_INSTALLED__ = true;

            var viewer = app.pdfViewer;
            var eventBus = app.eventBus;
            var linkSvc = app.pdfLinkService;
            var container = viewer.container;
            var V = win.pdfjsViewer;
            var ScrollMode = (V && V.ScrollMode) || {VERTICAL: 0, HORIZONTAL: 1, WRAPPED: 2, PAGE: 3};

            function enforceSinglePageMode() {
                try {
                    if (viewer.scrollMode !== ScrollMode.PAGE) {
                        viewer.scrollMode = ScrollMode.PAGE;
                    }
                    if (viewer.spreadMode !== 0) {
                        viewer.spreadMode = 0;
                    }
                    if (container && container.style) {
                        container.style.overflow = 'hidden';
                    }
                } catch (e) {
                }
            }

            function safeApplyScale(target) {
                try {
                    if (viewer.currentScaleValue !== target) {
                        viewer.currentScaleValue = target;
                    } else {
                        viewer.currentScaleValue = 'auto';
                        win.requestAnimationFrame(function () {
                            viewer.currentScaleValue = target;
                        });
                    }
                    viewer.update && viewer.update();
                    app.forceRendering && app.forceRendering();
                } catch (e) {
                }
            }

            var __fitState = {
                applyQueued: false,
                next: null,
                last: {page: 0, target: '', cw: 0, ch: 0}
            };

            function chooseOptionFor(pageNumber, attempt) {
                attempt = attempt || 0;
                try {
                    var pagesRotation = viewer.pagesRotation || 0;

                    function decideWith(pageW, pageH) {
                        var cw = container.clientWidth || 1;
                        var ch = container.clientHeight || 1;
                        var heightIfWidthFit = (cw / pageW) * pageH;
                        var target = (heightIfWidthFit > ch) ? 'page-fit' : 'page-width';

                        __fitState.next = {target: target, page: pageNumber, cw: cw, ch: ch};
                        if (__fitState.applyQueued) return;

                        __fitState.applyQueued = true;
                        win.requestAnimationFrame(function () {
                            __fitState.applyQueued = false;
                            var ap = __fitState.next;
                            __fitState.next = null;
                            if (!ap) return;

                            var last = __fitState.last;
                            if (last.target === ap.target &&
                                last.page === ap.page &&
                                Math.abs(last.cw - ap.cw) < 2 &&
                                Math.abs(last.ch - ap.ch) < 2) {
                                return;
                            }

                            safeApplyScale(ap.target);
                            __fitState.last = ap;
                        });
                    }

                    var pv = viewer.getPageView(pageNumber - 1);
                    if (pv && pv.pdfPage) {
                        var rot = ((pv.rotation || 0) + pagesRotation) % 360;
                        var vp = pv.pdfPage.getViewport({scale: 1, rotation: rot});
                        return decideWith(vp.width, vp.height);
                    }

                    if (app.pdfDocument && app.pdfDocument.getPage) {
                        app.pdfDocument.getPage(pageNumber).then(function (page) {
                            var rot = ((page.rotate || 0) + pagesRotation) % 360;
                            var vp = page.getViewport({scale: 1, rotation: rot});
                            decideWith(vp.width, vp.height);
                        }).catch(function () {
                            if (attempt < 5) {
                                win.requestAnimationFrame(function () {
                                    chooseOptionFor(pageNumber, attempt + 1);
                                });
                            }
                        });
                        return;
                    }

                    if (attempt < 5) {
                        win.requestAnimationFrame(function () {
                            chooseOptionFor(pageNumber, attempt + 1);
                        });
                    }
                } catch (e) {
                }
            }

            // 렌더 취소 시 상태 체크로 안전 가드
            function hardResetLayout() {
                try {
                    if (app.pdfRenderingQueue && app.pdfRenderingQueue.pause) {
                        app.pdfRenderingQueue.pause();
                    }
                    if (viewer._pages && viewer._pages.length) {
                        var RS = (V && V.RenderingStates) || {RUNNING: 1};
                        for (var i = 0; i < viewer._pages.length; i++) {
                            var pv = viewer._pages[i];
                            try {
                                if (pv && pv.cancelRendering && pv.renderingState === RS.RUNNING) {
                                    pv.cancelRendering();
                                }
                            } catch (e) {
                            }
                        }
                    }
                    container.scrollTop = 0;
                    container.scrollLeft = 0;
                } catch (e) {
                } finally {
                    if (app.pdfRenderingQueue && app.pdfRenderingQueue.resume) {
                        app.pdfRenderingQueue.resume();
                    }
                }
            }

            function scheduleChooseForCurrent() {
                win.requestAnimationFrame(function () {
                    win.requestAnimationFrame(function () {
                        chooseOptionFor(viewer.currentPageNumber);
                    });
                });
            }

            enforceSinglePageMode();

            var _goToDestination = linkSvc.goToDestination && linkSvc.goToDestination.bind(linkSvc);
            if (_goToDestination) {
                linkSvc.goToDestination = function () {
                    hardResetLayout();
                    var r = _goToDestination.apply(linkSvc, arguments);
                    enforceSinglePageMode();
                    scheduleChooseForCurrent();
                    return r;
                };
            }

            var _setHash = linkSvc.setHash && linkSvc.setHash.bind(linkSvc);
            if (_setHash) {
                var _debounceTimer = 0;
                var _inFlight = false;

                linkSvc.setHash = function () {
                    var r = _setHash.apply(linkSvc, arguments);

                    if (_debounceTimer) clearTimeout(_debounceTimer);
                    _debounceTimer = setTimeout(function () {
                        if (_inFlight) return;
                        _inFlight = true;

                        var once = function () {
                            eventBus.off('updateviewarea', once);
                            scheduleChooseForCurrent();
                            _inFlight = false;
                        };
                        eventBus.on('updateviewarea', once);

                        setTimeout(function () {
                            if (_inFlight) {
                                scheduleChooseForCurrent();
                                _inFlight = false;
                            }
                        }, 250);
                    }, 60);

                    return r;
                };
            }

            try {
                var root = win.document.getElementById('viewer') || win.document;
                root.addEventListener('click', function (ev) {
                    var el = ev.target;
                    while (el && el !== root) {
                        if (el.tagName === 'A' && el.getAttribute('href')) {
                            var href = el.getAttribute('href');
                            if (href.charAt(0) === '#' && href.length > 1) {
                                hardResetLayout();
                                enforceSinglePageMode();
                                scheduleChooseForCurrent();
                                break;
                            }
                        }
                        el = el.parentNode;
                    }
                }, true);
            } catch (e) {
            }

            eventBus.on && eventBus.on('pagechanging', function () {
                enforceSinglePageMode();
                scheduleChooseForCurrent();
            });
            eventBus.on && eventBus.on('pagenumberchanged', function () {
                enforceSinglePageMode();
                scheduleChooseForCurrent();
            });

            win.addEventListener('resize', function () {
                enforceSinglePageMode();
                scheduleChooseForCurrent();
            });

            eventBus.on && eventBus.on('pagesinit', function () {
                try {
                    enforceSinglePageMode();
                    hardResetLayout();
                } catch (e) {
                }
                win.requestAnimationFrame(function () {
                    win.requestAnimationFrame(function () {
                        chooseOptionFor(viewer.currentPageNumber || 1);
                    });
                });
            });

            eventBus.on && eventBus.on('documentloaded', function () {
                enforceSinglePageMode();
                scheduleChooseForCurrent();
            });
        }
    })();
    /* 토글 목록 버튼 */
    window.onPdfListToggle = function () {
        $.ajax({
            url: "/drawing/controlLogic.do",
            type: "POST",
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").css("display", "");
            },
            success: function (data) {
                $(controlTabPane).html(data);
            },
            error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    };
</script>