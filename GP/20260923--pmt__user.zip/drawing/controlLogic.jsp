﻿<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<div class="title-box">
    <h3 class="title02">제어로직 리스트</h3>
</div>

<!-- 검색영역 -->
<div class="search-box">
    <form id="form_search_work_request" method="post" autocomplete="off" action="javascript:fnWorkRequestSearch()">
        <div class="row">
            <div class="col-md-6 col-lg-4 col-xxl-3">
                <label class="form-label" for="drawingKeyword">검색어 입력</label>
                <input class="form-control" id="drawingKeyword" type="text" value="${drawingVO.searchKeyword}" name="searchKeyword">
            </div>

            <div class="col col-md-auto col-lg-auto">
                <button type="submit" class="btn btn-primary">
                    <span class="icon icon-search"></span>
                    <span>검색</span>
                </button>
            </div>
        </div>
    </form>
</div>

<%-- data-grid : 결과 리스트 뷰 --%>
<div id="_VIEW_CONTROLLOGIC_LIST">
    <%-- 조회 리스트 부분 : /detail/workRequest_list.jsp --%>
</div>

<script>
    function showPdfDetail(idx) {
        $.ajax({
            type: "post"
            , url: "/drawing/controlPdfView.do"
            , data: {icldIdx: idx}
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#controlTabPane").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    <%-- 검색 결과 리스트 --%>

    function fnWorkRequestSearch() {

        $.ajax({
            type: "post"
            , url: "/drawing/controlLogicList.do"
            , data: $("#form_search_work_request").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_VIEW_CONTROLLOGIC_LIST").html(data);
                $("#_VIEW_RESULT_SHOW").removeClass('d-none');
                $("#loadingBar").css("display", "none");
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    <%-- 페이지 이동 부분 --%>

    function fnPageMove(f) {
        var currentPage = parseInt($("#currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }

            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }

            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#currentPage").val(totalPage);
                return false;
            }
        }

        $.ajax({
            type: "get"
            , url: "/drawing/controlLogicList.do?pageIndex=" + currentPage
            , data: $("#form_search_work_request").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_VIEW_CONTROLLOGIC_LIST").html(data);
                $("#_VIEW_RESULT_SHOW").removeClass('d-none');
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    $(function () {
        fnWorkRequestSearch();
    });
</script>