<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<%-- <!-- 로딩박스 --> --%>
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="container-drawing">
    <!-- tab-menu -->
    <ul class="nav nav-tabs" id="drawingTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="controlTab" data-bs-toggle="tab" data-bs-target="#controlTabPane" type="button" role="tab" aria-controls="controlTabPane" aria-selected="false" data-page="/drawing/controlLogic.do">제어로직</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab" data-bs-toggle="tab" data-bs-target="#modelTabPane" type="button" role="tab" aria-controls="modelTabPane" aria-selected="false" data-page="/drawing/equipModel.do">3D</button>
        </li>
        <%--<li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE disabled" id="outstandingTmTab" data-bs-toggle="tab" data-bs-target="#outstandingTmTabPane" type="button" role="tab" aria-controls="outstandingTmTabPane" aria-selected="false" data-page="">Tag List</button>
        </li>--%>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="pnidTab" data-bs-toggle="tab" data-bs-target="#pnidTabPane" type="button" role="tab" aria-controls="pnidTabPane" aria-selected="false" data-page="/drawing/equipPnid.do">P&ID</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="dataparcTab" data-bs-toggle="tab" data-bs-target="#dataparcTabPane" type="button" role="tab" aria-controls="dataparcTabPane" aria-selected="false" data-page="/drawing/equipDataparc.do">DataPARC</button>
        </li>
    </ul>

    <!-- tab content -->
    <div class="tab-content" id="drawingTabContent">
        <div class="tab-pane fade _TAB_CONTENT" id="controlTabPane" role="tabpanel" aria-labelledby="controlTab" tabindex="0"></div>
        <div class="tab-pane fade _TAB_CONTENT" id="modelTabPane" role="tabpanel" aria-labelledby="modelTab" tabindex="0"></div>
        <div class="tab-pane fade _TAB_CONTENT" id="outstandingTmTabPane" role="tabpanel" aria-labelledby="outstandingTmTab" tabindex="0"></div>
        <div class="tab-pane fade _TAB_CONTENT" id="pnidTabPane" role="tabpanel" aria-labelledby="pnidTab" tabindex="0"></div>
        <div class="tab-pane fade _TAB_CONTENT" id="dataparcTabPane" role="tabpanel" aria-labelledby="dataparcTab" tabindex="0"></div>
    </div>
</div>


<script>
    $(document).ready(function () {
        // 탭 인덱스 (기본 0)
        const rawIdx = '${empty drawingVO.tabIdx ? 0 : drawingVO.tabIdx}';
        const tabIdx = parseInt(rawIdx);
        const $tabs = $('._TAB_PAGE');

        // view content
        function fnLoadTabContent($btn) {
            // 대상 탭 버튼/패널
            const targetContentId = $btn.attr('data-bs-target');
            const targetUrl = $btn.attr('data-page');
            if (!targetContentId || !targetUrl) return;

            // 기존 팝업/콘텐츠 정리
            $('._TAB_CONTENT').empty();

            $.ajax({
                url: targetUrl,
                type: "POST",
                dataType: "html",
                beforeSend: function () {
                    $("#loadingBar").css("display", "");
                },
                success: function (data) {
					//로드후 초기화 과정이 있어야 검색패널 열고닫기가 실행됨
					var targetPanel = document.querySelector(targetContentId);
					$(targetPanel).html(data);
					targetPanel.dispatchEvent(new CustomEvent('tabs:content-loaded', {
						bubbles: true
					}));
                    // 내부에서 로딩 닫음
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        }

        // 탭 클릭 시: Bootstrap 탭 전환 + Ajax 로딩
        $tabs.on('click', function (e) {
            e.preventDefault();

            // Bootstrap 탭 활성화 보장 : common.js에서 공통으로 사용
            fnSetCommonBootstrapTab($(this));

            // 데이터 로딩
            fnLoadTabContent($(this));
        });

        // 페이지 로딩시 tabIndex 실행
        const $initial = $tabs.eq(tabIdx);
        if ($initial.length) {
            // BS 탭 전환 후 컨텐츠 로드
            const bootstrapApi = window['bootstrap'];
            if (bootstrapApi && typeof bootstrapApi.Tab === 'function') {
                new bootstrapApi.Tab($initial[0]).show();
            }
            $initial.trigger('click');
        }
    });
</script>
</body>
<c:import url="/footer.do"/>
