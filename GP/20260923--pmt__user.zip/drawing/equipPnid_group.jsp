﻿<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content data-pid-page">
    <div class="page-content__placeholder">
        <div class="splitview">
            <aside class="splitview__pane splitview__pane--sidebar" aria-label="P&amp;ID 정보 검색">
                <form class="filter-panel" id="form_search_work_request" method="post" autocomplete="off" action="javascript:fnWorkRequestSearch(true)">
                    <div class="filter-panel__header">
                        <span class="filter-panel__title">검색</span>
                        <button class="filter-panel__toggle" type="button"
                                aria-label="정보 검색 접기" aria-expanded="true"></button>
                    </div>
                    
					<div class="filter-panel__search" id="filter-panel-search">
                        <div class="filter-panel__fields">
                            <input type="hidden" name="pageIndex" id="pageIndex" value="${pnidVO.pageIndex}">
                            <!-- 개발 연계: 검색 조건 영역은 filter-panel__fields를 사용하고, 각 조건은 form-field 단위로 추가·반복합니다. -->
                            <label class="form-field">
                                <span class="form-label">검색어 입력</span>
                                <input class="form-control form-control--return" placeholder="TAG 번호, 설비번호, P&ID 번호" id="pnidKeyword" type="text" value="${pnidVO.searchKeyword}" name="searchKeyword">
                            </label>
                        </div>
                        <%--<div class="filter-panel__actions">
                            <button type="submit" class="button button--primary">검색</button>
                        </div>--%>
                    </div>
                </form>
            </aside>
            <section class="splitview__pane splitview__pane--content" aria-label="P&amp;ID 조회 결과">
                <h1 class="page-content__heading">P&amp;ID 리스트</h1>

                <%-- data-grid : 결과 리스트 뷰 --%>
                <div class="result-panel" id="_VIEW_EQUIPPNID_LIST">
                    <%-- 조회 리스트 부분 : /detail/equipPnid_list.jsp --%>
                </div>
                
            </section>
        </div>
    </div>
</main>

<script>
	<%-- 클릭시 멀티뷰어 팝업 --%>
	function fnOpenEquipDetail(iegNo) {
		var targetUrl = "/multiview/index.do?t=F&iegNo=" + encodeURIComponent(iegNo);
	    fnOpenPopupStandard(targetUrl, "설비상세정보");
	}

    <%-- 검색 결과 리스트 --%>
    function fnWorkRequestSearch(resetPage) {
        if (resetPage) {
            $("#pageIndex").val(1);
        }

        $.ajax({
            type: "post"
            , url: "/drawing/equipPnidGroupList.do"
            , data: $("#form_search_work_request").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_VIEW_EQUIPPNID_LIST").html(data);
                $("#_VIEW_RESULT_SHOW").removeClass('d-none');
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    /* pnid 팝업 */
    function fnBtnPnidPop(target) {
        var topWindow = window.parent;
		var box = new WinBox("P&ID", {
			
            url: "/drawing/equipPnidPopup.do?searchKeyword=" + target,
            //width: "1400px",
			width: Math.min(1400, window.innerWidth - 20) + "px",
			height: Math.min(720, window.innerHeight - 20) + "px",
			x: "center",
			y: "center",
            
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },

			onclose: function () {
				window.removeEventListener("resize", resizeHandler);
			}
		});

		function resizeHandler() {
			if (!box || !box.g || box.min) return;

			var newWidth = Math.min(1400, window.innerWidth - 20);
			var newHeight = Math.min(720, window.innerHeight - 20);

			box.resize(newWidth, newHeight);
			box.move("center", "center");
		}

		window.addEventListener("resize", resizeHandler);
    }

    <%-- 페이지 이동 부분 --%>

    function fnPageMove(f) {
        var currentPage = parseInt($("#currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }

            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }

            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#currentPage").val(totalPage);
                return false;
            }
        }

        $("#form_search_work_request #pageIndex").val(currentPage);
        fnWorkRequestSearch(false);
    }

    $(function () {
        fnWorkRequestSearch(false);
    });
</script>
</body>
<c:import url="/footer.do"/>
