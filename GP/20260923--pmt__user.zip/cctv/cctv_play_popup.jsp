<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar">
    <div class="loader"></div>
</div>

<%-- 테스트 CCTV --%>
<iframe
        src="http://192.168.137.86:20000/cctv1013"
        width="100%"
        height="100%"
        allow="autoplay; fullscreen"
        style="border:0;"
        allowfullscreen>
</iframe>

<script>
    setTimeout(function(){
        $("#loadingBar").addClass("d-none");
    }, 3000);
</script>
</body>
<c:import url="/footer.do"/>