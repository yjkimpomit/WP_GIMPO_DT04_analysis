<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<button type="button" class="reset-date" style="position: absolute; bottom: 0; left: 2rem;">날짜 초기화</button>
<script>
	$('.reset-date').on('click', function () {
		$('input[type="date"]').val('');
	});
</script>
<div class="winbox-layout page-content">
    <div class="page-content__placeholder">
        <div class="splitview">
            <aside class="splitview__pane splitview__pane--sidebar" aria-label="정보 검색">
                
                <!-- 검색영역 -->
                <form class="filter-panel" id="frmCctvInfoSearch">
                    
                    <div class="filter-panel__header">
                        <span class="filter-panel__title">검색</span>
                        <button class="filter-panel__toggle"
                                type="button"
                                aria-label="정보 검색 접기"
                                aria-expanded="true"
                                aria-controls="filter-panel-search"></button>
                    </div>
                    
                    <div class="filter-panel__search" id="filter-panel-search">
                        <!-- filter-panel__fields 안에서 form-field 단위로 반복 -->
                        <div class="filter-panel__fields">
                        <input type="hidden" id="ColList" name="ColList" value=""/>
                        
                        <div class="form-field">
                            <label class="form-label" for="cctvId">CCTV 명</label>
                            <input class="form-control" type="text" id="cctvId" name="ici_name" placeholder="CCTV 명 입력" autocomplete="off"/>
                        </div>
                        
                        <div class="form-field">
                            <label class="form-label" for="cctvPlace">위치</label>
                            <input class="form-control" type="text" id="cctvPlace" name="ici_location" placeholder="위치 입력" autocomplete="off"/>
                        </div>
                        
                        <div class="filter-panel__actions">
                            <button type="button" class="button button--primary" onclick="fnSearchCctvList();">검색</button>
                            <%--
                                <button type="button" class="button button--primary" onclick="downloadCctvView();">설치파일 다운로드</button>
                            --%>
                        </div>
                    </div>
                
            </div>
                </form>
            </aside>
            <section class="splitview__pane splitview__pane--content" aria-label="검색 결과">
                <h1 class="page-content__heading">CCTV 리스트</h1>
                
                <%-- data-grid : 결과 리스트 뷰 --%>
                <div class="result-panel" id="divSearchResult">
                    
                    <div class="result-header">
                        <h2 class="result-header__title">조회결과<span class="result-header__count" id="searchResultCnt"></span></h2>
                        
                        <div class="result-header__actions">
                            <nav class="pagination" aria-label="페이지 이동">
                                <input type="number" id="currentPage" class="form-control form-control--page" aria-label="이동할 페이지 번호" placeholder="0">
                                <span aria-hidden="true">/</span>
                                <span class="total" id="totalPage">0</span>
                                <button type="button" class="button button--neutral" onclick="setPageMove();">이동</button>
                                <input type="hidden" id="currentPageVal"/>
                                <button type="button" class="button button--neutral" id="prePage" onclick="prePageMove();">이전</button>
                                <button type="button" class="button button--neutral" id="nextPage" onclick="nextPageMove();">다음</button>
                                <%-- 앱 로그인 체크 --%>
                                <c:if test="${sessionScope.loginInfo.iui_isadmin ne '999'}">
                                    <button type="button" class="button button--secondary" onclick="cctvExcelDownload()">엑셀 다운로드</button>
                                </c:if>
                            </nav>
                        </div>
                    </div>
                    
                    <!-- data-grid -->
                    <div class="result-table" id="divCctvList"></div>
                    
                    
                </div>
            </section>
        </div>
    </div>
</div>

<c:import url="/common/modalPopup.do"/>

<script src="${pageContext.request.contextPath}/resources/user/js/unity/webUtil.js"></script>
<script>
	function fnViewVlc(){
		$("#cctvImg").bPopup({
	        modalClose: false,
	        position: [0, 0],
	        opacity: .4,
	        speed: 450,
	        closeClass: "close",
	        onOpen: function () {
	            $(this).addClass('show detail-box');
	        },
	        onClose: function () {
	            $(this).removeClass('show');
	        }
	    });
	}

    function fnSearchCctvList() {
        $.ajax({
            url: "/cctv/cctvInfoList.do",
            type: "POST",
            data: $("#frmCctvInfoSearch").serialize(),
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").css("display", "");
            },
            success: function (data) {
                if (data !== "") {
                    $("#divCctvList").html(data);
                    $("#divSearchResult").show();
                }
            },
            error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    function setPageMove() {
        var flg = true;
        var setErrMsg = "";

        var currentPage = parseInt($("#currentPage").val());
        var totalPage = parseInt($("#totalPage").text());

        if (currentPage > totalPage) {
            flg = false;
            if (setErrMsg !== "") {
                setErrMsg += "\n";
            }
            setErrMsg += "검색할 페이지가 최대 페이지보다 큽니다.(최대 검색 페이지 : " + totalPage + ")";
        }

        if (flg) {
            var formData = $("#frmCctvInfoSearch").serialize();
            formData += "&pageIndex=" + currentPage;

            $.ajax({
                url: "/cctv/cctvInfoList.do",
                type: "POST",
                data: formData,
                dataType: "html",
                beforesend: function () {
                  $("#loadingBar").css("display", "");
                },
                success: function (data) {
                    if (data !== "") {
                        $("#divCctvList").html(data);
                    }
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        } else {
            alert(setErrMsg);
        }
    }

    function prePageMove() {
        var currentPageVal = parseInt($("#currentPageVal").val());
        var setCurrentPage = currentPageVal - 1;
        var flg = true;
        var setErrMsg = "";

        if (setCurrentPage < 1) {
            flg = false;
            if (setErrMsg !== "") {
                setErrMsg += "\n";
            }
            setErrMsg += "처음 페이지 입니다.";
        }

        if (flg) {
            var formData = $("#frmCctvInfoSearch").serialize();
            formData += "&pageIndex=" + setCurrentPage;

            $.ajax({
                url: "/cctv/cctvInfoList.do",
                type: "POST",
                data: formData,
                dataType: "html",
                beforeSend: function () {
                    $("#loadingBar").css("display", "");
                },
                success: function (data) {
                    if (data !== "") {
                        $("#divCctvList").html(data);
                    }
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        } else {
            alert(setErrMsg);
        }
    }

    function nextPageMove() {
        var flg = true;
        var setErrMsg = "";
        var totalPage = parseInt($("#totalPage").text());
        var currentPageVal = parseInt($("#currentPageVal").val());
        var setCurrentPage = currentPageVal + 1;

        if (setCurrentPage > totalPage) {
            flg = false;
            if (setErrMsg !== "") {
                setErrMsg += "\n";
            }
            setErrMsg += "마지막 페이지 입니다.";
        }

        if (flg) {
            var formData = $("#frmCctvInfoSearch").serialize();
            formData += "&pageIndex=" + setCurrentPage;

            $.ajax({
                url: "/cctv/cctvInfoList.do",
                type: "POST",
                data: formData,
                dataType: "html",
                beforeSend: function () {
                    $("#loadingBar").css("display", "");
                },
                success: function (data) {
                    if (data !== "") {
                        $("#divCctvList").html(data);
                    }
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        } else {
            alert(setErrMsg);
        }
    }

    $(document).ready(function () {
        fnSearchCctvList();
    });
</script>

</body>
<c:import url="/footer.do"/>

