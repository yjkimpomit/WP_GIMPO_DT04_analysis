<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<div class="table-responsive">
    <table class="data-table data-table--list" id="tblCctvList" aria-label="CCTV-리스트">
        <thead>
        <tr>
            <th scope="col" name="excelCol" data-field="CCTV-ID">CCTV ID</th>
            <th scope="col" name="excelCol" data-field="CCTV-명">CCTV 명</th>
            <th scope="col" name="excelCol" data-field="위치">위치</th>
            <th scope="col" data-field="CCTV-보기">CCTV 보기</th>
            <th scope="col" data-field="CCTV-위치확인">위치확인</th>
        </tr>
        </thead>
        <tbody>
        <%-- 데이터가 없을 경우 --%>
        <c:if test="${empty cctvInfoList}">
            <tr>
                <th colspan="5">
                    <div class="no-data">
                        조회된 데이터가 없습니다.
                    </div>
                </th>
            </tr>
        </c:if>
    
        <c:forEach items="${cctvInfoList}" var="cctvInfo" varStatus="status">
            <tr>
                <td data-field="CCTV-ID">${cctvInfo.ici_cctvid}</td>
                <td data-field="CCTV-명">${cctvInfo.ici_name}</td>
                <td data-field="위치">${cctvInfo.ici_location}</td>
                <td data-field="보기">
                    <button type="button" class="button button--sm button--neutral" onclick="fnViewVlcRtsp('${cctvInfo.ici_cctvid}');">
                    <!-- <button type="button" class="button button--sm button--neutral" onclick="fnViewVlc();"> -->
                        <span>보기</span>
                    </button>
                </td>
                <td data-field="이동">
                    <c:choose>
                        <c:when test="${cctvInfo.ici_model_conn_type eq 'Y'}">
                            <button type="button" class="button button--sm button--neutral" onclick="fnCctvtoUnity('${cctvInfo.modelTarget}', '${cctvInfo.ici_cctvid}');">
                                <span>이동</span>
                            </button>
                        </c:when>
                        <c:otherwise>-</c:otherwise>
                    </c:choose>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>

<script>
    $(function () {
        var currentPage = ${CCTVInfoVO.pageIndex};
        var recordCountPerPage = ${CCTVInfoVO.recordCountPerPage};
        var searchResultCnt = ${totCnt};

        var totalPage = Math.floor(searchResultCnt / recordCountPerPage);

        if ((searchResultCnt % recordCountPerPage) > 0) {
            totalPage++;
        }

        $("#currentPageVal").val(currentPage);
        $("#currentPage").val(currentPage);
        $("#totalPage").text(totalPage);

        $("#searchResultCnt").text("(" + searchResultCnt + ")");
    });

    //cctv 엑셀 다운로드
    function cctvExcelDownload() {
        var excelColList = [];

        $("th[name='excelCol']").each(function () {
            var fieldValue = $(this).data("field");
            excelColList.push(fieldValue);
        });
        $("#ColList").val(excelColList);

        $.ajax({
            type: "POST"
            , url: "/cctv/cctvInfoExcelList.do"
            , data: $("#frmCctvInfoSearch").serialize()
            , xhrFields: {
                responseType: 'blob'  // 응답을 Blob 형식으로 받기
            }
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (response, status, xhr) {
                //현재 날짜 가져오기
                var currentDate = new Date();
                var formattedDate = currentDate.getFullYear() + '-' +
                    (currentDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                    currentDate.getDate().toString().padStart(2, '0');

                // Blob을 사용하여 파일 다운로드 처리
                var blob = response;
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = "CCTV_" + formattedDate + ".xlsx";
                link.click();  // 다운로드 트리거
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }
</script>
