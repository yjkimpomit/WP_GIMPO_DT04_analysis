<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<div class="search-result">
    <div class="title-box" id="divSearchResult">
        <h4 class="title04">조회결과<small>(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h4>
        <span>조회결과는 최대 150개까지 표시됩니다.</span>
    </div>
    
    <div class="table-responsive">
        <%-- 데이터 리스트 --%>
        <table class="data-table data-table--list data-table--interactive" aria-label="global-search-result">
            <thead>
            <tr>
                <th scope="col" data-field="바로가기">바로가기</th>
                <th scope="col" data-field="명칭">명칭</th>
            </tr>
            </thead>
            <tbody>
            <c:if test="${empty list}">
                <tr>
                    <td colspan="2">
                        <div class="no-data">
                            데이터가 없습니다.
                        </div>
                    </td>
                </tr>
            </c:if>
            
            <c:forEach var="data" items="${list}">
	            <tr>
	                <td data-field="바로가기">
	                    <div class="icon-group">
	                    	<c:if test="${data.isPanorama eq 'Y'}">
	                        	<span class="icon icon-group-pano" title="파노라마" onclick="fnGlobalSearchOpenPano('${data.modelTarget}', '${data.iegNo}')"></span>
	                        </c:if>
	                        <c:if test="${data.isModel eq 'Y'}">
	                        	<span class="icon icon-group-3d" title="3D모델" onclick="fnGlobalSearchOpenModel('${data.modelTarget}', '${data.modelId}')"></span>
	                        </c:if>
	                        <c:if test="${data.isPnid eq 'Y'}">
	                        	<span class="icon icon-group-pnid" title="P&ID" onclick="fnGlobalSearchOpenPnid('${data.iegNo}')"></span>
	                        </c:if>
	                        <c:if test="${data.isDataparc eq 'Y'}">
		                        <span class="icon icon-group-dataparc"
								      title="dataPARC"
								      data-svg-file="<c:out value='${data.dataSvgFileName}'/>"
								      data-tag-no="<c:out value='${data.dataTagNo}'/>"
								      data-ieg-no="<c:out value='${data.iegNo}'/>"
								      onclick="fnGlobalSearchOpenDataParc(this)">
								</span>
	                    	</c:if>
	                    </div>
	                </td>
	                <td data-field="명칭">
	                    <span class="text-link" title="설비정보" onclick="fnGlobalSearchOpenFacilityDetail('${data.iegNo}')">
							[<c:out value="${data.descriptionNo}" />] <c:out value="${data.descriptionText}" />
	                    </span>
	                </td>
	            </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>