<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<%-- <!-- 로딩박스 --> --%>
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%-- 검색 화면 --%>
<div class="global-search">
    <form id="searchForm" name="searchForm" method="post">
        <div class="row gx-2 row-lg-cols-2">
            <fieldset class="col-auto">
                <legend class="visually-hidden">검색옵션 선택</legend>
                <div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="searchCondition" value="facility" id="id01" checked>
                        <label class="form-check-label" for="id01">
                            설비
                        </label>
                    </div>
                    <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="searchCondition" value="pnid" id="id02">
                        <label class="form-check-label" for="id02">
                            P&ID
                        </label>
                    </div>
                     <div class="form-check form-check-inline">
                        <input class="form-check-input" type="radio" name="searchCondition" value="dataparc" id="id03">
                        <label class="form-check-label" for="id03">
                            DataParc
                        </label>
                    </div>                   
                </div>
            </fieldset>
            <div class="col">
                <input class="form-control form-control--search" id="searchId" value="" name="searchKeyword" placeholder="검색어 입력">
            </div>
        </div>
    </form>
    <div id="_DIV_SEARCH_RESULT_LIST">
        <%-- 검색 결과 화면 --%>
    </div>
</div>


<script>
	var title = "";
	var content = "";
	
    function fnAlert() {
        $.alert({
            title: title,
            content: content,
            type: 'red',
            buttons: {
                '확인': {
                    btnClass: 'btn-red',
                    action: function () {
                    }
                }
            }
        });
    }
    
    function fnSearchResultList() {
    	$.ajax({
            url: "/search/searchList.do",
            type: "POST",
            data: $("#searchForm").serialize(),
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").css("display", "");
            },
            success: function (data) {
                if (window.innerWidth < 1600 || window.innerHeight < 700) {
                    fnResizePopupGlobalSearch(1670, 740, 152, 128);
                }
                $("#_DIV_SEARCH_RESULT_LIST").html(data);
            },
            error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }
    
    function fnGlobalSearchOpenFacilityDetail(iegNo) {
        if (!iegNo) {
            title = "설비정보";
            content = "연결된 설비정보가 없습니다.";
            fnAlert();
            return;
        }
    	fnOpenPopupStandard("/multiview/index.do?t=F&iegNo=" + encodeURIComponent(iegNo), "설비상세정보");
    }
    function fnGlobalSearchOpenPano(modelId, iegNo) {
        window.parent.$(".winbox:not(.min) .wb-min").trigger('click');
        window.top.openPanoInfoPopup(modelId, iegNo, "PANO");
    }   
    
    function fnGlobalSearchOpenModel(modelTarget, modelId) {
        window.parent.$(".winbox:not(.min) .wb-min").trigger('click');
        window.top.modelLoadToUnity(modelTarget, modelId);
    }
    
    function fnGlobalSearchOpenPnid(iegNo) {
    	var targetUrl = "/drawing/equipPnidPopup.do"+ "?searchKeyword=" + encodeURIComponent(iegNo)+ "&popupType=globalSearch";
        window.parent.$(".winbox:not(.min) .wb-min").trigger('click');
        window.top.fnOpenPopupStandard(targetUrl, "P&ID");
    }
    
    function fnGlobalSearchOpenDataParc(el) {
        const dataSvgFileName = el.dataset.svgFile;
        const dataTagNo = el.dataset.tagNo;
        const iegNo = el.dataset.iegNo;

        let targetUrl = "";
		
     	// 도면 경로 및 태그가 있으면 해당 위치로 바로 이동
        if (dataSvgFileName && dataTagNo) {
            const dataPath = "/drawing/dataparc/" + dataSvgFileName.replace(/\\/g, "/");

            targetUrl = "/drawing/equipDataparcPopup.do"
                + "?dataPath=" + encodeURIComponent(dataPath)
                + "&searchTag=" + encodeURIComponent(dataTagNo);
            
         // 태그번호 없이 설비번호로 도면 검색
        } else if (iegNo) {
            targetUrl = "/drawing/equipDataparcPopup.do?searchKeyword=" + encodeURIComponent(iegNo);
        } else {
            title = "DataParc";
            content = "도면 정보가 없습니다.";
            fnAlert();
            return;
        }

        window.parent.$(".winbox:not(.min) .wb-min").trigger("click");
        window.top.fnOpenPopupStandard(targetUrl, "DataParc");
    }
    
    $(function() {
        $("#searchForm").on("submit", function(e) {
            e.preventDefault();
            if ($("#searchId").val().trim()) {
                fnSearchResultList();
            }
        });
    });
</script>
</body>
<c:import url="/footer.do"/>
