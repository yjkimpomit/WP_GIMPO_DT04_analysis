<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<%-- <!-- 로딩박스 --> --%>
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<c:set var="accessUserId" value="16161357"/>

<div class="dashboard-box" id="_DASHBOARD">
    <%-- VIEW DASHBOARD --%>
</div>

<%-- modal popup --%>
<c:import url="/common/modalPopup.do"/>

<script>
    function fnloadDashboard() {
        $.ajax({
            url: "/dashboard/dashboard.do"
            , type: "POST"
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").show();
            }
            , success: function (data) {
                $("#_DASHBOARD").html(data);
            },
            error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    $(function () {
        fnloadDashboard();
    });
</script>

</body>
<c:import url="/footer.do"/>