<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 앱 메인 화면의 서비스 바로가기 페이지 --%>

<%-- 관리자 사번 --%>
<c:set var="accessUserId" value="16161357"/>

<c:import url="/header.do"/>

<body>
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>
<script>
	loadCss("${pageContext.request.contextPath}/resources/user/css/app-main.css");
</script>

<main class="winbox-layout page-content service-hub" aria-labelledby="service-hub-title">
    <div class="page-content__placeholder">
        <h1 id="service-hub-title" class="visually-hidden">서비스 바로가기</h1>
    
        <section class="service-hub__section" aria-labelledby="service-hub-core">
            <div class="service-hub__section-heading">
                <h2 id="service-hub-core">설비·도면 정보</h2>
                <span aria-hidden="true">01 / 03</span>
            </div>
            
            <div class="service-hub__grid">
                <button type="button" class="service-hub__card" data-title="설비정보" onclick="fnWinboxOpen('/drawing/index.do?tabIdx=0', $(this))">
                    <span class="service-hub__index" aria-hidden="true">01</span>
                    <span class="service-hub__card-content"><strong>설비검색</strong><span>설비명 또는 설비번호로 필요한 설비를 빠르게 찾습니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
                <button type="button" class="service-hub__card" data-title="P&ID" onclick="fnWinboxOpen('/drawing/equipPnidGroup.do', $(this))">
                    <span class="service-hub__index" aria-hidden="true">02</span>
                    <span class="service-hub__card-content"><strong>P&amp;ID</strong><span>배관·계장 도면에서 설비 연결 관계를 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
                <button type="button" class="service-hub__card" data-title="DataPARC" onclick="fnWinboxOpen('/drawing/equipDataparcPopup.do', $(this))">
                    <span class="service-hub__index" aria-hidden="true">03</span>
                    <span class="service-hub__card-content"><strong>DataPARC</strong><span>설비 운전 데이터를 조회하고 변화 추이를 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
            </div>
        </section>
        
        <section class="service-hub__section" aria-labelledby="service-hub-diagnosis">
            <div class="service-hub__section-heading">
                <h2 id="service-hub-diagnosis">설비진단</h2>
                <span aria-hidden="true">02 / 03</span>
            </div>
            <div class="service-hub__grid">
                <a href="#" class="service-hub__card" data-title="두케어" onclick="return false;">
                    <span class="service-hub__index" aria-hidden="true">04</span>
                    <span class="service-hub__card-content"><strong>두케어</strong><span>두케어에서 설비 진단 정보와 상태를 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </a>
                <a href="#" class="service-hub__card" data-title="표준복합" onclick="return false;">
                    <span class="service-hub__index" aria-hidden="true">05</span>
                    <span class="service-hub__card-content"><strong>표준복합</strong><span>표준복합에서 설비 진단 자료를 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </a>
                <a href="#" class="service-hub__card" data-title="가상시뮬레이션" onclick="return false;">
                    <span class="service-hub__index" aria-hidden="true">06</span>
                    <span class="service-hub__card-content"><strong>가상시뮬레이션</strong><span>가상 환경에서 설비 운전 시나리오를 살펴봅니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </a>
            </div>
        </section>
        
        <section class="service-hub__section" aria-labelledby="service-hub-more">
            <div class="service-hub__section-heading">
                <h2 id="service-hub-more">현장·운영 서비스</h2>
                <span aria-hidden="true">03 / 03</span>
            </div>
            <div class="service-hub__grid">
                <button type="button" class="service-hub__card" data-title="일일안전현황" onclick="fnWinboxOpen('/dailySafety/index.do?tabIdx=0', $(this))">
                    <span class="service-hub__index" aria-hidden="true">07</span>
                    <span class="service-hub__card-content"><strong>일일안전현황</strong><span>일자별 안전작업 현황과 주요 작업 내용을 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
                <button type="button" class="service-hub__card" data-title="파노라마" onclick="fnWinboxOpen('${panoUrl}', $(this))">
                    <span class="service-hub__index" aria-hidden="true">08</span>
                    <span class="service-hub__card-content"><strong>파노라마</strong><span>현장 파노라마 화면을 통해 설비 위치와 주변 환경을 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
                <button type="button" class="service-hub__card" data-title="위치/건강 모니터링" onclick="window.parent.fnOpenPopup('/pages/health-monitoring/location-health-monitoring.html', window.parent.$(this))">
                    <span class="service-hub__index" aria-hidden="true">09</span>
                    <span class="service-hub__card-content"><strong>위치/건강 모니터링</strong><span>현장 인력의 위치와 건강 상태를 확인합니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
                <button type="button" class="service-hub__card" data-title="AR 현장점검" onclick="window.parent.fnOpenPopup('/pages/ar-site-inspection/ar-site-inspection.html', window.parent.$(this))">
                    <span class="service-hub__index" aria-hidden="true">10</span>
                    <span class="service-hub__card-content"><strong>AR 현장점검</strong><span>증강현실 화면으로 현장 설비를 확인하고 점검 정보를 살펴봅니다.</span></span>
                    <span class="service-hub__arrow" aria-hidden="true"></span>
                </button>
            </div>
        </section>
        
    </div>
    
</main>
    
    
    <%--<h1 class="app-page-title">서비스 바로가기</h1>--%>
    <%--<div class="app-nav-group app-nav-group--primary">
        <div onclick="window.parent.fnLogsheetOepn()" class="app-nav-item" data-title="로그시트">
            <strong>로그시트</strong>
            <p class="text">설비에 부착된 QR코드를 스캔하여 로그시트를 조회·입력합니다.</p>
        </div>
        <div onclick="fnWinboxOpen('/earlywarning/index.do', $(this))" class="app-nav-item" data-title="조기경보">
            <strong>조기경보</strong>
            <p class="text">운전 데이터를 기반으로 이상 징후를 조기에 감지합니다.</p>
        </div>
        <div onclick="fnWinboxClose()" class="app-nav-item" data-title="3D모델">
            <strong>3D 모델</strong>
            <p class="text">3D 모델에서 설비를 선택하여 관련 정보를 통합 조회합니다.</p>
        </div>
    </div>
    <div class="app-nav-group app-nav-group--secondary">
        <div onclick="fnWinboxOpen('/dailySafety/index.do?tabIdx=0', $(this))" class="app-nav-item" data-title="일일안전현황">
            <strong>일일안전현황</strong>
            <p class="text">일자별 안전작업 현황과 주요 작업 내용을 확인합니다.</p>
        </div>
        
        <c:set var="panoUrl" value="/pcm/vi/main.do?pct_sn=84&pci_tag=Taean9_10"/>
        <c:if test="${sessionScope.eqOrgNo eq '5100'}">
            <c:set var="panoUrl" value="/pcm/vi/main.do?pct_sn=8&pci_tag="/>
        </c:if>
        <div onclick="fnWinboxOpen('${panoUrl}', $(this))" class="app-nav-item" data-title="파노라마">
            <strong>파노라마</strong>
            <p class="text">현장 파노라마 화면을 통해 설비 위치와 주변 환경을 확인합니다.</p>
        </div>
        <div onclick="fnWinboxOpen('/drawing/index.do?tabIdx=0', $(this))" class="app-nav-item" data-title="설비검색">
            <strong>설비검색</strong>
            <p class="text">설비명 또는 설비번호로 설비 정보를 빠르게 조회합니다.</p>
        </div>
        <div onclick="fnWinboxOpen('/serviceinfo/index.do?tabIdx=0', $(this))" class="app-nav-item" data-title="개선사항">
            <strong>서비스 개선사항</strong>
            <p class="text">시스템 이용 중 불편사항이나 개선 의견을 등록합니다.</p>
        </div>
    </div>--%>


<script>
    function fnWinboxClose() {
        // all close
        window.parent.$('.wb-close').trigger('click');
    }

    function fnWinboxOpen(url, t) {
        window.parent.fnAppMainWinboxOpen(url, t);
    }
</script>
</body>
<c:import url="/footer.do"/>