<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 일일안전현황 > 일일안전작업현황 --%>

<%--<div class="tab-pane fade show active" id="tab01-pane" role="tabpanel" aria-labelledby="tab01" tabindex="0">--%>
<div class="winbox-layout page-content daily-status-page">

    <h1 class="page-content__heading">일일안전 작업현황</h1>

    <section class="daily-status-section">
        <div class="section-header">
            <h2 class="section-title">종합현황</h2>
        </div>
        <div class="daily-summary-grid">
            <div class="daily-summary-card">
                <div class="table-responsive">
                    <table class="data-table data-table--list" aria-label="종합현황-위험작업">
                        <thead>
                        <tr>
                            <th scope="colgroup" colspan="13">안전작업허가서 주요 위험작업(건수)</th>
                        </tr>
                        <tr>
                            <th scope="col" data-field="구분">구분</th>
                            <th scope="col" data-field="일반">일반</th>
                            <th scope="col" data-field="화기">화기</th>
                            <th scope="col" data-field="밀폐">밀폐</th>
                            <th scope="col" data-field="고소">고소</th>
                            <th scope="col" data-field="중량물">중량물</th>
                            <th scope="col" data-field="정전">정전</th>
                            <th scope="col" data-field="굴착">굴착</th>
                            <th scope="col" data-field="잠수">잠수</th>
                            <th scope="col" data-field="방사선">방사선</th>
                            <th scope="col" data-field="화학물질">화학물질</th>
                            <th scope="col" data-field="기타">기타</th>
                            <th scope="col" data-field="합계">합계</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row" data-field="구분">(건)</th>
                            <td data-field="일반" class="_WR_HAZARD" id="_WR_G">0</td>
                            <td data-field="화기" class="_WR_HAZARD" id="_WR_HW">0</td>
                            <td data-field="밀폐" class="_WR_HAZARD" id="_WR_C">0</td>
                            <td data-field="고소" class="_WR_HAZARD" id="_WR_H">0</td>
                            <td data-field="중량물" class="_WR_HAZARD" id="_WR_HO">0</td>
                            <td data-field="정전" class="_WR_HAZARD" id="_WR_PO">0</td>
                            <td data-field="굴착" class="_WR_HAZARD" id="_WR_E">0</td>
                            <td data-field="잠수" class="_WR_HAZARD" id="_WR_D">0</td>
                            <td data-field="방사선" class="_WR_HAZARD" id="_WR_R">0</td>
                            <td data-field="화학물질" class="_WR_HAZARD" id="_WR_CS">0</td>
                            <td data-field="기타" class="_WR_HAZARD" id="_WR_O">0</td>
                            <td data-field="합계" class="text-bg-light _WR_HAZARD" id="_WR_TOT">0</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="daily-summary-card">
                <div class="table-responsive">
                    <table class="data-table data-table--list" aria-label="종합현황-인력현황">
                        <thead>
                        <tr>
                            <th scope="colgroup" colspan="3">인력현황(명)</th>
                        </tr>
                        <tr>
                            <th scope="col" data-field="경상">경상</th>
                            <th scope="col" data-field="외부">외부</th>
                            <th scope="col" data-field="합계">합계</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td data-field="경상" id="_WR_SUM_NUMBER_ONSITE">0</td>
                            <td data-field="외부" id="_WR_SUM_NUMBER_OUTSIDE">0</td>
                            <td data-field="합계" class="text-bg-light" id="_WR_SUM_NUMBER">0</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="daily-summary-card">
                <div class="table-responsive">
                    <table class="data-table data-table--list" aria-label="종합현황-전체작업">
                        <thead>
                        <tr>
                            <th scope="col" rowspan="2" style="height: 80px;">전체작업(건)</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td data-field="전체작업" id="_WR_SUM_WORK">0</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
            <div class="daily-summary-card">
                <div class="table-responsive">
                    <table class="data-table data-table--list" aria-label="종합현황-등록현황">
                        <thead>
                        <tr>
                            <th scope="colgroup" colspan="3">등록현황(건)</th>
                        </tr>
                        <tr>
                            <th scope="col" data-field="등록작업">등록작업</th>
                            <th scope="col" data-field="GENi 작업">GENi 작업</th>
                            <th scope="col" data-field="미등록">미등록</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <td data-field="등록작업" id="_WR_STATUS_P">0</td>
                            <td data-field="GENi 작업" id="_WR_STATUS_D">0</td>
                            <td data-field="미등록" id="_WR_STATUS_C">0</td>
                        </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>

    <section class="daily-status-section">
        <div class="section-header"><h2 class="section-title">현황등록</h2></div>

        <div class="calendar-box">
            <div class="calendar-header">
                <div class="form-choice-list">
                    <label class="visually-hidden" for="selectYear">연도 선택</label>
                    <select class="form-select" aria-label="연도 선택" id="selectYear">
                        <option selected>연도 선택</option>
                    </select>
                    <label class="visually-hidden" for="selectMonth">월 선택</label>
                    <select class="form-select" aria-label="월 선택" id="selectMonth">
                        <option selected>월 선택</option>
                    </select>
                </div>

                <button type="button" class="button button--primary" onclick="fnDailyRiskEntryPop('', 0, '')">현황 등록하기</button>
            </div>

            <div class="calendar-body">
                <div class="calendar-list date" id="calendar-list"></div>
            </div>
        </div>
    </section>

    <div class="result-panel__body" id="_SAFETY_WORK_REPORT_LIST">
        <%-- 검색결과 리스트 : /detail/workReport_list.jsp --%>
    </div>
</div>

<form id="searchWorkReportForm" name="searchWorkReportForm" method="get">
    <input type="hidden" name="searchDate" id="searchDate" value="${workReportVO.searchDate}">
    <input type="hidden" name="pageIndex" id="pageIndex" value="${workReportVO.pageIndex}">
    <input type="hidden" name="orderColumn" id="orderColumn" value="${workReportVO.orderColumn}">
    <input type="hidden" name="orderType" id="orderType" value="${workReportVO.orderType}">
    <input type="hidden" name="searchCondition" id="searchCondition" value="${workReportVO.searchCondition}">
    <input type="hidden" name="searchKeyword" id="searchKeyword" value="${workReportVO.searchKeyword}">
</form>

<script src="${pageContext.request.contextPath}/resources/user/js/dailysafety/calendar.js"></script>
<script>
    <%-- /* SORT */ --%>

    function fnWorkReportOrder(o) {
        orderColumn = o.attr("data-order-column");
        orderType = o.attr("data-order-type");

        if (orderType === "asc") {
            orderType = "desc";
        } else {
            orderType = "asc";
        }

        $("#searchWorkReportForm #orderColumn").val(orderColumn);
        $("#searchWorkReportForm #orderType").val(orderType);

        fnSearchWorkReportList(paramSearchDate);
    }

    <%-- /* 등록 팝업 */ --%>

    function fnDailyRiskEntryPop(row, idx, paramUnregistData) {
        var mode = "I";

        if (idx > 0) {
            mode = "U";
        }

        // active class
        $("._TR_WORK_REPORT").removeClass("active");
        $(row).addClass("active");

        /* 팝업 */
        var url = "/dailySafety/workReportForm.do?isrIdx=" + idx + "&mode=" + mode + "&searchDate=" + paramSearchDate;

        if (paramUnregistData && paramUnregistData !== '') {
            url += "&paramUnregistData=" + encodeURIComponent(paramUnregistData);
        }

        var box = new WinBox("일일안전작업현황", {
            url: url,
            width: Math.min(1204, window.innerWidth - 20) + "px",
            height: Math.min(720, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    <%-- 페이지 이동 부분 --%>

    function fnPageMove(f) {
        var currentPage = parseInt($("#currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }
            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }
            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#currentPage").val(totalPage);
                return false;
            }
        }

        $("#currentPage").val(currentPage);

        $("#searchWorkReportForm #pageIndex").val(currentPage);
        fnSearchWorkReportList(paramSearchDate);
    }

    <%-- /* 리스트에서 상세 팝업 */ --%>

    function fnShowDetail(row, idx) {
        fnDailyRiskEntryPop(row, idx, '');
    }

    <%-- /* 엑셀 다운로드 */ --%>

    function fnExcelDownloadWorkReport() {
        $.ajax({
            type: "POST"
            , url: "/dailySafety/workReportExcelDownload.do"
            , data: $("#searchWorkReportForm").serialize()
            , xhrFields: {
                responseType: 'blob'  // 응답을 Blob 형식으로 받기
            }
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (response, status, xhr) {
                //현재 날짜 가져오기
                var currentDate = new Date();
                var formattedDate = currentDate.getFullYear() + '-' +
                    (currentDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                    currentDate.getDate().toString().padStart(2, '0');

                // Blob을 사용하여 파일 다운로드 처리
                var blob = response;
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = "일일안전작업현황_" + formattedDate + ".xlsx";
                link.click();  // 다운로드 트리거
            }
            , error: function (request, status, error) {
                alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    <%-- /* 미등록 작업보기 팝업 */ --%>

    function fnWorkReportUnRegistPop() {
        var data = "?pageIndex=1&unregistSearchDate=" + paramSearchDate;
        var url = "/dailySafety/popSearchWorkOrderUnregist.do" + data;
        var box = new WinBox("등록현황 관리", {
            url: url,
            width: Math.min(1204, window.innerWidth - 20) + "px",
            height: Math.min(720, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    function fnSearchKeyword(e) {
        if (e.key === "Enter" || e.keyCode === 13) {
            $("#searchWorkReportForm #pageIndex").val(1);
            $("#searchWorkReportForm #searchCondition").val($("#selectSearchCondition option:selected").val());
            $("#searchWorkReportForm #searchKeyword").val($("#txtSearchKeyword").val());

            fnSearchWorkReportList(paramSearchDate);
        }
    }
</script>
