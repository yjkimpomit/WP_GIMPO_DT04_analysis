<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 일일안전현황 > 일일안전작업현황 등록화면의 오더번호 검색 팝업 --%>

<c:import url="/header.do"/>

<body>
<%--  timepicker --%>
<link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/timepicker/jquery.timepicker.min.css">
<script src="${pageContext.request.contextPath}/resources/user/js/timepicker/jquery.timepicker.min.js"></script>

<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="searchWorkOrderPopup">
    <h1 class="page-content__heading visually-hidden">일일안전작업 > 오더번호 검색</h1>

    <!-- 사번의 오더정보 팝업 -->
    
    <div class="splitview" id="searchResultWorkOrderContentPop">
        <aside class="splitview__pane splitview__pane--sidebar" aria-label="오더번호-검색">
            <!-- 검색결과 리스트 -->
            <form class="filter-panel" id="form_pop_search_work_order" name="form_pop_search_work_order" method="post" autocomplete="off">
                <input type="hidden" id="pageIndex" name="pageIndex" value="1">
                <input type="hidden" id="paramOrderSearchDate" name="searchDate" value="${workReportVO.searchDate}">
                <input type="hidden" id="paramPlanBy" name="planBy" value="${workReportVO.workSvCode}">
                
                <div class="filter-panel__header">
                    <span class="filter-panel__title">검색</span>
                    <button class="filter-panel__toggle"
                            type="button"
                            aria-label="오더번호 검색 접기"
                            aria-expanded="true"
                            aria-controls="filter-panel-search"></button>
                </div>
                
                <div class="filter-panel__search" id="filter-panel-search">
                    <!-- filter-panel__fields 안에서 form-field 단위로 반복 -->
                    <div class="filter-panel__fields">
                        
                        <div class="form-field">
                            <label class="form-label" for="searchWorkOrderNo">오더번호</label>
                            <input type="text" class="form-control" id="searchWorkOrderNo" name="searchWorkOrderNo" value="${workReportVO.workOrderNo}">
                        </div>
                        <div class="form-field">
                            <label class="form-label" for="searchWorkOrderDescription">오더명</label>
                            <input type="text" class="form-control" id="searchWorkOrderDescription" name="searchWorkOrderDescription">
                        </div>
                        <div class="form-field">
                            <label class="form-label" for="searchPlanName">감독자</label>
                            <input type="text" class="form-control" id="searchPlanName" name="searchPlanName" value="${workReportVO.workSvName}">
                        </div>
                        <div class="form-field">
                            <label class="form-choice">
                                <input type="checkbox" value="1" id="check_searchType" name="searchType">
                                <span>전체</span>
                            </label>
                        </div>
                        
                    </div>
                    
                    <div class="filter-panel__actions">
                        <button type="button" class="button button--primary" onclick="fnBtnPopSearchWorkOrder()">검색</button>
                    </div>
                </div>
                
            </form>
        </aside>
        
        <div class="splitview__pane splitview__pane--content">
            <h2 class="visually-hidden">오더번호 검색</h2>
            
            <div class="result-panel" id="_POP_SEARCH_WORK_ORDER_LIST">
                <%-- 오더 검색 리스트 --%>
            </div>
        </div>
    </div>
    
</main>

<script>
    /* 선택한 오더 정보를 폼에 등록 */
    function fnPopCallBackWorkOrder(workOrderType, code, authoNo) {
        window.parent.fnPopCallBackWorkOrder(workOrderType, code, authoNo);
        window.parent.$(".winbox.app-winbox.app-winbox--detail.focus").find(".wb-close").trigger("click");
    }

    // 오더번호 검색 리스트
    function fnSearchWorkOrderList() {
        $.ajax({
            type: "post"
            , url: "/dailySafety/popSearchWorkOrderList.do"
            , data: $("#form_pop_search_work_order").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_POP_SEARCH_WORK_ORDER_LIST").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n error:" + error);
            }
            , complete: function (data) {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    /* 검색 버튼 클릭 */
    function fnBtnPopSearchWorkOrder() {
        $("#form_pop_search_work_order #pageIndex").val(1);
        fnSearchWorkOrderList();
    }

    /* 오더번호 검색 팝업창의 페이지 처리 */
    function fnPageMovePop(f) {
        var currentPage = parseInt($("#searchWorkOrderPopForm #currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }
            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }
            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#searchWorkOrderPopForm #currentPage").val(totalPage);
                return false;
            }
        }

        $("#searchWorkOrderPopForm #currentPage").val(currentPage);
        $("#form_pop_search_work_order #pageIndex").val(currentPage);

        fnSearchWorkOrderList();
    }

    $(function () {
        fnSearchWorkOrderList();
    });
</script>
</body>
<c:import url="/footer.do"/>
