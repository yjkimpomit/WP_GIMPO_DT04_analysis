<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 일일안전작업현황 > 등록현황관리 팝업창 --%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="workReportUnRegistPopup">
    <h1 class="page-content__heading visually-hidden">동록현황 관리</h1>

    <div class="splitview" id="workReportUnRegistPopupContentPop">
        
        <aside class="splitview__pane splitview__pane--sidebar" aria-label="동록현황-검색">
        <!-- 검색결과 리스트 -->
            <form class="filter-panel" id="form_pop_search_work_report_unregist" method="post" autocomplete="off">
                <input type="hidden" name="pageIndex" id="pageIndex" value="1">
                <input type="hidden" name="searchDate" id="unregistSearchDate" value="${param.unregistSearchDate}">
                
                <div class="filter-panel__header">
                    <span class="filter-panel__title">검색</span>
                    <button class="filter-panel__toggle"
                            type="button"
                            aria-label="동록현황 검색 접기"
                            aria-expanded="true"
                            aria-controls="filter-panel-search"></button>
                </div>
                
                <div class="filter-panel__search" id="filter-panel-search">
                    <!-- filter-panel__fields 안에서 form-field 단위로 반복 -->
                    <div class="filter-panel__fields">
                        
                        <div class="form-field">
                            <label class="form-label" for="searchWorkOrderNo">오더번호</label>
                            <input class="form-control" type="number" id="searchWorkOrderNo" name="searchWorkOrderNo">
                        </div>
                        <div class="form-field">
                            <label class="form-label" for="searchWorkOrderDescription">오더명</label>
                            <input class="form-control" id="searchWorkOrderDescription" name="searchWorkOrderDescription">
                        </div>
                        <div class="form-field">
                            <label class="form-label" for="searchPlanName">감독자</label>
                            <input class="form-control" id="searchPlanName" name="searchPlanName">
                        </div>
                    </div>
                    
                    <div class="filter-panel__actions">
                        <button type="button" class="button button--primary" onclick="fnBtnPopSearchWorkReportUnregist()">검색</button>
                    </div>
                </div>
            </form>
        </aside>
        
        <div class="splitview__pane splitview__pane--content">
            <div class="result-panel" id="_POP_SEARCH_WORK_UNREGIST_LIST">
                <%-- 미등록 검색 리스트 --%>
            </div>
        </div>
    </div>
    
</main>

<script>
    <%-- // 미등록 팝업 창 > 검색 처리 --%>
    function fnPopSearchWorkReportUnregist() {
        $.ajax({
            type: "post"
            , url: "/dailySafety/popSearchWorkOrderUnregistList.do"
            , data: $("#form_pop_search_work_report_unregist").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_POP_SEARCH_WORK_UNREGIST_LIST").html(data);
            }
            , error: function (request, status, error) {
                alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
            }
            , complete: function (data) {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    /* 등록현황관리 팝업창의 페이지 처리 */
    function fnPageMovePopUnregist(f) {
        var currentPage = parseInt($("#searchWorkReportUnregistPopForm #currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }
            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }
            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#searchWorkReportUnregistPopForm #currentPage").val(totalPage);
                return false;
            }
        }

        $("#form_pop_search_work_report_unregist #pageIndex").val(currentPage);

        fnPopSearchWorkReportUnregist();
    }

    <%-- /* 수정 팝업 */ --%>

    function fnDailyRiskEntryPop(row, idx, paramUnregistData) {
        var mode = "I";

        if (idx > 0) {
            mode = "U";
        }

        // active class
        $("._TR_WORK_UNREGIST").removeClass("active");
        $(row).addClass("active");

        /* 팝업 */
        var url = "/dailySafety/workReportForm.do?isrIdx=" + idx + "&mode=" + mode;

        if (paramUnregistData && paramUnregistData !== '') {
            url += "&paramUnregistData=" + encodeURIComponent(paramUnregistData);
        }

        var isUpdate = false;
        var box = new WinBox("일일안전작업현황", {
            url: url,
            width: Math.min(1400, window.innerWidth - 20) + "px",
            height: Math.min(window.innerHeight - 20, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
                window.parent.isUpdate = true;
            }
        });
    }

    /* 미등록 팝업창 검색 버튼 처리 */
    function fnBtnPopSearchWorkReportUnregist() {
        $("#form_pop_search_work_report_unregist #pageIndex").val(1);
        fnPopSearchWorkReportUnregist();
    }

    $(function () {
       fnBtnPopSearchWorkReportUnregist();
    });
</script>
</body>
<c:import url="/footer.do"/>