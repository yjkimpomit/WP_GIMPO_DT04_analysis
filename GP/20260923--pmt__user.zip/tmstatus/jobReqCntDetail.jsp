<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- 작업요청 건수 상세 목록 -->--%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="jobReqCntDetailBox">
    <div class="page-content__placeholder content-section">

        <div class="result-panel" id="jobReqCntDetailList">
            <%-- 리스트 부분 --%>
        </div>

    </div>
</main>

<form id="formJobReqCntDetail" name="formJobReqCntDetail" method="post">
    <input type="hidden" id="pageIndex" name="pageIndex" value="1"/>
    <input type="hidden" id="requestNo" name="requestNo" value="<c:out value='${requestNo}'/>">
    <input type="hidden" id="requestType" name="requestType" value="<c:out value='${requestType}'/>">
    <input type="hidden" id="startDate" name="startDate" value="<c:out value='${startDate}'/>">
    <input type="hidden" id="endDate" name="endDate" value="<c:out value='${endDate}'/>">
</form>

<script>
    /* list */
    function fnJobReqCntDetailList() {
        $.ajax({
            type: "post"
            , url: "/tmStatus/jobReqCntDetailList.do"
            , data: $("#formJobReqCntDetail").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#jobReqCntDetailList").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    <%-- 페이지 이동 부분 --%>
    function fnPageMove(f) {
        var currentPage = parseInt($("#currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }

            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }

            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#currentPage").val(totalPage);
                return false;
            }
        }

        $("#currentPage").val(currentPage);
        $("#formJobReqCntDetail #pageIndex").val(currentPage);

        fnJobReqCntDetailList();
    }

    $(function () {
        fnJobReqCntDetailList();
    });
</script>
</body>
<c:import url="/footer.do"/>