<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 다발TM현황-상세정보 --%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="multTMDetailBox">
    <div class="result-panel" id="multTMDetailList">
        <%-- 리스트 부분 --%>
    </div>
</main>

<form id="formMultipleTmStatsDetailForm" name="formMultipleTmStatsDetailForm" method="post">
    <input type="hidden" name="requestNo" id="requestNo" value="${itemNo}">
    <input type="hidden" name="pageIndex" id="pageIndex" value="1">
</form>

<script>
    /* 리스트 */
    function fnMultipleTmStatsDetailList() {
        $.ajax({
            type: "post",
            url: "/tmStatus/multipleTMStatsDetailList.do"
            , data: $("#formMultipleTmStatsDetailForm").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#multTMDetailList").html(data);
            },
            error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    <%-- 페이지 이동 부분 --%>
    function fnDetailPageMove(f) {
        var detailCurrentPage = parseInt($("#detailCurrentPage").val());

        if (f === 'P') {
            if (detailCurrentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }

            detailCurrentPage = detailCurrentPage - 1;
        } else if (f === 'N') {
            if (detailCurrentPage === totalPages) {
                alert("마지막 페이지입니다.");
                return false;
            }

            detailCurrentPage = detailCurrentPage + 1;
        } else if (f === 'M') {
            if (detailCurrentPage > totalPages) {
                alert("마지막 페이지는 " + totalPages + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#detailCurrentPage").val(totalPages);
                return false;
            }
        }

        $("#detailCurrentPage").val(detailCurrentPage);
        $("#formMultipleTmStatsDetailForm #pageIndex").val(detailCurrentPage);

        fnMultipleTmStatsDetailList();
    }

    $(function () {
        fnMultipleTmStatsDetailList();
    });
</script>
</body>
<c:import url="/footer.do"/>
