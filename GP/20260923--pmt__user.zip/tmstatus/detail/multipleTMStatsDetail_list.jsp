<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 다발TM현황-상세정보 리스트 --%>

<script>
    var totalPages = ${paginationInfo.totalPageCount};
</script>

<header class="result-header">
    <h1 class="result-header__title">
        <span>${equipNm}</span>
        <span class="result-header__count">(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</span>
    </h1>

    <div class="result-header__actions">
        <nav class="pagination" aria-label="페이지 이동">
            <input type="number" id="detailCurrentPage" class="form-control form-control--page" aria-label="이동할 페이지 번호" value="<c:out value='${paginationInfo.currentPageNo}'/>">
            <span aria-hidden="true">/</span>
            <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="button button--neutral" onclick="fnDetailPageMove('M')">이동</button>
            <button type="button" class="button button--neutral" onclick="fnDetailPageMove('P')">이전</button>
            <button type="button" class="button button--neutral" onclick="fnDetailPageMove('N')">다음</button>
        </nav>
    </div>
</header>

<div class="table-responsive">
    <table id="tblMultiTMStatsDetail" class="data-table data-table--list" data-tab-id="workReqPane" aria-label="다발TM현황-상세정보">
        <thead>
        <tr>
            <th scope="col" data-field="호기">호기</th>
            <th scope="col" data-field="요청번호">요청번호</th>
            <th scope="col" data-field="진행상태">진행상태</th>
            <th scope="col" data-field="요청명">요청명</th>
            <th scope="col" data-field="설비번호">설비번호</th>
            <th scope="col" data-field="설비명">설비명</th>
            <th scope="col" data-field="요청자">요청자</th>
            <th scope="col" data-field="요청부서">요청부서</th>
            <th scope="col" data-field="요청일자">요청일자</th>
            <th scope="col" data-field="감독부서">감독부서</th>
            <th scope="col" data-field="증상">증상</th>
        </tr>
        </thead>
        <tbody>
        <%-- 데이터가 없을 경우 --%>
        <c:if test="${fn:length(list) == 0}">
            <tr>
                <td colspan="11">
                    <div class="no-data">
                        조회된 데이터가 없습니다.
                    </div>
                </td>
            </tr>
        </c:if>
        <c:forEach var="data" items="${list}" varStatus="status">
            <tr>
                <th scope="row" data-field="호기">${data.hoki}</th>
                <th scope="col" data-field="요청번호">${data.noticeNo}</th>
                <td data-field="진행상태">${data.noticeStatusnm}</td>
                <td data-field="요청명">${data.description}</td>
                <td data-field="설비번호">${data.itemNo}</td>
                <td data-field="설비명">${data.equipNm}</td>
                <td data-field="요청자">${data.reqBynm}</td>
                <td data-field="요청부서">${data.reqDeptNonm}</td>
                <td data-field="요청일자">${data.reqDate}</td>
                <td data-field="감독부서">${data.deptNonm}</td>
                <td data-field="증상">${data.symptomnm}</td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
