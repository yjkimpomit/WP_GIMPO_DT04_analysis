<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<div class="winbox-layout page-content">
	<div class="page-content__placeholder">
		<div class="splitview">
			<aside class="splitview__pane splitview__pane--sidebar" aria-label="정보 검색">

				<!-- 검색영역 -->
				<form class="filter-panel" id="form_search_job_reqeust_count" method="post" autocomplete="off">

					<div class="filter-panel__header">
						<span class="filter-panel__title">검색</span>
						<button class="filter-panel__toggle" 
								type="button"
								aria-label="정보 검색 접기" 
								aria-expanded="true" 
								aria-controls="filter-panel-search"></button>
					</div>
					
					<div class="filter-panel__search" id="filter-panel-search">
                        <!-- filter-panel__fields 안에서 form-field 단위로 반복 -->
                        <div class="filter-panel__fields">
    
                            <!-- 사업소 영역 추후에 사용할 수 있음 -->
                            <!-- <div class="col-md-6 col-lg-4 col-xxl-2">
                                <label class="form-label" for="bizOfcSel">사업소</label>
                                <select class="form-select" aria-label="사업소 선택" id="bizOfcSel" disabled>
                                    <option>사업소 선택</option>
                                    <option value="1" selected>평택2복합</option>
                                </select>
                            </div> -->
    
                            <fieldset class="form-field">
                                <legend class="form-label">검색 유형</legend>
                                <div class="form-field__content form-choice-list">
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchType01" name="searchType" value="1" checked>
                                        <span>요청 유형</span>
                                    </label>
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchType02" name="searchType" value="2">
                                        <span>중요도</span>
                                    </label>
                                </div>
                            </fieldset>
    
                            <fieldset class="form-field">
                                <legend class="form-label" id="dateRangePicker">검색기간(확정일)</legend>
    
                                <div class="form-control-group">
                                    <label>
                                        <span class="visually-hidden">시작일</span>
                                        <input type="date" class="form-control" id="confirmedDtStart" name="searchPeriodStart">
                                    </label>
    
                                    <label>
                                        <span class="visually-hidden">종료일</span>
                                        <input type="date" class="form-control" id="confirmedDtEnd" name="searchPeriodEnd">
                                    </label>
                                </div>
                            </fieldset>
    
                            <fieldset class="form-field">
                                <legend class="form-label">검색조건</legend>
                                <div class="form-field__content form-choice-list">
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchCondition05" name="searchCondition" value="5" data-label="설비" checked>
                                        <span>설비별</span>
                                    </label>
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchCondition02" name="searchCondition" value="2" data-label="요청부서">
                                        <span>요청부서별</span>
                                    </label>
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchCondition03" name="searchCondition" value="3" data-label="감독부서">
                                        <span>감독부서별</span>
                                    </label>
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchCondition04" name="searchCondition" value="4" data-label="요청자">
                                        <span>요청자별</span>
                                    </label>
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchCondition01" name="searchCondition" value="1" data-label="호기">
                                        <span>호기별</span>
                                    </label>
                                    <label class="form-choice">
                                        <input type="radio" id="rbSearchCondition06" name="searchCondition" value="6" data-label="요청부서/감독부서">
                                        <span>요청부서별 & 감독부서별</span>
                                    </label>
                                </div>
                            </fieldset>
    
                            <div class="form-field">
                                <label class="form-label" for="reqDeptOption">요청부서</label>
                                <div class="form-control-group">
                                <input class="form-control form-control--search" id="reqDeptOption" name="reqDeptNo" disabled onclick="searchReqDeptTreePopup($(this));">
                                <input class="form-control" type="text" value="" id="reqDeptInput" disabled="">
                                </div>
                            </div>
    
                            <div class="form-field">
                                <label class="form-label" for="supvDeptOption">감독부서</label>
                                <div class="form-control-group">
                                <input class="form-control form-control--search" id="supvDeptOption" name="deptNo" disabled onclick="searchReqTreePopup($(this));">
                                <input class="form-control" type="text" value="" id="supvDeptInput" disabled="">
                                </div>
                            </div>
                        </div>
    
                        <div class="filter-panel__actions">
                            <button type="button" class="button button--primary" onclick="fnJobRequestCountSearch()">검색</button>
                        </div>
					</div>
					
				</form>
			
			</aside>
			<section class="splitview__pane splitview__pane--content" aria-label="검색 결과">
				<h1 class="page-content__heading">작업요청 건수</h1>
				
				<%-- data-grid : 결과 리스트 뷰 --%>
				<div class="result-panel" id="_VIEW_RESULT_SHOW">
					<div class="result-chart" id="divResultChart">
						<div class="chart-item chart-container">
                        <%-- 차트 : /detail/jobReqCnt_chart.jsp --%>
                        </div>
					</div>

					<div class="result-table" id="_VIEW_JOB_RC_LIST">
						<%-- 조회 리스트 부분 : /detail/jobReqCnt_list.jsp --%>
					</div>
				</div>
				
			</section>
		</div>
	</div>
</div>

<script>
    function setDate() {
        //날짜 현재날짜 기준 한 달 전 세팅
        var today = new Date();
        var yyyy = today.getFullYear();
        var mm = ("0" + (today.getMonth() + 1)).slice(-2); // 월은 0부터 시작하므로 +1
        var dd = ("0" + today.getDate()).slice(-2);
        var currentDate = yyyy + "-" + mm + "-" + dd;
        $('#confirmedDtEnd').val(currentDate); // 첫 번째 input에 오늘 날짜 설정

        // 두 번째 input 태그 (한 달 전 날짜로 설정)
        today.setMonth(today.getMonth() - 1); // 현재 날짜 기준 한 달 전으로 설정
        var lastMonthDate = today.getFullYear() + "-" + ("0" + (today.getMonth() + 1)).slice(-2) + "-" + ("0" + today.getDate()).slice(-2);
        $('#confirmedDtStart').val(lastMonthDate); // 두 번째 input에 한 달 전 날짜 설정
    }

    //요청부서별 , 감독부서별, 요청자별, 요청부서별&감독부서별
    document.querySelectorAll('input[type="radio"][name="searchCondition"]').forEach(radio => {
        radio.addEventListener('change', function () {
            //요청부서
            var reqDeptInput = document.getElementById('reqDeptOption');
            //요청부서명
            var reqDeptName = document.getElementById('reqDeptInput');
            //감독부서별
            var supDeptInput = document.getElementById('supvDeptOption');
            //감독부서명
            var supDeptName = document.getElementById('supvDeptInput');

            //요청부서별 or 요청자별
            if (this.value == 2 || this.value == 4) {
                supDeptInput.disabled = true;
                supDeptInput.value = '';
                supDeptName.value = '';
                reqDeptInput.disabled = false;
                //감독부서별
            } else if (this.value == 3) {
                supDeptInput.disabled = false;
                reqDeptInput.disabled = true;
                reqDeptInput.value = '';
                reqDeptName.value = '';
                //요청부서별 and 감독부서별
            } else if (this.value == 6) {
                supDeptInput.disabled = false;
                reqDeptInput.disabled = false;
            } else {
                supDeptInput.disabled = true;
                reqDeptInput.disabled = true;
                supDeptInput.value = '';
                supDeptName.value = '';
                reqDeptInput.value = '';
                reqDeptName.value = '';
            }
        });
    });

    function fnChangeLabel() {
        var dataFieldName = $("[name=rbSearchCondition]:checked").attr('data-label');
        $("#jobReqCntList").find('[data-field="호기"]').eq(0).text(dataFieldName);
    }

    <%-- 검색 차트/리스트 --%>

    function fnJobRequestCountSearch() {
        var stval = "";
        var endval = "";

        //조회 시작일
        stval = document.getElementById("confirmedDtStart").value;
        //조회 종료일
        endval = document.getElementById("confirmedDtEnd").value;

        if (stval !== "" && endval === "") {
            alert("조회 종료일을 선택해주세요");
            return false;
        } else if (stval === "" && endval !== "") {
            alert("조회 시작일을 선택해주세요");
            return false;
        } else if (stval > endval) {
            alert("조회 종료일을 시작일 이전으로 설정할 수 없습니다.\n조회 종료일을 다시 선택해주세요.");
            return false;
        }

        <%-- 검색 차트 --%>
        $.ajax({
            type: "post"
            , url: "/tmStatus/jobReqCntChart.do"
            , data: $("#form_search_job_reqeust_count").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $(".chart-item").html(data);

            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });

        <%-- 검색 리스트 --%>
        $.ajax({
            type: "post"
            , url: "/tmStatus/jobReqCntList.do"
            , data: $("#form_search_job_reqeust_count").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_VIEW_JOB_RC_LIST").html(data);
                fnChangeLabel();
                $("#loadingBar").css("display", "none");
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });

        $("#_VIEW_RESULT_SHOW").removeClass('d-none');
    }

    <%-- 상세정보 팝업 --%>

    function showDetail(row, r) {
        $("._TR_JOB_RC").removeClass("active");
        $(row).addClass("active");

        var requestNo = $(row).attr("data-request-no");
        var requestType = r;

        if (requestType === 6) {
            requestNo = document.getElementById("rnd").value;
        }

        var startDate = $("#confirmedDtStart").val();
        var endDate = $("#confirmedDtEnd").val();
        var data = "?requestNo=" + requestNo + "&requestType=" + requestType + "&startDate=" + startDate + "&endDate=" + endDate;
        var url = "/tmStatus/jobReqCntDetail.do" + data;

        var box = new WinBox("작업요청 건수 > 상세정보", {
            url: url,
            width: Math.min(1400, window.innerWidth - 20) + "px",
            height: Math.min(720, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    $(function () {
        setDate();
        fnJobRequestCountSearch();
    });
</script>


