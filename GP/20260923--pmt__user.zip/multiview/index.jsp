<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<style>
    .tab-pane iframe {
        display: block;
        width: 100%;
        height: 100%;
        border: 0;
    }
</style>

<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<iframe id="_FACILITY_VIEW" width="100%" height="100%"></iframe>

<%--<div class="idms-box">
    <div class="grid-2x2">
        <div class="cell">
            <div class="cell-control">
                <span title="전체화면 보기" class="icon fullscr" onclick="showFullScreen(event);"></span>
                <span title="전체화면 닫기" class="icon fullscr-close" onclick="closeFullScreen(event);"></span>
            </div>
            <div class="idms-container ic-01">
                <!-- tab nav -->
                <ul class="nav nav-underline">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="facility-tab01" data-bs-toggle="tab" data-bs-target="#facility-tab01-pane" type="button" role="tab" aria-controls="facility-tab01-pane" aria-selected="true">설비정보 - <span class="text">${geniInfo.iegDecription}</span></button>
                    </li>
                </ul>
                <!-- tab-content -->
                <div class="tab-content" id="idmsTabContent01">
                    <div class="tab-pane fade show active" id="facility-tab01-pane" role="tabpanel" aria-labelledby="facility-tab01-pane" tabindex="0">
                        <div style="height: 100%;overflow: hidden;">
                            &lt;%&ndash; 설비정보 <c:import url="/multiview/facilityDetail.do?iegNo=52921-00060"/>&ndash;%&gt;
                            <iframe id="_FACILITY_VIEW" width="100%" height="100%"></iframe>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="cell">
            <div class="cell-control">
                <span title="목록 보기" class="icon show-list" onclick="toggleDocuList(event);"></span>
                <span title="전체화면 보기" class="icon fullscr" onclick="showFullScreen(event);"></span>
                <span title="전체화면 닫기" class="icon fullscr-close" onclick="closeFullScreen(event);"></span>
            </div>
            <!-- 연계문서 -->
            <div class="doc-box" id="_MULTI_TAB_2_DOC_VIEW">
                <div class="doc-header">
                    <strong>연계문서</strong>
                    <span class="icon icon-close" title="닫기" onclick="toggleDocuList(event);"></span>
                </div>
                <div class="doc-body" id="_MULTI_TAB_2_DOC_LIST">
                    &lt;%&ndash; 문서 리스트 &ndash;%&gt;
                    &lt;%&ndash;<div class="doc-link" onclick="">A101J-3001_GH-186-023-221_COMBINED REHEAT VALVE ASS’Y</div>&ndash;%&gt;
                </div>
            </div>
            <div class="idms-container ic-02">
                <!-- tab nav -->
                <ul class="nav nav-underline">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active _MULTI_TAB_2" id="pnid-tab02" data-bs-toggle="tab" data-bs-target="#pnid-tab02-pane" data-target="_MULTI_TAB_PAGE_2_PNID" type="button" role="tab" aria-controls="pnid-tab02-pane" aria-selected="true" data-page="/multiview/pnid.do?iegNo=${geniInfo.iegNo}&pnidNo=${geniInfo.pnidNo}">P&ID</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _MULTI_TAB_2" id="clogic-tab02" data-bs-toggle="tab" data-bs-target="#clogic-tab02-pane" data-target="_MULTI_TAB_PAGE_2_DATAPARC" type="button" role="tab" aria-controls="clogic-tab02-pane" aria-selected="false" data-page="/multiview/dataparc.do?iegNo=${geniInfo.iegNo}">dataPARC</button>
                    </li>
                    &lt;%&ndash;<li class="nav-item" role="presentation">
                        <button class="nav-link _MULTI_TAB_2" id="electric-tab02" data-bs-toggle="tab" data-bs-target="#electric-tab02-pane" type="button" role="tab" aria-controls="electric-tab02-pane" aria-selected="false" data-page="/multiview/sld.do?dataPath=">전기단선도</button>
                    </li>&ndash;%&gt;
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _MULTI_TAB_2" id="panorama-tab02" data-bs-toggle="tab" data-bs-target="#panorama-tab02-pane" data-target="_MULTI_TAB_PAGE_2_PANORAMA" type="button" role="tab" aria-controls="panorama-tab02-pane" aria-selected="false" data-page="/pcm/vi/panoview.do?pct_sn=84&tagno=${panoData.pIdx}">파노라마</button>
                    </li>
                </ul>
                <!-- tab-content -->
                <div class="tab-content" id="idmsTabContent02">
                    <div class="tab-pane fade show active _MULTI_TAB_PAGE_2" id="pnid-tab02-pane" role="tabpanel" aria-labelledby="pnid-tab02" tabindex="0">
                        &lt;%&ndash; P&ID &ndash;%&gt;
                        <iframe id="_MULTI_TAB_PAGE_2_PNID" width="100%" height="100%"></iframe>
                    </div>
                    <div class="tab-pane fade _MULTI_TAB_PAGE_2" id="clogic-tab02-pane" role="tabpanel" aria-labelledby="clogic-tab02" tabindex="0">
                        &lt;%&ndash; dataPARC &ndash;%&gt;
                        <iframe id="_MULTI_TAB_PAGE_2_DATAPARC" width="100%" height="100%"></iframe>
                    </div>
                    &lt;%&ndash;<div class="tab-pane fade _MULTI_TAB_PAGE_2" id="electric-tab02-pane" role="tabpanel" aria-labelledby="electric-tab02" tabindex="0">
                        &lt;%&ndash; 전기단선도 &ndash;%&gt;
                    </div>&ndash;%&gt;
                    <div class="tab-pane fade _MULTI_TAB_PAGE_2" id="panorama-tab02-pane" role="tabpanel" aria-labelledby="panorama-tab02" tabindex="0">
                        &lt;%&ndash; 파노라마 &ndash;%&gt;
                        <iframe id="_MULTI_TAB_PAGE_2_PANORAMA" width="100%" height="100%"></iframe>
                    </div>
                </div>
            </div>
        </div>

        <div class="cell">
            <div class="cell-control">
                <span title="목록 보기" class="icon show-list" onclick="toggleDocuList(event);"></span>
                <span title="전체화면 보기" class="icon fullscr" onclick="showFullScreen(event);"></span>
                <span title="전체화면 닫기" class="icon fullscr-close" onclick="closeFullScreen(event);"></span>
            </div>
            <!-- 연계문서 -->
            <div class="doc-box" id="_MULTI_TAB_3_DOC_VIEW">
                <div class="doc-header">
                    <strong>연계문서</strong>
                    <span class="icon icon-close" title="닫기" onclick="toggleDocuList(event);"></span>
                </div>
                <div class="doc-body" id="_MULTI_TAB_3_DOC_LIST">
                    &lt;%&ndash; 문서 리스트 &ndash;%&gt;
                    &lt;%&ndash;<div class="doc-link" onclick="">A101J-3001_GH-186-023-221_COMBINED REHEAT VALVE ASS’Y</div>&ndash;%&gt;
                </div>
            </div>
            <div class="idms-container ic-03">
                <!-- tab nav -->
                <ul class="nav nav-underline">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active _MULTI_TAB_3" id="pnid-tab03" data-bs-toggle="tab" data-bs-target="#pnid-tab03-pane" data-target="_MULTI_TAB_PAGE_3_PNID" type="button" role="tab" aria-controls="pnid-tab03-pane" aria-selected="true" data-page="/multiview/pnid.do?iegNo=${geniInfo.iegNo}&pnidNo=${geniInfo.pnidNo}">P&ID</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _MULTI_TAB_3" id="clogic-tab03" data-bs-toggle="tab" data-bs-target="#clogic-tab03-pane" data-target="_MULTI_TAB_PAGE_3_DATAPARC" type="button" role="tab" aria-controls="clogic-tab03-pane" aria-selected="false" data-page="/multiview/dataparc.do?iegNo=${geniInfo.iegNo}">dataPARC</button>
                    </li>
                    &lt;%&ndash;<li class="nav-item" role="presentation">
                        <button class="nav-link _MULTI_TAB_3" id="electric-tab03" data-bs-toggle="tab" data-bs-target="#electric-tab03-pane" type="button" role="tab" aria-controls="electric-tab03-pane" aria-selected="false" data-page="/multiview/sld.do?dataPath=">전기단선도</button>
                    </li>&ndash;%&gt;
                    <li class="nav-item" role="presentation">
                        <button class="nav-link _MULTI_TAB_3" id="panorama-tab03" data-bs-toggle="tab" data-bs-target="#panorama-tab03-pane" data-target="_MULTI_TAB_PAGE_3_PANORAMA" type="button" role="tab" aria-controls="panorama-tab03-pane" aria-selected="false" data-page="/pcm/vi/panoview.do?pct_sn=84&tagno=${panoData.pIdx}">파노라마</button>
                    </li>
                </ul>
                &lt;%&ndash;<!-- tab-content -->&ndash;%&gt;
                <div class="tab-content" id="idmsTabContent03">
                    <div class="tab-pane fade show active _MULTI_TAB_PAGE_3" id="pnid-tab03-pane" role="tabpanel" aria-labelledby="pnid-tab03" tabindex="0">
                        &lt;%&ndash;<!-- 3 P&ID -->&ndash;%&gt;
                        <iframe id="_MULTI_TAB_PAGE_3_PNID" width="100%" height="100%"></iframe>
                    </div>
                    <div class="tab-pane fade _MULTI_TAB_PAGE_3" id="clogic-tab03-pane" role="tabpanel" aria-labelledby="clogic-tab03" tabindex="0">
                        &lt;%&ndash;<!-- 3 dataPARC -->&ndash;%&gt;
                        <iframe id="_MULTI_TAB_PAGE_3_DATAPARC" width="100%" height="100%"></iframe>
                    </div>
                    &lt;%&ndash;<div class="tab-pane fade _MULTI_TAB_PAGE_3" id="electric-tab03-pane" role="tabpanel" aria-labelledby="electric-tab03" tabindex="0">
                        &lt;%&ndash;<!-- 3 전기단선도 -->&ndash;%&gt;
                    </div>&ndash;%&gt;
                    <div class="tab-pane fade _MULTI_TAB_PAGE_3" id="panorama-tab03-pane" role="tabpanel" aria-labelledby="panorama-tab03" tabindex="0">
                        &lt;%&ndash;<!-- 3 파노라마 -->&ndash;%&gt;
                        <iframe id="_MULTI_TAB_PAGE_3_PANORAMA" width="100%" height="100%"></iframe>
                    </div>
                </div>
            </div>
        </div>
        <div class="cell pc-only">
            <div class="cell-control">
                <span title="전체화면 보기" class="icon fullscr" onclick="showFullScreen(event);"></span>
                <span title="전체화면 닫기" class="icon fullscr-close" onclick="closeFullScreen(event);"></span>
            </div>
            <div class="unity-box">
                &lt;%&ndash; unity view area &ndash;%&gt;
                <iframe id="_MULTI_UNITY_VIEW" width="100%" height="100%"></iframe>
            </div>
        </div>
    </div>
</div>--%>

<script src="${pageContext.request.contextPath}/resources/user/js/iframe/dynamic-iframe.js"></script>
<script>
    function showFullScreen(e) {
        const $targetCell = $(e.target).closest('.cell');
        if ($targetCell.length) {
            $targetCell.addClass('fullscreen');

            // Set 3d model flag
            const iframe = $("#_MULTI_UNITY_VIEW")[0];
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.fnSetLoadIdmsPage(false, 1);
            }
        }
    }

    function closeFullScreen(e) {
        const $targetCell = $(e.target).closest('.cell');
        if ($targetCell.length) {
            $targetCell.removeClass('fullscreen');

            // Set 3d model flag
            const iframe = $("#_MULTI_UNITY_VIEW")[0];
            if (iframe && iframe.contentWindow) {
                iframe.contentWindow.fnSetLoadIdmsPage(true, 1);
            }

        }
    }

    /* 연계문서 목록 토글 */
    function toggleDocuList(e) {
        const $btn = $(e.target).closest('.show-list');
        const $cell = $(e.target).closest('.cell');
        if (!$cell.length) return;

        // 현재 활성화된 탭 내 doc-box 찾기
        const $activePane = $cell.find('.tab-pane.active');
        const $activeDocuBox = $cell.find('.doc-box');

        if ($activeDocuBox.length) {
            const isActive = $activeDocuBox.hasClass('active');

            // 모든 탭의 doc-box 및 버튼 active 제거
            $cell.find('.doc-box').removeClass('active');
            $btn.removeClass('active');

            // 현재 탭만 토글
            if (!isActive) {
                $activeDocuBox.addClass('active');
                $btn.addClass('active');
            }
        }
    }

    /* iframe resize */
    function resizeIframeToContent(iframe) {
        try {
            var doc = iframe.contentDocument || iframe.contentWindow.document;

            var height = Math.max(
                doc.body.scrollHeight,
                doc.documentElement.scrollHeight,
                doc.body.offsetHeight,
                doc.documentElement.offsetHeight
            );

            iframe.style.height = height + "px";
        } catch (e) {
            console.warn("iframe resize failed:", e);
        }
    }

    /* view page */
    function fnViewPage(targetSel, url, targetDoc) {
        if (targetDoc !== "") {
            $(targetDoc + "VIEW").removeClass('active');
        }

        /*initDynamicIframe(targetSel, url, {
            mode: 'fill',
            attrs: {scrolling: 'auto'}
        });*/

        var $iframe = $("#" + targetSel);

        /*$iframe.off("load.autoResize").on("load.autoResize", function () {
            resizeIframeToContent(this);
        });*/

        $iframe.attr("src", url);
    }

    // 설비번호로 데이터 검색(Pnid, dataParc, sld)
    function fnSearchData(targetSel, url, targetDoc) {
        console.log("fnSearchData : ", targetSel, url, targetDoc)
        $.ajax({
            type: "POST"
            , url: url
            , dataType: "json"
            , beforeSend: function () {
                $("#loadingBar").show();
            },
            success: function (data) {
                var dataLen = data.length;
                var docList = [];
                var paramUrl = "";

                $.each(data, function (i, item) {
                    var text = (item && item.text) || "";

                    paramUrl = url.split("dataPath=")[0] + "&dataPath=" + encodeURIComponent(item.data) + "&searchTag=" + encodeURIComponent(item.tagNo);
                    docList.push('<div class="doc-link" onclick="fnViewPage(\'' + targetSel + '\', \'' + paramUrl + '\', \'' + targetDoc + '\')"><span>' + item.fileName + '</span> <span>' + text + '</span></div>');
                });

                $(targetDoc + "LIST").html(docList.join(""));

                // 여러개의 정보가 있으면 리스트를 보여줌
                if (dataLen === 0) {
                    fnViewPage(targetSel, url, targetDoc);
                } else if (dataLen > 0 && dataLen <= 1) {
                    fnViewPage(targetSel, paramUrl, targetDoc);
                } else {
                    $(targetDoc + "VIEW").addClass('active');
                }
            },
            error: function (xhr, status, error) {
                console.log("### error ### " + error);
                alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
            },
            complete: function () {
                $("#loadingBar").hide();
            }
        });
    }

    /* 1 설비정보, 4 유니티 뷰 */
    function fnMultiViewLoadingPage() {
        // 설비정보 view
        /*initDynamicIframe("#_FACILITY_VIEW", "/multiview/facilityDetail.do?iegNo=${geniInfo.iegNo}", {
            mode: 'fill',
            attrs: {scrolling: 'auto'}
        });*/

        $("#_FACILITY_VIEW").attr("src", "/multiview/facilityDetail.do?iegNo=${geniInfo.iegNo}");

        // unity view
        /*initDynamicIframe("#_MULTI_UNITY_VIEW", "/multiview/unityViewer.do?modelType=${modelData.modelTarget}&modelId=${modelData.modelId}", {
            mode: 'fill',
            attrs: {scrolling: 'no'}
        });*/
        $("#_MULTI_UNITY_VIEW").attr("src", "/multiview/unityViewer.do?modelType=${modelData.modelTarget}&modelId=${modelData.modelId}");
    }

    // page loading : 탭메뉴 설정
    function fnInitPage($tabs) {
        var $initial = $tabs;
        if ($initial.length) {
            // BS 탭 전환 후 컨텐츠 로드
            if (window.bootstrap && typeof window.bootstrap.Tab === 'function') {
                new bootstrap.Tab($initial[0]).show();
            }
            $initial.trigger('click');
        }
    }

    $(document).ready(function () {
        /* 탭 페이지 로딩 */
        // 2번째 프레임
        $("._MULTI_TAB_2").click(function (e) {
            e.preventDefault();

            var idx = $(this).index("._MULTI_TAB_2");
            var targetSel = $(this).attr("data-target");
            var url = $(this).attr("data-page");

            // check doc list & loading url
            if (idx < 2) {
                fnSearchData(targetSel, url, "#_MULTI_TAB_2_DOC_");
            } else {
                fnViewPage(targetSel, url, "#_MULTI_TAB_2_DOC_");
            }
        });

        // 3번째 프레임
        $("._MULTI_TAB_3").click(function (e) {
            e.preventDefault();

            var idx = $(this).index("._MULTI_TAB_3");
            var targetSel = $(this).attr("data-target");
            var url = $(this).attr("data-page");

            // check doc list & loading url
            if (idx < 2) {
                fnSearchData(targetSel, url, "#_MULTI_TAB_3_DOC_");
            } else {
                fnViewPage(targetSel, url, "#_MULTI_TAB_3_DOC_");
            }
        });

        /* init loading */
        console.log("##### " + window.location.search);
        var params = new URLSearchParams(window.location.search);
        var paramU = params.get("u");
        if (!paramU) {
            paramU = decodeURIComponent(paramU);
        }

        <c:if test="${not empty geniInfo.iegNo}">
        fnInitPage($("._MULTI_TAB_2").eq(0));   // 2 프레임 뷰 로딩
        fnInitPage($("._MULTI_TAB_3").eq(1));   // 3 프레임 뷰 로딩

        // loading: 1,4 프레임뷰
        fnMultiViewLoadingPage();
        </c:if>
    });
</script>
</body>
<c:import url="/footer.do"/>
