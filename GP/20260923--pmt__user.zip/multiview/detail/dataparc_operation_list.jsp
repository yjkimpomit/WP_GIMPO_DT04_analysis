<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보의 운전정보 리스트 -->
<table class="data-table data-table--list data-table--interactive" aria-label="운전정보">
    <colgroup>
        <col style="width: 196px;">
        <col>
        <col style="width: 128px;">
        <col style="width: 160px;">
    </colgroup>
    <thead>
    <tr>
        <th scope="col" data-field="태그">태그</th>
        <th scope="col" data-field="상세정보">상세정보</th>
        <th scope="col" data-field="운전정보">운전정보</th>
        <th scope="col" data-field="TREND">TREND</th>
    </tr>
    </thead>
    <tbody>
    <c:if test="${empty utag}">
        <tr>
            <th colspan="6">
                <div class="no-data">
                    조회된 데이터가 없습니다.
                </div>
            </th>
        </tr>
    </c:if>
    <c:if test="${not empty utag}">
        <tr>
            <td data-field="태그">${fn:toUpperCase(utag)}</td>
            <td data-field="상세정보">${utagDes}</td>
            <td data-field="운전정보">${utagVal}</td>
            <td data-field="TREND">
                <c:choose>
                    <c:when test="${trendYn eq 'Y'}">
                        <button type="button" class="button button--sm button--neutral" onclick="openTrendPopup('${utag}','${trendTime}')">
                            <span>트렌드 보기</span>
                        </button>
                    </c:when>
                    <c:otherwise>-</c:otherwise>
                </c:choose>
            </td>
        </tr>
    </c:if>
    </tbody>
</table>



