<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body>
<c:if test="${empty multiViewVO.dataPath}">
    <div class="no-data" id="infoNoData">
        dataPARC정보가 없습니다.
    </div>
</c:if>
<c:if test="${not empty multiViewVO.dataPath}">
<script>
    loadCss("${pageContext.request.contextPath}/resources/user/js/svgviewer/css/svg-wrapper.css");
</script>

<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="page-content__placeholder">
    <%-- dataparc 운전정보 팝업 --%>
    <%--<div class="modal fade" tabindex="-1" id="dataparcDetailBox">
        <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-xl-down modal-xl">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="title04">운전정보</h5>
                    <button type="button" class="btn close">
                        <span class="icon icon-close"></span><span>닫기</span>
                    </button>
                </div>
    
                <div class="modal-body" id="dataparcDetail">
    
                </div>
            </div>
        </div>
    </div>--%>
    
    <input type="file" id="svgFileInput" accept=".svg" class="visually-hidden" />

    <div id="svgarea" class="svgarea">
        <!-- 기존 object를 여기로 append 중 -->
        <div id="center-guide" aria-hidden="true">
            <div class="cg-line cg-vertical"></div>
            <div class="cg-line cg-horizontal"></div>
        </div>
    </div>
    
</div>

<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/dataparc/svg-pan-zoom.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/dataparc/svg.min.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/dataparc/svgViewerUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/dataparc/svgTableUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/dataparc/svgDummyUtils.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/dataparc/svgUtagHandlerUtils.js"></script>
<script>
    let parser = new DOMParser();
    let svgDoc = null;
    let svgElement = null;
    let panZoom = null;
    let svgType = null;
    let ckType = null;
    let checkeClickEvent = false;

    const svgns = 'http://www.w3.org/2000/svg';

    window.addEventListener("DOMContentLoaded", function () {
        // 예시 : http://127.0.0.1:5500/?dataPath=/test_viewer_file/21GT%2520COOLING%2520STEAM%2520SYSTEM.svg&searchTag=1-33110-FV-GT1136
		// 예시 : http://localhost:8080/multiview/dataparc.do?dataPath=/drawing/dataparc/2275_BLR%20TUBE%20LEAK%20MONITOR.svg&searchTag=1-33110-FV-GT1136 {tagNo}
        // url 경로로 접근 시 작동
        initFromUrlParams();
   
    });
</script>
</c:if>
</body>
<c:import url="/footer.do"/>
