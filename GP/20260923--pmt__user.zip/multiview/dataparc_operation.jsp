<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

 <%-- dataPARC의 태그정보 팝업 --%>

<c:import url="/header.do"/>

<body>
<%-- 로딩박스 --%>
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="searchResultPopup">
    <h1 class="page-content__heading visually-hidden">운전정보</h1>
    <div class="table-responsive" id="_DIV_OPER_LIST">
        <%-- operation list --%>
    </div>
</main>

<script>
    // 트렌드 보기 팝업을 여는 함수
    function openTrendPopup(tagNo, time) {
        var data = "?iegTagno=" + tagNo + "&time=" + time;
        var url = "/facility/operationTrend.do" + data;
        var box = new WinBox("Trend", {
            url: url,
            width: Math.min(1200, window.innerWidth - 20) + "px",
            height: Math.min(640, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    function fnOperationList() {
        $.ajax({
            type: "POST"
            , url: "/multiview/dataparc/operationList.do"
            , dataType: "html"
        	, data: {
                 utag: '${utag}',
                 utagVal: '${utagVal}',
                 utagDes: '${utagDes}'
               }
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_DIV_OPER_LIST").html(data);
            },
            error: function (e) {
                console.log(e);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    fnOperationList();
</script>
</body>
<c:import url="/footer.do"/>