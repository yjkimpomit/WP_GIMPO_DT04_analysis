﻿<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<!DOCTYPE html>
<html>
<head>
    <meta name="viewport" content="width=device-width, initial-scale=1, user-scalable=no" />
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/pdfviewer/style.css" />
    <script src="${pageContext.request.contextPath}/resources/user/js/pdfviewer/lib/webviewer.min.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/pdfviewer/old-browser-checker.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/pdfviewer/global.js"></script>
    <title>JavaScript PDF Viewer Demo</title>
</head>
<body>
<aside>
    <h1>Controls</h1>
    <h2>choose file</h2>
    <input id="file-picker" type="file" accept=".pdf,.jpg,.jpeg,.png,.doc,.docx,.docm,.dotx,.dotm,.dot,.xlsx,.xlsm,.xlt,.xls,.odt,.txt,.rtf,.pptx,.ppt,.pptm,.pps,.pot,.md,.xod" />
    <hr />

    <h1>Instructions</h1>
    <strong>This sample is using WebViewer client side rendering, so none of the files will be uploaded to any server.</strong>
    <p>Use the dropdown above to view local or remote documents. Out of the box, WebViewer client only can load the following file types:</p>
    <ul>
        <li>.pdf</li>
        <li>.jpg</li>
        <li>.jpeg</li>
        <li>.png</li>
        <li>.doc</li>
        <li>.docx</li>
        <li>.xls</li>
        <li>.xlsx</li>
        <li>.ppt</li>
        <li>.pptx</li>
        <li>.md</li>
        <li>.xod</li>
    </ul>

    <p>Visit <a href="https://docs.apryse.com/documentation/web/guides/file-format-support/" target="_blank">here</a> for a full list of supported file formats.</p>
    <p>You can also open password-protected PDF. The password is `foobar12`.</p>
</aside>
<div id="viewer" style="margin-top: 0"></div>
<script src="${pageContext.request.contextPath}/resources/user/js/pdfviewer/menu-button.js"></script>
<script>
    var targetFile = "/drawingFiles/logic-9/1_14 DROP PDF.pdf";
    <c:if test="${not empty fn:escapeXml(param.file)}">targetFile = "${fn:escapeXml(param.file)}";</c:if>
</script>
<script src="${pageContext.request.contextPath}/resources/user/js/pdfviewer/viewing.js"></script>
<!--ga-tag-->
</body>
</html>
