<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body>

<c:if test="${empty multiViewVO.dataPath}">
	<div class="no-data" id="infoNoData">
		P&ID정보가 없습니다.
	</div>
</c:if>
<c:if test="${not empty multiViewVO.dataPath}">
    <script>
		loadCss("${pageContext.request.contextPath}/resources/user/js/svgviewer/css/svg-wrapper.css");
		loadCss("${pageContext.request.contextPath}/resources/user/js/svgviewer/css/style.css");
    </script>

	<!-- 로딩박스 -->
	<div class="loading-box" id="loadingBar" style="display: none;">
		<div class="loader"></div>
	</div>
	
	
		<div id="svgarea" class="svgarea">
			<div id="center-guide" aria-hidden="true">
				<div class="cg-line cg-vertical"></div>
				<div class="cg-line cg-horizontal"></div>
			</div>
		</div>

		<!-- pnid 도면 네비게이션 -->
		<div class="pnid-history-box">
			<div class="pnid-history-header">
				<strong>최근 도면<span id="pnidHistoryCount"></span></strong>
				<button
						type="button"
						id="pnidToggleBtn"
						class="pnid-toggle-btn"
						aria-expanded="true"
						aria-label="최근 도면 접기/펼치기"
				><span class="visually-hidden">도면리스트</span></button>
			</div>

			<div class="pnid-history-body" id="pnidHistoryBody">
				<ul class="pnid-history-list" id="navHistoryList">
					<!-- JS로 목록 생성 -->
				</ul>
			</div>
		</div>
	

	<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/pnid/svg-pan-zoom.js"></script>
	<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/pnid/svg.min.js"></script>
	<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/pnid/svgViewerUtils.js"></script>
	<script src="${pageContext.request.contextPath}/resources/user/js/svgviewer/pnid/svgTableUtils.js"></script>
	<script>
		let parser = new DOMParser();
		let svgDoc = null;
		let svgElement = null;
		let panZoom = null;
		let svgType = null;
		let ckType = null;
		let checkeClickEvent = false;
		const NAV_HISTORY_KEY = "pnid_nav_history";

		const svgns = 'http://www.w3.org/2000/svg';

		window.addEventListener("DOMContentLoaded", function () {
			// 예시 : http://127.0.0.1:5500/index.html?dataPath=/pnid/G12J-11420-BM-105-001.svg&searchTag=SA
			// 예시 : http://localhost:8080/multiview/pnid.do?dataPath=/drawing/pnid/10-11600-UM-105-001.svg&searchTag=SA {tagNo}
			// url 경로로 접근 시 작동

			if (shouldResetNavHistory()) {
				sessionStorage.removeItem(NAV_HISTORY_KEY);
			}

			initFromUrlParams();

			if (typeof loadNavHistory === "function" && typeof renderNavHistory === "function") {
				const history = loadNavHistory(); //  sessionStorage에서
				renderNavHistory(history);
			}

			const navTogglebtn = document.getElementById("pnidToggleBtn");
			const navBody = document.getElementById("pnidHistoryBody");
			if (!navTogglebtn || !navBody) return;

			navTogglebtn.addEventListener("click", function () {
				const isCollapsed = navBody.classList.toggle("is-collapsed");
				navTogglebtn.classList.toggle("is-collapsed", isCollapsed);
				navTogglebtn.setAttribute("aria-expanded", String(!isCollapsed));
				//navTogglebtn.textContent = isCollapsed ? "▸" : "▾";
			})
		});
	</script>
</c:if>
</body>
<c:import url="/footer.do"/>
