<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 -->
<div class="result-panel">
    <div class="result-panel__body" id="_DIV_OPER_LIST">
    <%-- operation list --%>
    </div>
</div>

<%-- </div> --%>

<%-- 운전정보의 트렌드보기 팝업 --%>
<div class="modal fade b-popup" id="trendModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-xl-down modal-xl">
        <div class="modal-content">
            <%-- 데이터 상세정보 뷰 --%>
        </div>
    </div>
</div>

<script>
    // 트렌드 보기 팝업을 여는 함수
    function openTrendPopup(tagNo, time) {
        var data = "?iegTagno=" + tagNo + "&time=" + time;
        var url = "/facility/operationTrend.do" + data;
        var box = new WinBox("Trend", {
            url: url,
            width: Math.min(1400, window.innerWidth - 20) + "px",
            height: Math.min(window.innerHeight - 20, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    function fnOperationList() {
        $.ajax({
            type: "POST"
            , url: "/facility/operationInfoList.do"
            , data: {iegNo: '${facilityGeniVO.iegNo}'}
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_DIV_OPER_LIST").html(data);
            },
            error: function (e) {
                console.log(e);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    fnOperationList();
</script>