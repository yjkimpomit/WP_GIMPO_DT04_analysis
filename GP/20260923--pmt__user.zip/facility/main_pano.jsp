<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="main">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<div class="modal fade external-popup facility show" id="externalPopup" tabindex="-1" style="left: 0px; position: absolute; top: 0px; z-index: 1052; opacity: 1; display: block;">
    <div class="modal-dialog modal-dialog-scrollable modal-fullscreen" style="margin-top:0;height:100vh;">
        <div class="modal-content" id="popupContentView">

            <input type="hidden" id="panoInfo" name="panoInfo" value="${panoInfo}"/>

            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle">설비정보</h2>
                <button type="button" id="modalMainPano" class="btn-close modal-close" aria-label="Close" onclick="fnClosePano()"></button>
            </div>

            <div class="modal-body" id="modalBodyContent">

                <!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 -->

                <c:set var="isBtn3dDisabled" value="disabled"/>
                <c:if test="${geniInfo.iegModelConnect eq 'Y'}"><c:set var="isBtn3dDisabled" value=""/></c:if>

                <div class="container-facility">

                    <!-- 제목영역 -->
                    <div class="title-box">
                        <div>
                            <h3 class="title02">${geniInfo.iegDecription}</h3>
                        </div>
                        <div class="buttons">
                            <button type="button" class="btn btn-xs btn-primary ${isBtn3dDisabled}" id="moveTo3D" onclick="panoToUnity('${geniInfo.iegModelType}','${geniInfo.iegNo}');">
                                <span class="icon icon-3d"></span><span>3D 모델</span>
                            </button>
                        </div>
                    </div>

                    <!-- 데이터 테이블 -->
                    <ul class="nav nav-tabs" id="facTab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <button class="nav-link active _TAB_PAGE" id="modelTab01" data-bs-toggle="tab" data-bs-target="#modelTab01-pane" type="button" role="tab" aria-controls="tab01-pane" aria-selected="true" data-page="/info.do?panoInfo=1">설비정보</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link _TAB_PAGE" id="modelTab02" data-bs-toggle="tab" data-bs-target="#modelTab02-pane" type="button" role="tab" aria-controls="tab02-pane" aria-selected="false" data-page="/maintenanceHistory.do">정비이력</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link _TAB_PAGE" id="modelTab04" data-bs-toggle="tab" data-bs-target="#modelTab04-pane" type="button" role="tab" aria-controls="tab04-pane" aria-selected="false" data-page="/materialInfo.do">자재정보</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link _TAB_PAGE" id="modelTab05" data-bs-toggle="tab" data-bs-target="#modelTab05-pane" type="button" role="tab" aria-controls="tab05-pane" aria-selected="false" data-page="/tmInfo.do">TM 이력</button>
                        </li>
                        <li class="nav-item" role="presentation">
                            <button class="nav-link _TAB_PAGE" id="modelTab06" data-bs-toggle="tab" data-bs-target="#modelTab06-pane" type="button" role="tab" aria-controls="tab06-pane" aria-selected="false" data-page="/operationInfo.do">운전정보</button>
                        </li>
                    </ul>

                    <!-- 탭 콘텐츠 -->
                    <div class="tab-content" id="facTabContent">
                        <!-- 설비정보 -->
                        <div class="tab-pane fade show active" id="modelTab01-pane" role="tabpanel" aria-labelledby="tab01" tabindex="0">
                            <c:import url="/facility/info.do"/>
                        </div>
                        <!-- 설비정보 End -->

                        <!-- 정비이력 -->
                        <div class="tab-pane fade" id="modelTab02-pane" role="tabpanel" aria-labelledby="modelTab02" tabindex="0">
                        </div>

                        <!-- 고장이력 -->
                        <div class="tab-pane fade" id="modelTab03-pane" role="tabpanel" aria-labelledby="modelTab03" tabindex="0">
                        </div>

                        <!-- 자재정보 -->
                        <div class="tab-pane fade" id="modelTab04-pane" role="tabpanel" aria-labelledby="modelTab04" tabindex="0">
                        </div>

                        <!-- TM 이력 -->
                        <div class="tab-pane fade" id="modelTab05-pane" role="tabpanel" aria-labelledby="modelTab05" tabindex="0">
                        </div>

                        <!-- 운전정보 -->
                        <div class="tab-pane fade" id="modelTab06-pane" role="tabpanel" aria-labelledby="modelTab06" tabindex="0">
                        </div>
                        <!-- 운전정보 end -->
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<%-- modal popup --%>
<c:import url="/common/modalPopup.do"/>

<script src="${pageContext.request.contextPath}/resources/user/js/facility/custom-facility.js"></script>
<script>
    $(document).ready(function () {
        var facilityRefListChk = $("#facilityRefList").val();
        var panoInfoChk = $("#panoInfo").val();

        if (panoInfoChk === 1) {
            $("#externalPopup #_FACILITY_DETAIL_VIEW_INFO").show();
            $("#infoTitle").hide();
            $("#infoMessage").hide();
            $("#infoNoData").hide();
        }

        <%-- 설비정보 페이지의 파노라마 버튼 삭제 --%>
        $("#moveToPanorama").remove();

        /* 페이지 로딩 */
        $("._TAB_PAGE").click(function (e) {
            e.preventDefault();

            var target = $(this).attr("data-bs-target");
            var url = "/facility" + $(this).attr("data-page");

            $.ajax({
                type: "post"
                , url: url
                , data: {iegNo: '${geniInfo.iegNo}'}
                , dataType: "html"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    $(target).html(data);
                    $("#moveToPanorama").remove();
                }
                , error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                }
                , complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        });
    });

    /* 설비정보 > 설비상세 정보 뷰 */
    /*function fnFacilityDetailInfo(e, iegNo) {
        alert("main_pano.jsp #####");
        $('._TR_INFO').removeClass('active');
        $(e).parent('._TR_INFO').addClass('active');

        $.ajax({
            type: "post"
            , url: "/facility/infoDetail.do"
            , data: {iegNo: iegNo}
            , dataType: "html"
            , success: function (data) {
                $("#externalPopup #_FACILITY_DETAIL_VIEW_INFO").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
        });
    }*/

    /* 설비정보 > 정비이력 상세 뷰 */
    /*function fnFacilityDetailMaintenance(e, woNo) {
        console.log("### 설비정보 > 정보이력 상세뷰 ###");

        $('._TR_INFO_MH').removeClass('active');
        $(e).addClass('active');

        $.ajax({
            type: "post"
            , url: "/facility/maintenanceHistoryDetail.do"
            , data: {woNo: woNo}
            , dataType: "html"
            , success: function (data) {
                $("#_FACILITY_DETAIL_VIEW_MH").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
        });
    }*/

    /* 설비정보 > 자재정보 상세 뷰 */
    /*function fnFacilityDetailMaterial(e, partNo, equipNo) {
        console.log("### 설비정보 > 자재정보 상세 뷰 ###");

        $('._TR_INFO_MI').removeClass('active');
        $(e).addClass('active');

        $.ajax({
            type: "post"
            , url: "/facility/materialInfoDetail.do"
            , data: {partNo: partNo, equipNo: equipNo}
            , dataType: "html"
            , success: function (data) {
                $("#_FACILITY_DETAIL_VIEW_MI").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
        });
    }*/

    function panoToUnity(modelType, iegNo) {
        if (window.Android) {
            // 창닫기 기능 포함
            window.Android.panoramaLoadToUnity(modelType, iegNo);
        } else {
            if (window.opener && !window.opener.closed) {
                window.opener.opener.focus();
                window.opener.close();
                window.opener.opener.panoramaLoadToUnity(modelType, iegNo);
            }
            window.close();
        }
    }

    function fnClosePano() {
        if (window.Android) {
            window.Android.closeWindow(); // Call Android method
        } else {
            window.close();
        }
    }
</script>

</body>
<c:import url="/footer.do"/>