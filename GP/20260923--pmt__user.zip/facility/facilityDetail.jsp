<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 -->--%>
<%--
/*
* /facility 폴더에 있는 파일 사용
* /facility/info.jsp : 설비정보/리스트*
*/
--%>
<c:import url="/header.do"/>

<body class="sub">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%-- 3d model connect check  --%>
<c:set var="btn3dViewClass" value="disabled"/>
<c:if test="${not empty geniInfo.isModel}">
    <c:set var="btn3dViewClass" value=""/>
</c:if>

<!-- 우측 콘텐츠 -->
<main class="container-facility">

    <!-- 제목영역 -->
    <div class="title-box mb-0">
        <%--<div>
            <h3 class="title02">${geniInfo.iegDecription}</h3>
        </div>--%>
        <div class="buttons">
            <button type="button" class="btn btn-xs btn-primary d-none ${btn3dViewClass}" id="moveTo3D" onclick="fnFacilityTo3D('${geniInfo.iegModelType}','${geniInfo.iegNo}')">
                <span class="icon icon-3d"></span><span>3D 모델</span>
            </button>
        </div>
    </div>

    <main class="winbox-layout tabs tabs--scrollable" data-tabs>
    <ul class="nav nav-tabs" id="facTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active _TAB_PAGE" id="modelTab01" data-bs-toggle="tab" data-bs-target="#modelTab01-pane" type="button" role="tab" aria-controls="tab01-pane" aria-selected="true" data-page="/info.do">설비정보</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab02" data-bs-toggle="tab" data-bs-target="#modelTab02-pane" type="button" role="tab" aria-controls="tab02-pane" aria-selected="false" data-page="/maintenanceHistory.do">정비이력</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab03" data-bs-toggle="tab" data-bs-target="#modelTab03-pane" type="button" role="tab" aria-controls="tab03-pane" aria-selected="false" data-page="/materialInfo.do">자재정보</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab04" data-bs-toggle="tab" data-bs-target="#modelTab04-pane" type="button" role="tab" aria-controls="tab04-pane" aria-selected="false" data-page="/tmInfo.do">TM 이력</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab05" data-bs-toggle="tab" data-bs-target="#modelTab05-pane" type="button" role="tab" aria-controls="tab05-pane" aria-selected="false" data-page="/file.do">연계문서</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab06" data-bs-toggle="tab" data-bs-target="#modelTab06-pane" type="button" role="tab" aria-controls="tab06-pane" aria-selected="false" data-page="/operationInfo.do">운전정보</button>
        </li>
    </ul>

    <!-- 탭 콘텐츠 -->
    <div class="tab-content" id="facTabContent">
        <!-- 설비정보 -->
        <div class="tab-pane fade show active _TAB_PAGE_MODEL" id="modelTab01-pane" role="tabpanel" aria-labelledby="tab01" tabindex="0">
            <c:import url="/facility/info.do"/>
        </div>
        <!-- 설비정보 End -->

        <!-- 정비이력 -->
        <div class="tab-pane fade _TAB_PAGE_MODEL" id="modelTab02-pane" role="tabpanel" aria-labelledby="modelTab02" tabindex="0">
        </div>

        <!-- 자재정보 -->
        <div class="tab-pane fade _TAB_PAGE_MODEL" id="modelTab03-pane" role="tabpanel" aria-labelledby="modelTab03" tabindex="0">
        </div>

        <!-- TM 이력 -->
        <div class="tab-pane fade _TAB_PAGE_MODEL" id="modelTab04-pane" role="tabpanel" aria-labelledby="modelTab04" tabindex="0">
        </div>

        <!-- 연계 문서 -->
        <div class="tab-pane fade _TAB_PAGE_MODEL" id="modelTab05-pane" role="tabpanel" aria-labelledby="modelTab05" tabindex="0">
        </div>

        <!-- 운전정보 -->
        <div class="tab-pane fade _TAB_PAGE_MODEL" id="modelTab06-pane" role="tabpanel" aria-labelledby="modelTab06" tabindex="0">
        </div>
        <!-- 운전정보 end -->
    </div>
</main>

<script src="${pageContext.request.contextPath}/resources/user/js/facility/custom-facility.js"></script>
<script>
    $(document).ready(function () {
        var facilityRefListChk = $("#facilityRefList").val();
        if (facilityRefListChk === 0) {
            $("#_FACILITY_DETAIL_VIEW_INFO").hide();
        }

        /* 페이지 로딩 */
        $("._TAB_PAGE").click(function (e) {
            e.preventDefault();
            $("._TAB_PAGE_MODEL").empty();

            var target = $(this).attr("data-bs-target");
            var url = "/facility" + $(this).attr("data-page");

            $.ajax({
                type: "post"
                , url: url
                , data: {iegNo: "${geniInfo.iegNo}"}
                , dataType: "html"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    $(target).html(data);
                }
                , error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                }
                , complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        });
    });
</script>
</body>
<c:import url="/footer.do"/>
