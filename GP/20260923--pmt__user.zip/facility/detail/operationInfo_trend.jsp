<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 운전정보의 트렌드보기 팝업 --%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup trend-chart-page" id="searchResultPopup">
        <%-- 데이터 상세정보 뷰 --%>
        <h1 class="result-header__title">${fn:toUpperCase(facilityOperationVO.iegTagno)}</h1>

        <form id="formTrendSearch" name="formTrendSearch" method="post" data-popup-form>
            <input type="hidden" name="searchCnd" value="run"/>
            <input type="hidden" name="iegTagno" value="${facilityOperationVO.iegTagno}"/>
            
            <%-- 가로형 검색폼 --%>
            <div class="search-fields">
                <span id="dateRangePicker">조회 기간</span>
                <%-- .form-field--group 단위로 반복 --%>
                <div class="form-field--group">
                    <label>
                        <span class="visually-hidden">시작일</span>
                        <input type="date" class="form-control" id="startDate01" name="startDate" value="${startDate}">
                    </label>
                    
                    <label>
                        <span class="visually-hidden">시작시각</span>
                        <input type="time" class="form-control" id="startTime01" name="startTime" value="${startTime}">
                    </label>
                    
                    <span aria-hidden="true">~</span>
                    
                    <label>
                        <span class="visually-hidden">종료일</span>
                        <input type="date" class="form-control form-control--calendar" id="endDate01" name="endDate" value="${endDate}">
                    </label>
                    
                    <label>
                        <span class="visually-hidden">종료시각</span>
                        <input type="time" class="form-control" id="endTime01" name="endTime" value="${endTime}">
                    </label>
                </div>
                <button type="button" class="button button--primary" onclick="fnTrendSearch()">검색</button>
            </div>
        </form>
        
        <div class="result-chart">
            <div class="trend-data-group">
                <dl class="text-group">
                    <dt>최소</dt>
                    <dd id="trendMin">-</dd>
                </dl>
    
                <dl class="text-group">
                    <dt>최대</dt>
                    <dd id="trendMax">-</dd>
                </dl>
    
                <dl class="text-group">
                    <dt>현재</dt>
                    <dd id="trendCurrent">-</dd>
                </dl>
            </div>
            
            <div class="chart-container" id="viewChart">
            <%-- chart area --%>
            </div>
        </div>
    
</main>

<script>
    function fnTrendSearch() {
        const start = $("#startDate01").val() + " " + $("#startTime01").val();
        const end = $("#endDate01").val() + " " + $("#endTime01").val();

        if (start > end) {
            title = "조회 기간 확인";
            content = "종료시간이 시작시간보다 빠릅니다.";
            fnAlert();
            return;
        }

        $.ajax({
            url: "/facility/operationTrendChart.do",
            data: $("#formTrendSearch").serialize(),
            dataType: "html",
            beforeSend: function () {
                $("#loadingBar").show();
                $("#trendMin").text("-");
                $("#trendMax").text("-");
                $("#trendCurrent").text("-");
            },
            success: function (data) {
                $("#viewChart").html(data);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    $(function () {
        fnTrendSearch();
    });
</script>