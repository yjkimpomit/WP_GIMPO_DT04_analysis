<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:if test="${empty vwGeniInfo.equipNo}">
    <div class="no-data" id="infoNoData">
        설비정보가 없습니다.
    </div>
</c:if>

<c:if test="${not empty vwGeniInfo.equipNo}">
    <%--<div class="splitview panel-split-layout panel-split-layout--two-to-one">--%>
        <div class="splitview__pane splitview__pane--sidebar panel-split-layout__sidebar" aria-label="설비상세 정보">
            <section class="panel-split-layout__group panel-split-layout__group--primary">
                <div class="result-header">
                    <h2 class="result-header__title">설비상세 정보</h2>
    
                    <%--<c:if test="${not empty modelTarget}">
                        <button type="button" class="btn btn-primary btn-sm mobile-only" onclick="fnFacilityTo3D('${modelTarget}', '${modelId}')"><span class="icon-3d"></span><span>3D 모델</span></button>
                    </c:if>--%>
                </div>
    
                <div class="table-responsive">
                    <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab01-pane" aria-label="설비상세">
                        <colgroup>
                            <col style="width: 104px;">
                            <col>
                            <col style="width: 128px;">
                            <col style="min-width: 240px;">
                        </colgroup>
                        <tbody>
                        <%-- 연계정보 버튼 추가 --%>
                        <tr>
                            <th scope="row">연계정보</th>
                            <td>
                                <div class="linked-info-actions" aria-label="설비 연계정보">
                                    <button class="button button--neutral button--icon button--panorama" type="button" aria-label="파노라마 보기">파노라마</button>
                                    <button class="button button--neutral button--icon button--3d-model" type="button" aria-label="3D 모델 보기">3D 모델</button>
                                    <button class="button button--neutral button--icon button--dataparc" type="button" aria-label="DataPARC 보기">DataPARC</button>
                                    <button class="button button--neutral button--icon button--pid" type="button" aria-label="P&amp;ID 보기">P&amp;ID</button>
                                </div>
                            </td>
                            <th scope="row">상태</th>
                            <td data-field="상태">${vwGeniInfo.eqStatus}</td>
                        </tr>
                        <tr>
                            <th scope="row">설비번호</th>
                            <td data-field="설비번호">${vwGeniInfo.equipNo}</td>
                            <th scope="row">설비명</th>
                            <td data-field="설비명">${vwGeniInfo.description}</td>
                        </tr>
                        <tr>
                            <th scope="row">기능위치번호</th>
                            <td data-field="기능위치번호">${vwGeniInfo.locNo}</td>
                            <th scope="row">기능위치명</th>
                            <td data-field="기능위치명" colspan="3">${vwGeniInfo.locNm}</td>
                        </tr>
                        <tr>
                            <th scope="row">계통코드</th>
                            <td data-field="계통코드">${vwGeniInfo.eqCategory}</td>
                            <th scope="row">계통코드명</th>
                            <td data-field="계통코드명" colspan="3">${vwGeniInfo.eqCategoryNm}</td>
                        </tr>
                        <tr>
                            <th scope="row">종류코드</th>
                            <td data-field="종류코드">${vwGeniInfo.eqType}</td>
                            <th scope="row">종류코드명</th>
                            <td data-field="종류코드명" colspan="3">${vwGeniInfo.eqTypeNm}</td>
                        </tr>
                        <tr>
                            <th scope="row">TAG_NO</th>
                            <td data-field="TAG_NO">${vwGeniInfo.tagNo}</td>
                            <th scope="row">PNID_NO</th>
                            <td data-field="PNID_NO" colspan="3">${vwGeniInfo.pnidNo}</td>
                        </tr>
                        <tr>
                            <th scope="row">자산번호</th>
                            <td data-field="자산번호">${vwGeniInfo.assetNo}</td>
                            <th scope="row">자산명</th>
                            <td data-field="자산명" colspan="3">${vwGeniInfo.assetNm}</td>
                        </tr>
                        <tr>
                            <th scope="row">계층구조</th>
                            <td data-field="계층구조" colspan="3">${vwGeniInfo.labelInfo}</td>
                        </tr>
                        </tbody>
    
                            <%-- 대표설비 뷰 --%>
                        <c:if test="${not empty mainGeniInfo}">
                            <tfoot>
                            <tr class="main-equipment">
                                <th scope="row">대표설비</th>
                                <td data-field="대표설비" colspan="5">
                                    <div class="main-info-box">
                                        <div class="fac-root"><span class="badge text-bg-primary">호기</span> ${mainGeniInfo.hokiNm}</div>
                                        <div class="fac-code"><span class="badge text-bg-info">설비번호</span> ${mainGeniInfo.equipNo}</div>
                                        <div class="fac-name"><span class="badge text-bg-info">설비명</span> ${mainGeniInfo.description}</div>
                                    </div>
                                </td>
                            </tr>
                            </tfoot>
                        </c:if>
                    </table>
                </div>
            </section>
            
            <%-- 포함설비 리스트 --%>
            <c:if test="${not empty includeList}">
            <section class="panel-split-layout__group panel-split-layout__group--secondary">
                <div class="result-header">
                    <h2 class="result-header__title">포함설비 목록</h2>
                </div>
                
                <div class="table-responsive">
                    <table class="data-table data-table--list data-table--interactive" aria-label="포함설비목록">
                        <thead>
                        <tr>
                                <%--<th scope="col" data-field="순번">순번</th>--%>
                            <th scope="col" data-field="호기">호기</th>
                            <th scope="col" data-field="설비유형">설비유형</th>
                            <th scope="col" data-field="포함설비번호">포함설비번호</th>
                            <th scope="col" data-field="포함설비명">포함설비명</th>
                        </tr>
                        </thead>
                        <tbody>
                            <%-- <!-- tr 클릭 시 해당 부분 클래스 추가해 주세요. tr class="active" -->
                            <!-- 다른 행을 클릭하면 이전에 추가된 active 클래스는 제거하고, 새로 클릭한 행에 active 클래스 추가해 주세요. --> --%>
                        <c:forEach var="data" items="${includeList}" varStatus="status">
                            <tr class="_TR_INFO_INCLUDE" onclick="fnFacilityIncludePopup(this,'${data.equipNo}')">
                                    <%--<td data-field="순번"></td>--%>
                                <td data-field="호기">${data.hokiNm}</td>
                                <td data-field="설비유형">${data.eqType}</td>
                                <td data-field="포함설비번호">${data.equipNo}</td>
                                <td data-field="포함설비명">${data.description}</td>
                            </tr>
                        </c:forEach>
                        </tbody>
                    </table>
                </div>
            </section>
            </c:if>
        </div>
        
        <div class="splitview__pane splitview__pane--content panel-split-layout__content" role="region" aria-label="설비사진">
            <section class="panel-split-layout__group panel-split-layout__group--primary">
                <%-- 설비 사진 부분 : controller에서 조건 체크 --%>
                <div class="result-header">
                    <h2 class="result-header__title">설비사진</h2>
                </div>
                
                <div class="facility-photo">
                    <img id="equipImage" src="/modelImages/${vwGeniInfo.equipNo}.jpg" alt="${vwGeniInfo.equipNo}" class="img-fluid">
                </div>
                <%-- </c:if> --%>
            </section>
        </div>
    <%--</div>--%>

    <script>
        $(function () {
            <%-- 설비정보 보기 구분 --%>
            var panoInfoChk = $("#panoInfo").val();
            var facilityRefListChk = $("#facilityRefList").val();

            if (facilityRefListChk === 0) {
                $("#externalPopup #_FACILITY_DETAIL_VIEW_INFO").hide();
            }

            if (panoInfoChk === 1) {
                $("#externalPopup #_FACILITY_DETAIL_VIEW_INFO").show();
                $("#infoTitle").hide();
                $("#infoMessage").hide();
                $("#infoNoData").hide();
            }

            <%-- 파노라마에 설비번호/태그번호 넘김 --%>
            <c:choose>
            <c:when test="${not empty geniInfo.iegTagno}">
            $("#moveToPanorama").attr('data-no', '${geniInfo.iegNo}');
            $("#moveToPanorama").attr('data-tag-no', '${geniInfo.iegTagno}');
            $("#moveToPanorama").removeClass('disabled');
            </c:when>
            <c:otherwise>
            $("#moveToPanorama").addClass('disabled');
            </c:otherwise>
            </c:choose>
        });
    </script>
</c:if>