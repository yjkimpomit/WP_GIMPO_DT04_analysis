<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>

<div class="result-header">
	<h2 class="result-header__title">자재상세</h2>
</div>

<!-- info -->
<div class="table-responsive">
	<table class="data-table data-table--view data-table--detail" data-tab-id="modelTab04-pane" aria-label="자재상세">
		<colgroup>
			<col style="width: 180px;">
			<col>
			<col style="width: 180px;">
			<col>
			<col style="width: 180px;">
			<col>
		</colgroup>
		<tbody>
			<tr>
				<th scope="row">자재번호</th>
				<td data-field="자재번호">${materialInfo.partNo}</td>
				<th scope="row">MEIC</th>
				<td data-field="MEIC">${materialInfo.meic}</td>
				<th scope="row">자재그룹</th>
				<td data-field="자재그룹">${materialInfo.ptGroup}</td>
			</tr>
			<tr>
				<th scope="row">자재클래스</th>
				<td data-field="자재클래스">${materialInfo.ptClass}</td>
				<th scope="row">자재클래스명</th>
				<td data-field="자재클래스">${materialInfo.ptClassDesc}</td>
				<th scope="row">단위</th>
				<td data-field="단위">[${materialInfo.uom}] ${materialInfo.uomDesc}</td>
			</tr>
			<tr>
				<th scope="row">구 자재번호</th>
				<td data-field="구자재번호">${materialInfo.oldPartNo}</td>
				<th scope="row">품질등급</th>
				<td data-field="품질등급">${materialInfo.qualityGrade}</td>
				<th scope="row">생성요청자</th>
				<td data-field="생성요청자">${materialInfo.enterBy}</td>
			</tr>
			<tr>
				<th scope="row">생성요청부서</th>
				<td data-field="생성요청부서">${materialInfo.reqDeptNo}</td>
				<th scope="row">생성일</th>
				<td data-field="생성일">
					<c:choose>
						<c:when test="${fn:length(materialInfo.enterDate) == 0}">
							${materialInfo.enterDate}
						</c:when>
						<c:when test="${fn:length(materialInfo.enterDate) != 0}">
							<c:out value='${fn:substring(materialInfo.enterDate, 0, 4)}-'/><c:out value='${fn:substring(materialInfo.enterDate, 4, 6)}-'/><c:out value='${fn:substring(materialInfo.enterDate, 6, 8)}'/>
						</c:when>
					</c:choose>
				</td>
				<th scope="row">변경일</th>
				<td data-field="변경일">
					<c:choose>
						<c:when test="${fn:length(materialInfo.updateDate) == 0}">
							${materialInfo.updateDate}
						</c:when>
						<c:when test="${fn:length(materialInfo.updateDate) != 0}">
							<c:out value='${fn:substring(materialInfo.updateDate, 0, 4)}-'/><c:out value='${fn:substring(materialInfo.updateDate, 4, 6)}-'/><c:out value='${fn:substring(materialInfo.updateDate, 6, 8)}'/>
						</c:when>
					</c:choose>
				</td>
			</tr>
			<tr>
				<th scope="row">호기</th>
				<td data-field="호기">52921</td>
				<th scope="row">주 설비명</th>
				<td data-field="주설비명" colspan="3">${materialInfo.equipDesc}</td>
			</tr>
			<tr>
				<th scope="row">품명 및 규격</th>
				<td data-field="품명및규격" colspan="5">${materialInfo.ptSize}</td>
			</tr>
			<tr>
				<th scope="row">연간소요량</th>
				<td data-field="연간소요량"><fmt:formatNumber value="${materialInfo.yearQty}" pattern="#,###" /></td>
				<th scope="row">총누적소요량</th>
				<td data-field="총누적소요량"><fmt:formatNumber value="${materialInfo.consistQty}" pattern="#,###" /></td>
				<th scope="row">자재유형</th>
				<td data-field="자재유형">${materialInfo.ptTypeCode}</td>
			</tr>
			<tr>
				<th scope="row">인수검사여부</th>
				<td data-field="인수검사여부">${materialInfo.isDelete}</td>
				<th scope="row">공장검사여부</th>
				<td data-field="공장검사여부">${materialInfo.needGubun}</td>
				<th scope="row">시리얼넘버</th>
				<td data-field="시리얼넘버">${materialInfo.serailNo}</td>
			</tr>
			<tr>
				<th scope="row">제조사 부품식별번호</th>
				<td data-field="제조사부품식별번호">${materialInfo.vendorPartNo}</td>
				<th scope="row">제조사</th>
				<td data-field="제조사">${materialInfo.vendorDesc}</td>
				<th scope="row">모델넘버</th>
				<td data-field="모델넘버">${materialInfo.model}</td>
			</tr>
		</tbody>
	</table>
</div>
