<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core"%>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui"%>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions"%>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form"%>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt"%>

<c:if test="${mhInfo == null}">
    <div class="no-data">
        정비이력이 없습니다.
    </div>
</c:if>

<c:if test="${mhInfo != null}">
<div class="title-box">
		<div>
			<h5 class="title04 my-0">${mhInfo.equipDesc} 정비상세</h5>
		</div>
</div>
<div class="table-responsive">
	<table class="data-table data-table--view data-table--detail" data-tab-id="modelTab02-pane" aria-label="정비상세">
		<colgroup>
			<col style="width: 160px;">
			<col>
			<col style="width: 160px;">
			<col>
			<col style="width: 160px;">
			<col>
			<col style="width: 160px;">
			<col>
		</colgroup>
		<tbody>
			<tr>
				<th scope="row">오더번호</th>
				<td data-field="오더번호">${mhInfo.woNo}</td>
				<th scope="row">오더명</th>
				<td data-field="오더명" colspan="5">${mhInfo.woDesc}</td>
			</tr>
			<tr>
				<th scope="row">설비번호</th>
				<td data-field="설비번호">${mhInfo.equipNo}</td>
				<th scope="row">설비명</th>
				<td data-field="설비명" colspan="5">${mhInfo.equipDesc}</td>
			</tr>
			<tr>
				<th scope="row">진행상태</th>
				<td data-field="진행상태">${mhInfo.woStatus}</td>
				<th scope="row">오더타입</th>
				<td data-field="오더타입">${mhInfo.woCategory}</td>
				<th scope="row">정비조건</th>
				<td data-field="정비조건" colspan="3">${mhInfo.workableCondition}</td>
			</tr>
			<tr>
				<th scope="row">요청번호</th>
				<td data-field="요청번호">
					<c:choose>
							<c:when test="${mhInfo.noticeNo == '0'}">
							
							</c:when>
							<c:when test="${mhInfo.noticeNo != '0'}">
								${mhInfo.noticeNo}
							</c:when>
					</c:choose>
				</td>
				<th scope="row">요청종류</th>
				<td data-field="요청종류">${mhInfo.noticeType}</td>
				<th scope="row">요청일자</th>
				<td data-field="요청일자" colspan="3">
					<c:choose>
						<c:when test="${fn:length(mhInfo.noticeReqDate) == 0}">
							${mhInfo.noticeReqDate}
						</c:when>
						<c:when test="${fn:length(mhInfo.noticeReqDate) != 0}">
							<c:out value='${fn:substring(mhInfo.noticeReqDate, 0, 4)}-'/><c:out value='${fn:substring(mhInfo.noticeReqDate, 4, 6)}-'/><c:out value='${fn:substring(mhInfo.noticeReqDate, 6, 8)}'/>
						</c:when>
					</c:choose>
				</td>
			</tr>
			<tr>
				<th scope="row">요청명</th>
				<td data-field="요청명" colspan="7">${mhInfo.noticeDesc}</td>
			</tr>
			<tr>
				<th scope="row">요청내용</th>
				<td data-field="요청내용" colspan="7">${mhInfo.noticeRemark}</td>
			</tr>
			<tr>
				<th scope="row">설계자 사번</th>
				<td data-field="설계자사번">${mhInfo.planBy}</td>
				<th scope="row">설계자이름</th>
				<td data-field="설계자이름">${mhInfo.planName}</td>
				<th scope="row">설계부서</th>
				<td data-field="설계부서" colspan="3">${mhInfo.deptName}</td>
			</tr>
			<tr>
				<th scope="row">정비부서</th>
				<td data-field="정비부서">${mhInfo.workDeptName}</td>
				<th scope="row">작업중요도</th>
				<td data-field="작업중요도" colspan="5">${mhInfo.woGrade}</td>
			</tr>
			<tr>
				<th scope="row">설계 시작일</th>
				<td data-field="설계시작일"><c:out value='${fn:substring(mhInfo.planStartDate, 0, 4)}-'/><c:out value='${fn:substring(mhInfo.planStartDate, 4, 6)}-'/><c:out value='${fn:substring(mhInfo.planStartDate, 6, 8)}'/></td>
				<th scope="row">설계 완료일</th>
				<td data-field="설계완료일"><c:out value='${fn:substring(mhInfo.planEndDate, 0, 4)}-'/><c:out value='${fn:substring(mhInfo.planEndDate, 4, 6)}-'/><c:out value='${fn:substring(mhInfo.planEndDate, 6, 8)}'/></td>
				<th scope="row">실제 시작일</th>
				<td data-field="실제시작일"><c:out value='${fn:substring(mhInfo.workStartDate, 0, 4)}-'/><c:out value='${fn:substring(mhInfo.workStartDate, 4, 6)}-'/><c:out value='${fn:substring(mhInfo.workStartDate, 6, 8)}'/></td>
				<th scope="row">실제 완료일</th>
				<td data-field="실제완료일"><c:out value='${fn:substring(mhInfo.workEndDate, 0, 4)}-'/><c:out value='${fn:substring(mhInfo.workEndDate, 4, 6)}-'/><c:out value='${fn:substring(mhInfo.workEndDate, 6, 8)}'/></td>
			</tr>
			<tr>
				<th scope="row">WBS코드</th>
				<td data-field="WBS코드" colspan="7"></td>
			</tr>
			<tr>
				<th scope="row">작업내용</th>
				<td data-field="작업내용" colspan="7"></td>
			</tr>
		</tbody>
	</table>
</div>
</c:if>