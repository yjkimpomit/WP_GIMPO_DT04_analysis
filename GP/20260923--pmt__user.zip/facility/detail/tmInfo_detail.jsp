<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup">
    <div class="modal-body">
        <div class="table-responsive">
            <table class="data-table data-table--view data-table--detail" data-tab-id="modelTab05-pane" aria-label="TM-이력-상세보기">
                <colgroup>
                    <col style="width: 128px;">
                    <col>
                    <col style="width: 128px;">
                    <col>
                </colgroup>
                <tbody>
                <tr>
                    <th scope="row">요청명</th>
                    <td data-field="요청명">${tmInfo.description}</td>
                    <th scope="row">설비번호</th>
                    <td data-field="설비번호">${tmInfo.equipNo}</td>
                </tr>
                <tr>
                    <th scope="row">요청자</th>
                    <td data-field="요청자">${tmInfo.reqByNm}</td>
                    <th scope="row">요청부서</th>
                    <td data-field="요청부서">[${tmInfo.reqDeptNo}] ${tmInfo.reqDeptNm}</td>
                </tr>
                <tr>
                    <th scope="row">감독부서</th>
                    <td data-field="감독부서">[${tmInfo.deptNo}] ${tmInfo.deptNm}</td>
                    <th scope="row">우선순위</th>
                    <td data-field="우선순위">
                        <c:choose>
                            <c:when test="${tmInfo.priority == 'E'}">
                                긴급
                            </c:when>
                            <c:when test="${tmInfo.priority == 'G'}">
                                일상
                            </c:when>
                            <c:when test="${tmInfo.priority == 'S'}">
                                사후
                            </c:when>
                        </c:choose>
                    </td>
                </tr>
                <tr>
                    <th scope="row">작업중요도</th>
                    <td data-field="작업중요도">
                        <c:choose>
                            <c:when test="${tmInfo.woGrade == 'A'}">
                                A등급(중요작업)
                            </c:when>
                            <c:when test="${tmInfo.woGrade == 'B'}">
                                B등급(일반작업)
                            </c:when>
                            <c:when test="${tmInfo.woGrade == 'C'}">
                                C등급(경미한작업)
                            </c:when>
                        </c:choose>
                    </td>
                    <th scope="row">Red Tag</th>
                    <td data-field="Red Tag">${tmInfo.isWorkConfirm}</td>
                </tr>
                <tr>
                    <th scope="row">증상</th>
                    <td data-field="증상">
                        <c:choose>
                            <c:when test="${tmInfo.symptom == 'S010'}">
                                누설 (Leakage)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S020'}">
                                오지시 (Indication Error)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S030'}">
                                오염 (Contamination)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S040'}">
                                손상/파손 (Breakdown)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S050'}">
                                변형 (Deformation)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S060'}">
                                파열 (Rupture)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S070'}">
                                부식/침식 (Corrosion/Erosion)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S080'}">
                                진동이상 (Vibration)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S090'}">
                                이음(소음) (Noise)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S100'}">
                                단선/단락 (Disconnection/Short-circuit)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S110'}">
                                동결 (Freezing)
                            </c:when>
                            <c:when test="${tmInfo.symptom == 'S120'}">
                                과부하 (Over Load)
                            </c:when>
                        </c:choose>
                    </td>
                    <th scope="row">사업자코드</th>
                    <td data-field="사업자코드">${tmInfo.eqOrgNo}</td>
                </tr>
                <tr>
                    <th scope="row">요청내용</th>
                    <td data-field="요청내용" colspan="3">
                        <div class="overflow-y-scroll" style="height: 100px;">${tmInfo.remark}</div>
                    </td>
                </tr>
                </tbody>
            </table>
        </div>
    </div>
</main>
</body>
<c:import url="/footer.do"/>


