<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<div class="result-header">
    <h2 class="result-header__title">운전정보<span class="result-header__count"></span></h2>
</div>

<!-- 설비정보의 운전정보 리스트 -->
<div class="table-responsive">
    <table class="data-table data-table--list data-table--interactive" aria-label="운전정보">
        <colgroup>
            <col style="width: 196px;">
            <col>
            <col style="width: 128px;">
            <col style="width: 96px;">
            <col style="width: 160px;">
        </colgroup>
        <thead>
        <tr>
            <th scope="col" data-field="태그">태그</th>
            <th scope="col" data-field="상세정보">상세정보</th>
            <th scope="col" data-field="운전정보">운전정보</th>
            <th scope="col" data-field="예측값">예측값</th>
            <th scope="col" data-field="TREND">TREND</th>
        </tr>
        </thead>
        <tbody>
        <c:if test="${empty operationList}">
            <tr>
                <td class="text-center" colspan="6">
                    <div class="no-data">조회된 데이터가 없습니다.</div>
                </td>
            </tr>
        </c:if>
        <c:forEach var="data" items="${operationList}" varStatus="status">
            <tr>
                <td data-field="태그">${data.iegTagno}</td>
                <td data-field="상세정보">${data.iegDescription}</td>
                <td data-field="운전정보">${data.operationValue}</td>
                <td data-field="예측값">${data.operationValue}</td>
                <td data-field="TREND">
                    <c:choose>
                        <c:when test="${data.trendYn eq 'Y'}">
                            <button type="button" class="button button--sm button--neutral" onclick="openTrendPopup('${data.iegTagno}','${data.time}')">
                                <span>트렌드 보기</span>
                            </button>
                        </c:when>
                        <c:otherwise>-</c:otherwise>
                    </c:choose>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>



