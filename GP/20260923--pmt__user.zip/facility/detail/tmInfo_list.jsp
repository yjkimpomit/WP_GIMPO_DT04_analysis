<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 설비상세정보 > TM이력의 리스트 --%>
<table class="data-table data-table--list data-table--interactive" aria-label="TM-이력">
    <thead>
    <tr>
        <%--<!--  <th scope="col" data-field="진행상태">진행상태</th> -->--%>
        <th scope="col" data-field="요청번호">요청번호</th>
        <th scope="col" data-field="요청명">요청명</th>
        <th scope="col" data-field="요청일자">요청일자</th>
        <th scope="col" data-field="요청자">요청자</th>
        <th scope="col" data-field="요청부서">요청부서</th>
        <th scope="col" data-field="감독부서">감독부서</th>
        <th scope="col" data-field="설비번호">설비번호</th>
        <th scope="col" data-field="설비명">설비명</th>
        <th scope="col" data-field="작업중요도">작업중요도</th>
        <th scope="col" data-field="우선순위">우선순위</th>
        <th scope="col" data-field="증상">증상</th>
    </tr>
    </thead>
    <tbody>
    <c:if test="${empty list}">
        <tr>
            <th colspan="11">
                <div class="no-data">
                    조회된 데이터가 없습니다.
                </div>
            </th>
        </tr>
    </c:if>

    <c:forEach var="data" items="${list}" varStatus="status">
        <!-- tm 상세화면 별도 페이지 처리 -->
        <tr class="_TR_INFO_TM" onclick="showTmDetailView(this, ${data.equipNo}, ${data.idx})">
                <%-- <th scope="row" data-field="진행상태">
                <c:choose>
                        <c:when test="${data.eaiFlag == 'N'}">
                            작업중
                        </c:when>
                        <c:when test="${data.woGrade == 'Y'}">
                            작업완료
                        </c:when>
                    </c:choose>
                </th> --%>
            <th scope="col" data-field="요청번호" id="TH_INFO_TM_IDX">${data.idx}</th>
            <th scope="col" data-field="요청명" id="TH_INFO_TM_DESCRIPTION">${data.description}</th>
            <td data-field="요청일자" id="TH_INFO_TM_TIMECREATED"><c:out value='${fn:substring(data.timecreated, 0, 10)}'/></td>
            <td data-field="요청자" id="TH_INFO_TM_REQ_BY">${data.reqByNm}</td>
            <td data-field="요청부서" id="TH_INFO_TM_REQ_DEPT_NO">${data.reqDeptNm}</td>
            <td data-field="감독부서" id="TH_INFO_TM_DEPT_NO">${data.deptNm}</td>
            <td data-field="설비번호" id="TH_INFO_TM_EQUIP_NO">${data.equipNo}</td>
            <td data-field="설비명" id="TH_INFO_TM_EQUIP_NM">${data.equipNm}</td>
            <td data-field="작업중요도" id="TH_INFO_TM_WO_GRADE">
                <c:choose>
                    <c:when test="${data.woGrade == 'A'}">
                        A등급(중요작업)
                    </c:when>
                    <c:when test="${data.woGrade == 'B'}">
                        B등급(일반작업)
                    </c:when>
                    <c:when test="${data.woGrade == 'C'}">
                        C등급(경미한작업)
                    </c:when>
                </c:choose>
            </td>
            <td data-field="우선순위" id="TH_INFO_TM_PRIORITY">
                <c:choose>
                    <c:when test="${data.priority == 'E'}">
                        긴급
                    </c:when>
                    <c:when test="${data.priority == 'G'}">
                        일상
                    </c:when>
                    <c:when test="${data.priority == 'S'}">
                        사후
                    </c:when>
                </c:choose>
            </td>
            <td data-field="증상" id="TH_INFO_TM_SYMPTOM">
                <c:choose>
                    <c:when test="${data.symptom == 'S010'}">
                        누설 (Leakage)
                    </c:when>
                    <c:when test="${data.symptom == 'S020'}">
                        오지시 (Indication Error)
                    </c:when>
                    <c:when test="${data.symptom == 'S030'}">
                        오염 (Contamination)
                    </c:when>
                    <c:when test="${data.symptom == 'S040'}">
                        손상/파손 (Breakdown)
                    </c:when>
                    <c:when test="${data.symptom == 'S050'}">
                        변형 (Deformation)
                    </c:when>
                    <c:when test="${data.symptom == 'S060'}">
                        파열 (Rupture)
                    </c:when>
                    <c:when test="${data.symptom == 'S070'}">
                        부식/침식 (Corrosion/Erosion)
                    </c:when>
                    <c:when test="${data.symptom == 'S080'}">
                        진동이상 (Vibration)
                    </c:when>
                    <c:when test="${data.symptom == 'S090'}">
                        이음(소음) (Noise)
                    </c:when>
                    <c:when test="${data.symptom == 'S100'}">
                        단선/단락 (Disconnection/Short-circuit)
                    </c:when>
                    <c:when test="${data.symptom == 'S110'}">
                        동결 (Freezing)
                    </c:when>
                    <c:when test="${data.symptom == 'S120'}">
                        과부하 (Over Load)
                    </c:when>
                </c:choose>
            </td>
        </tr>
    </c:forEach>
    </tbody>
</table>

