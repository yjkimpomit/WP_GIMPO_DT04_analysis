<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보의 연계문서 리스트 -->

<div class="result-header">
    <h2 class="result-header__title">연계문서<span class="result-header__count">(전체 <fmt:formatNumber value="${listCount}" type="number"/>)</span></h2>
    
    <div class="result-header__actions">
        <div class="form-choice-list">
            <label class="visually-hidden" for="selType">문서타입</label>
            <select class="form-select" id="selType" onchange="fnSelSearchType(this.value)">
                <option value="">전체</option>
                <c:forEach var="type" items="${typeList}" varStatus="status">
                    <c:set var="selected" value=""/>
                    <c:if test="${facilityFileVO.ieftTypeCode eq type.ieftTypeCode}"><c:set var="selected" value="selected"/></c:if>
                    <option value="${type.ieftTypeCode}" ${selected}>${type.ieftTypeName} (<fmt:formatNumber value="${type.typeCount}" type="number"/>)</option>
                </c:forEach>
            </select>
        </div>
    </div>
</div>

<div class="table-responsive">
    <table class="data-table data-table--list data-table--interactive" aria-label="연계문서">
        <colgroup>
            <col style="width: 196px;">
            <col>
            <col style="width: 128px;">
        </colgroup>
        <thead>
        <tr>
            <th scope="col" data-field="파일타입">파일타입</th>
            <th scope="col" data-field="파일명">파일명</th>
            <th scope="col" data-field="다운로드">다운로드</th>
        </tr>
        </thead>
        <tbody>
        <c:if test="${empty list}">
            <tr>
                <td class="text-center" colspan="3">
                    <div class="no-data">조회된 데이터가 없습니다.</div>
                </td>
            </tr>
        </c:if>
        <c:forEach var="data" items="${list}" varStatus="status">
            <tr>
                <td data-field="파일타입">${data.ieftTypeName}</td>
                <td data-field="파일명">${data.fileName}</td>
                <td data-field="다운로드">
                    <button type="button" class="button button--sm button--primary" onclick="fnFileDownload('${data.saveFileName}')">다운로드</button>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>


