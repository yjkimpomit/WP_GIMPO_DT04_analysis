<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보 연계문서 탭메뉴 -->

<div class="result-panel">
    <div class="result-panel__body"  id="_DIV_FILE_LIST">
    <%-- file list --%>
    </div>
</div>

<form id="searchFormList">
    <input type="hidden" id="iegNo" name="iegNo" value="${facilityFileVO.iegNo}">
    <input type="hidden" id="typeCode" name="ieftTypeCode" value="${facilityFileVO.ieftTypeCode}">
</form>

<script src="${pageContext.request.contextPath}/resources/user/js/file/custom-file.js"></script>
<script>
    function fnOperationList() {
        $.ajax({
            type: "POST"
            , url: "/facility/fileList.do"
            , data: $("#searchFormList").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_DIV_FILE_LIST").html(data);
            },
            error: function (e) {
                console.log(e);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    function fnSelSearchType(v) {
        $("#searchFormList #typeCode").val(v);
        fnOperationList();
    }

    function fnFileDownload(targetName) {
        $.confirm({
            title: "파일 다운로드", content: "파일을 다운로드하겠습니까?", type: 'blue', buttons: {
                '확인': {
                    btnClass: 'btn-blue', action: function () {
                        $.ajax({
                            type: "POST", url: "/facility/fileDownload.do", data: {saveFileName: targetName}, xhrFields: {
                                responseType: 'blob'
                            }, beforeSend: function () {
                                $("#loadingBar").show();
                            }, success: function (data, message, xhr) {
                                var blob = data;
                                var fileName = "";

                                var disposition = xhr.getResponseHeader('Content-Disposition');
                                if (disposition && disposition.indexOf('attachment') !== -1) {
                                    var filenameRegex = /filename[^;=\n]*=((['"]).*?\2|[^;\n]*)/;
                                    var matches = filenameRegex.exec(disposition);
                                    if (matches != null && matches[1]) {
                                        fileName = decodeURIComponent(matches[1].replace(/['"]/g, '').replace('UTF-8\'\'', ''));
                                    }
                                }

                                var link = document.createElement('a');
                                link.href = URL.createObjectURL(blob);
                                link.download = fileName;
                                link.click();
                                URL.revokeObjectURL(link.href);
                            }, error: function (request, status, error) {
                                title = "파일 다운로드";
                                if (request.status === 404) {
                                    content = "다운로드할 파일이 없습니다.";
                                } else {
                                    content = "오류가 발생했습니다.";
                                }
                                fnMsg();
                            }, complete: function () {
                                $("#loadingBar").hide();
                            }
                        });
                    }
                }, '취소': {
                    action: function () {
                    }
                }
            }
        });
    }

    fnOperationList();
</script>