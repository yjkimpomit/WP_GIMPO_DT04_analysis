<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 -->

<!-- TM 이력 -->
<%-- <div class="tab-pane fade" id="modelTab05-pane" role="tabpanel" aria-labelledby="modelTab05" tabindex="0"> --%>

<div class="result-panel">
    <div class="result-panel__body">
        <div class="result-header">
            <h2 class="result-header__title">TM 이력</h2>
            <button class="button button--primary" type="button" onclick="fnFacilityTMDetailPop('${facilityGeniVO.iegNo}')">TM 발행</button>
        </div>
        
        <!-- data-grid -->
        <div class="table-responsive" id="_DIV_TM_INFO_LIST">
            <%-- /detail/tmInfo_list.jsp --%>
        </div>
    </div>

</div>

<%-- </div> --%>

<!-- TM이력 > TM상세 팝업 -->
<div class="modal fade" tabindex="-1" id="tmView">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-xl">
        <div class="modal-content">
            <!-- tmViewDetail start -->

            <!-- tmViewDetail end -->
        </div>
    </div>
</div>

<!-- TM이력 > TM발행 팝업 -->
<div class="modal fade" id="tmModal" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-lg-down modal-xl">
        <div class="modal-content">
        </div>
    </div>
</div>

<%-- use iegNo --%>
<input type="hidden" name="facilityIegNo" id="facilityIegNo" value="${facilityGeniVO.iegNo}"/>

<script>
    var isUpdate = false;

    function fnSearchFacilityTMList() {
        var iegNo = $("#facilityIegNo").val();

        $.ajax({
            type: "post"
            , url: "/facility/tmInfoList.do"
            , data: {iegNo: iegNo}
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            },
            success: function (data) {
                $("#_DIV_TM_INFO_LIST").html(data);
            },
            error: function (request, status, error) {
                title = "TM 이력";
                content = "오류가 발생했습니다.<br>잠시 후 다시 시도하시기 바랍니다.";
                fnAlert();
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    /* TM이력 > TM 이력 상세 팝업 */
    function showTmDetailView(e, equipNo, tmCode) {
        $("._TR_INFO_TM").removeClass('active');
        $(e).addClass('active');

        var data = "equipNo=" + equipNo + "&idx=" + tmCode;
        var url = "/facility/tmInfoDetail.do?" + data;

        var box = new WinBox("TM 상세정보", {
            url: url,
            width: Math.min(1400, window.innerWidth - 20) + "px",
            height: Math.min(720, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    /* TM이력 > TM 발행 팝업 */
    function fnFacilityTMDetailPop(iegNo) {
        var data = "iegNo=" + iegNo;
        var url = "/facility/tmInfoAdd.do?" + data;

        var box = new WinBox("TM 발행", {
            url: url,
            width: Math.min(1400, window.innerWidth - 20) + "px",
            height: Math.min(720, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
                if(isUpdate) {
                    fnSearchFacilityTMList();
                }
            }
        });
    }

    $(document).ready(function () {
        fnSearchFacilityTMList();
    });
</script>

