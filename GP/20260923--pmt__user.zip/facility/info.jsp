<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- <!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 --> --%>

<c:set var="facilitySize">${fn:length(facilityRefList)}</c:set>

<input type="hidden" id="facilityRefList" name="facilityRefList" value="${facilitySize}"/>

<%-- <!-- 설비정보 --> --%>
<%-- <div class="tab-pane fade show active" id="modelTab01-pane" role="tabpanel" aria-labelledby="tab01" tabindex="0"> --%>

<div class="result-panel result-panel--master-detail">
    
    <c:if test="${facilitySize > 0}">
    <div class="result-header">
        <h2 class="result-header__title">
            설비정보
            <span class="result-header__count">(전체 <fmt:formatNumber value="${facilitySize}"/>건 <span aria-hidden="true">/</span> <span id="3dNum">0</span> <span aria-hidden="true">/</span> <span id="panoNum">0</span>)</span>
        </h2>
        
        <div class="result-header__actions">
            <nav class="pagination" aria-label="페이지 이동">
                <input type="number" id="currentPage" class="form-control form-control--page" aria-label="이동할 페이지 번호" value="<c:out value='${paginationInfo.currentPageNo}'/>">
                <span aria-hidden="true">/</span>
                <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
                <button type="button" class="button button--neutral" onclick="fnPageMove('M')">이동</button>
                <button type="button" class="button button--neutral" onclick="fnPageMove('P')">이전</button>
                <button type="button" class="button button--neutral" onclick="fnPageMove('N')">다음</button>
                    <%-- 앱 로그인 체크 --%>
                <c:if test="${sessionScope.loginInfo.iui_isadmin ne '999'}">
                    <button type="button" class="button button--secondary" onclick="fnExcelDownloadWorkOrder()">엑셀 다운로드</button>
                </c:if>
            </nav>
        </div>
    </div>
    
    <div class="info-message" id="infoMessage">조회할 항목을 선택해 주세요.</div>
    <!-- fac list -->
    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="설비정보">
            <thead>
            <tr>
                <th scope="col" data-field="설비번호">설비번호</th>
                <th scope="col" data-field="설비명">설비명</th>
                <th scope="col" data-field="기능위치번호">기능위치번호</th>
                <th scope="col" data-field="계통코드">계통코드</th>
                <th scope="col" data-field="종류코드">종류코드</th>
                <th scope="col" data-field="상태">상태</th>
            </tr>
            </thead>
            <tbody>
            <c:set var="countNum3d" value="0"/>
            <c:set var="countNumPano" value="0"/>

            <c:forEach var="data" items="${facilityRefList}" varStatus="status">
                <c:set var="isBtn3dDisabled" value="disabled"/>
                <c:set var="isBtnPanoDisabled" value="disabled"/>

                <c:if test="${data.iegModelConnect eq 'Y'}"><c:set var="countNum3d" value="${countNum3d + 1}"/></c:if>

                <c:if test="${data.iegModelConnect eq 'Y'}"><c:set var="isBtn3dDisabled" value=""/></c:if>
                <c:if test="${data.panoFlg eq '1' && data.iegModelConnect eq 'Y'}"><c:set var="isBtnPanoDisabled" value=""/></c:if>
                <c:if test="${data.panoFlg eq '1' && data.iegModelConnect eq 'Y'}"><c:set var="countNumPano" value="${countNumPano + 1}"/></c:if>

                <tr class="_TR_INFO">
                    <td data-field="설비번호" onclick="fnFacilityMultiviewPop(this, '${data.equipNo}')">${data.equipNo}</td>
                    <td data-field="설비명">
                        <a href="javascript:" onclick="fnFacilityDetailInfo(this, '${data.equipNo}')">${data.description}</a>

                        <%-- <!-- 유니티 모델로 바로 이동하는 버튼, 연결 모델이 없는 경우에는 버튼 클래스에 disabled 추가해 주세요. --> --%>
                        <button type="button" class="button button--sm button--secondary ${isBtn3dDisabled}" title="3D모델 이동" onclick="fnFacilityTo3D('${data.iegModelType}','${data.equipNo}');">
                            3D 모델
                        </button>
                        <%-- <!-- 파노라마로 바로 이동하는 버튼, 연결 파노라마가 없는 경우에는 버튼 클래스에 disabled 추가해 주세요. --> --%>
                        <button type="button" class="button button--sm button--secondary ${isBtnPanoDisabled}" onclick="fnFacilityToPanorama(this,'${data.equipNo}');" title="파노라마 이동">
                            파노라마
                        </button>
                    </td>
                    <td data-field="기능위치번호">${data.locNo}</td>
                    <td data-field="계통코드">${data.eqCategory}</td>
                    <td data-field="종류코드">${data.eqType}</td>
                    <td data-field="상태">${data.eqStatus}</td>
                </tr>
            </c:forEach>

            <script>
                $("#3dNum").html("3D모델: ${countNum3d}건");
                $("#panoNum").html("파노라마: ${countNumPano}건");
            </script>
            </tbody>
        </table>
    </div>
    </c:if>

    <%-- <!-- detail info --> --%>
    <%--<div class="result-panel__body" id="_FACILITY_DETAIL_VIEW_INFO">--%>
    <div class="splitview panel-split-layout panel-split-layout--two-to-one" id="_FACILITY_DETAIL_VIEW_INFO">
        <c:if test="${facilitySize == 0}">
            <c:import url="/facility/infoDetail.do"/>
        </c:if>
    </div>
</div>

<script>
    var facilityRefListChk = $("#facilityRefList").val();

    if (facilityRefListChk === 0) {
        $("#externalPopup #_FACILITY_DETAIL_VIEW_INFO").hide();
    }

    var panoInfoChk = $("#panoInfo").val();

    if (panoInfoChk === 1) {
        $("#externalPopup #_FACILITY_DETAIL_VIEW_INFO").show();
        $("#infoTitle").hide();
        $("#infoMessage").hide();
        $("#infoNoData").hide();
    }
</script>
<%-- </div> --%>
