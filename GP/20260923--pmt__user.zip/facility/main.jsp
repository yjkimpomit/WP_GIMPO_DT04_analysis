<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 -->

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%-- 3d model connect check  --%>
<c:set var="btn3dViewClass" value="disabled"/>
<c:if test="${geniInfo.iegModelConnect eq 'Y'}">
    <c:set var="btn3dViewClass" value=""/>
</c:if>

<!-- 우측 콘텐츠 -->
<main class="winbox-layout tabs tabs--scrollable" data-tabs>

    <!-- 제목영역 -->
    <div class="title-box">
        <div>
            <h3 class="title02">${geniInfo.iegDecription}</h3>
        </div>
        <div class="buttons">
            <button type="button" class="btn btn-xs btn-primary ${btn3dViewClass}" id="moveTo3D" onclick="modelLoadToUnity('${geniInfo.iegModelType}','${geniInfo.iegNo}');">
                <span class="icon icon-3d"></span><span>3D 모델</span>
            </button>
        </div>
    </div>

    <ul class="nav nav-tabs" id="facTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active _TAB_PAGE" id="modelTab01" data-bs-toggle="tab" data-bs-target="#modelTab01-pane" type="button" role="tab" aria-controls="tab01-pane" aria-selected="true" data-page="/info.do">설비정보</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab02" data-bs-toggle="tab" data-bs-target="#modelTab02-pane" type="button" role="tab" aria-controls="tab02-pane" aria-selected="false" data-page="/maintenanceHistory.do">정비이력</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab04" data-bs-toggle="tab" data-bs-target="#modelTab04-pane" type="button" role="tab" aria-controls="tab04-pane" aria-selected="false" data-page="/materialInfo.do">자재정보</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab05" data-bs-toggle="tab" data-bs-target="#modelTab05-pane" type="button" role="tab" aria-controls="tab05-pane" aria-selected="false" data-page="/tmInfo.do">TM 이력</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="modelTab06" data-bs-toggle="tab" data-bs-target="#modelTab06-pane" type="button" role="tab" aria-controls="tab06-pane" aria-selected="false" data-page="/operationInfo.do">운전정보</button>
        </li>
    </ul>

    <!-- 탭 콘텐츠 -->
    <div class="tab-content" id="facTabContent">

        <!-- 설비정보 -->
        <div class="tab-pane fade show active" id="modelTab01-pane" role="tabpanel" aria-labelledby="tab01" tabindex="0">
            <c:import url="/facility/info.do"/>
        </div>
        <!-- 설비정보 End -->

        <!-- 정비이력 -->
        <div class="tab-pane fade" id="modelTab02-pane" role="tabpanel" aria-labelledby="modelTab02" tabindex="0">
        </div>

        <!-- 고장이력 -->
        <div class="tab-pane fade" id="modelTab03-pane" role="tabpanel" aria-labelledby="modelTab03" tabindex="0">
        </div>

        <!-- 자재정보 -->
        <div class="tab-pane fade" id="modelTab04-pane" role="tabpanel" aria-labelledby="modelTab04" tabindex="0">
        </div>

        <!-- TM 이력 -->
        <div class="tab-pane fade" id="modelTab05-pane" role="tabpanel" aria-labelledby="modelTab05" tabindex="0">
        </div>

        <!-- 운전정보 -->
        <div class="tab-pane fade" id="modelTab06-pane" role="tabpanel" aria-labelledby="modelTab06" tabindex="0">
        </div>
        <!-- 운전정보 end -->

    </div>
</main>

<script src="${pageContext.request.contextPath}/resources/user/js/facility/custom-facility.js"></script>
<script>
    $(document).ready(function () {
        var facilityRefListChk = $("#facilityRefList").val();
        if (facilityRefListChk === 0) {
            $("#_FACILITY_DETAIL_VIEW_INFO").hide();
        }

        // 3D 모델에서 설비정보 클릭시, 이동버튼 가림처리
        $("#moveTo3D").hide();

        if ($(".facility").length) {
            $("#moveTo3D").show();

            // 설비정보팝업 > 3D모델 이동 버튼 클릭시 콘텐츠 제거 후, 모달창 초기화
            $("#moveTo3D").click(function () {
                window.parent.$(".winbox:not(.min) .wb-min").trigger('click');
            });
        }

        /* 페이지 로딩 */
        $("._TAB_PAGE").click(function (e) {
            e.preventDefault();
            $("#modelTab01-pane, #modelTab02-pane, #modelTab03-pane, #modelTab04-pane, #modelTab05-pane, #modelTab06-pane").empty();

            var target = $(this).attr("data-bs-target");
            var url = "/facility" + $(this).attr("data-page");

            $.ajax({
                type: "post"
                , url: url
                , data: {iegNo: "${geniInfo.iegNo}"}
                , dataType: "html"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    $(target).html(data);
                }
                , error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                }
                , complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        });
    });
</script>
</body>
<c:import url="/footer.do"/>