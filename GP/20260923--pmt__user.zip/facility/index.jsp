<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body>

<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content">
    
    <div class="page-content__placeholder page-content__placeholder--flex">
        <h1 class="page-content__heading">설비 검색</h1>
        <div class="equipment-search" role="search" aria-label="설비 검색">
            <div class="equipment-search__controls">
                <label class="visually-hidden" for="facSearchInput">설비 검색</label>
                <select class="form-select equipment-search__type" id="facSelect" aria-label="검색 조건">
                    <option value="1">설비</option>
                    <option value="2">부품</option>
                </select>
                <input class="form-control form-control--return equipment-search__input" id="facSearchInput" type="search" placeholder="설비번호/설비명 검색">
                <button class="equipment-search__expand-button is-collapsed" id="facSearchButton" type="button" aria-label="트리 전체 펼치기"></button>
            </div>
            <div class="jstree-box" role="tree" tabindex="0" aria-label="설비 zTree 영역">
                
                <div class="loading-box" id="facLoadingBar" style="display: none;">
                    <div class="loader"></div>
                </div>
                <div id="facTree" class="ztree"></div>
                
            </div>
        </div>
    </div>
    
</main>
<script src="${pageContext.request.contextPath}/resources/user/js/tree/facility-master.js"></script>

<c:if test="${sessionScope.loginInfo.iui_isadmin eq '999'}">
    <%-- 모바일용 : 키보드 닫기 처리 --%>
<script>
    document.addEventListener("keydown", function (event) {
        if (event.key === "Enter") {
            const target = event.target;

            if (
                target instanceof HTMLInputElement ||
                target instanceof HTMLTextAreaElement
            ) {
                // 기존 input/change 이벤트 발생
                target.dispatchEvent(new Event("input", { bubbles: true }));
                target.dispatchEvent(new Event("change", { bubbles: true }));

                if (window.KeyboardBridge && window.KeyboardBridge.hideKeyboard) {
                    window.KeyboardBridge.hideKeyboard();
                }
            }
        }
    });
</script>
</c:if>
</body>
<c:import url="/footer.do"/>
