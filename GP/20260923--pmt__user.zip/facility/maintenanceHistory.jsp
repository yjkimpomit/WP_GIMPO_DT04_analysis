<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!-- 설비정보 영역으로 설비정보 팝업 및 3D 모델 메뉴 클릭시 오픈되는 팝업 -->

<c:set var="mhListSize">${fn:length(mhList)}</c:set>

<!-- 정비이력 -->
<%-- <div class="tab-pane fade" id="modelTab02-pane" role="tabpanel" aria-labelledby="modelTab02" tabindex="0"> --%>

<%--<c:if test="${mhListSize == 0}">
    <div class="no-data">
        정비이력이 없습니다.
    </div>
</c:if>--%>

<div class="result-panel">
    <%--<c:if test="${mhListSize > 0}">--%>
    <div class="result-header">
        <h2 class="result-header__title">
            정비이력
            <span class="result-header__count">(전체 <fmt:formatNumber value="${mhListSize}"/>건)</span>
        </h2>
        
        <div class="result-header__actions">
            <nav class="pagination" aria-label="페이지 이동">
                <input type="number" id="currentPage" class="form-control form-control--page" aria-label="이동할 페이지 번호" value="<c:out value='${paginationInfo.currentPageNo}'/>">
                <span aria-hidden="true">/</span>
                <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
                <button type="button" class="button button--neutral" onclick="fnPageMove('M')">이동</button>
                <button type="button" class="button button--neutral" onclick="fnPageMove('P')">이전</button>
                <button type="button" class="button button--neutral" onclick="fnPageMove('N')">다음</button>
                <%-- 앱 로그인 체크 --%>
                <c:if test="${sessionScope.loginInfo.iui_isadmin ne '999'}">
                    <button type="button" class="button button--secondary" onclick="fnExcelDownloadWorkOrder()">엑셀 다운로드</button>
                </c:if>
            </nav>
        </div>
    </div>
        
    <div class="info-message _MH_MESSAGE">조회할 항목을 선택해 주세요.</div>
    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="정비이력">
            <thead>
            <tr>
                <th scope="col" data-field="설비번호">설비번호</th>
                <th scope="col" data-field="설비명">설비명</th>
                <th scope="col" data-field="오더번호">오더번호</th>
                <th scope="col" data-field="오더타입">오더타입</th>
                <th scope="col" data-field="오더명">오더명</th>
                <th scope="col" data-field="설계일">설계일</th>
                <th scope="col" data-field="상태">상태</th>
            </tr>
            </thead>
            <tbody>
            <%-- 데이터가 없을 경우 --%>
            <c:if test="${empty mhList}">
                <tr>
                    <td colspan="7">
                        <div class="no-data">
                            조회된 데이터가 없습니다.
                        </div>
                    </td>
                </tr>
            </c:if>
            
            <%-- 데이터 루프 부분 --%>
            <c:forEach var="data" items="${mhList}" varStatus="status">
                <tr class="_TR_INFO_MH" onclick="fnFacilityDetailMaintenance($(this), ${data.woNo})">
                    <td data-field="설비번호">${data.equipNo}</td>
                    <td data-field="설비명">${data.equipDesc}</td>
                    <td data-field="오더번호">${data.woNo}</td>
                    <td data-field="오더타입">${data.woCategory}</td>
                    <td data-field="오더명"><span>${data.woDesc}</span></td>
                    <td data-field="설계일"><c:out value='${fn:substring(data.planStartDate, 0, 4)}-'/><c:out value='${fn:substring(data.planStartDate, 4, 6)}-'/><c:out value='${fn:substring(data.planStartDate, 6, 8)}'/></td>
                    <td data-field="상태">${data.woStatus}</td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
    <%--</c:if>--%>
    
    <!-- detail info -->
    <div class="result-panel__body" id="_FACILITY_DETAIL_VIEW_MH"></div>
    <%-- </div> --%>

</div>

