<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script>
    function userCodeDetail(id, name) {
        var chkVal = $("#chkTitleTree").val();

        //요청자
        if (chkVal === "1") {
            window.parent.$('#issuerOption').val(id);
            window.parent.$('#issuerInput').val(name);
            //감독자
        } else if (chkVal === "2") {
            window.parent.$('#supvorOption').val(id);
            window.parent.$('#supvorInput').val(name);
            //점검자
        } else if (chkVal === "3") {
            window.parent.$('#inspectorOption').val(id);
            window.parent.$('#inspectorInput').val(name);
            //발행자
        } else if (chkVal === "4") {
            window.parent.$('#issuerOption').val(id);
            window.parent.$('#issuerInput').val(name);
            //회수자
        } else if (chkVal === "5") {
            window.parent.$('#retrieverOption').val(id);
            window.parent.$('#retrieverInput').val(name);
            //설계자
        } else if (chkVal === "6") {
            window.parent.$('#designerOption').val(id);
            window.parent.$('#designerInput').val(name);
        }

        $('#id_code1').prop('checked', false);

        window.parent.$(".winbox.app-winbox.app-winbox--detail.focus").find(".wb-close").trigger("click");
    }
</script>

<%-- <!-- 요청자, 감독자, 발행자, 회수자, 점검자 공통 팝업 리스트--> --%>
<div class="table-responsive">
    <table class="data-table data-table--list data-table--interactive" aria-label="사용자-데이터">
        <thead>
        <tr>
            <th scope="col" data-field="유저-ID">유저 ID</th>
            <th scope="col" data-field="유저명">유저명</th>
            <th scope="col" data-field="부서">부서</th>
            <th scope="col" data-field="보직코드">보직코드</th>
            <th scope="col" data-field="보직">보직</th>
            <th scope="col" data-field="근무여부">근무여부</th>
        </tr>
        </thead>
        <tbody>
        <%-- 데이터가 없을 경우 --%>
        <c:if test="${fn:length(list) == 0}">
            <tr>
                <th colspan="6">
                    <div class="no-data">
                        조회된 데이터가 없습니다.
                    </div>
                </th>
            </tr>
        </c:if>
        <c:forEach var="data" items="${list}" varStatus="status">
            <tr onclick="userCodeDetail('${data.userId}','${data.userName}')">
                <th scope="row" data-field="유저-ID">${data.userId}</th>
                <td data-field="유저명">${data.userName}</td>
                <td data-field="부서">${data.description}</td>
                <td data-field="보직코드">${data.positionCd}</td>
                <td data-field="보직">${data.positionNm}</td>
                <td data-field="근무여부">${data.isJoin}</td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>
