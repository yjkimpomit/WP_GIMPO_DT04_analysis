<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- W/O 검색 팝업 : 팝업내 검색박스 + 테이블 나오는 팝업 bPopup -->--%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="searchWoTreePopup">
    <h1 class="page-content__heading visually-hidden">W/O 검색</h1>
    <div class="result-panel" id="woSearchListForm">
        <%-- W/O 검색 폼 --%>
    </div>
</main>

<script>
    /* W/O 검색 폼 */
    function fnSearchTreeWoForm() {
        $.ajax({
            type: "POST"
            , url: "/common/wolInfo.do"
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }, success: function (data) {
                $("#woSearchListForm").html(data);
            }, error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }, complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    /* W/O 검색 결과 리스트 */
    function fnWoDetailSearch() {
        var startVal = "";
        var endVal = "";

        //조회 시작일
        startVal = document.getElementById("designDateStart").value;
        //조회 종료일
        endVal = document.getElementById("designDateEnd").value;

        if (startVal !== "" && endVal === "") {
            alert("조회 종료일을 선택해주세요");
            return false;
        } else if (startVal === "" && endVal !== "") {
            alert("조회 시작일을 선택해주세요");
            return false;
        } else if (startVal > endVal) {
            alert("조회 종료일을 시작일 이전으로 설정할 수 없습니다.\n조회 종료일을 다시 선택해주세요.");
            return false;
        }

        $.ajax({
            type: "POST"
            , url: "/common/wolList.do"
            , data: $("#form_search_woresult1").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }, success: function (data) {
                $("#_VIEW_WO_RESULTS_LIST").html(data);
            }, error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }, complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    $(function () {
        fnSearchTreeWoForm();
    })
</script>
</body>
<c:import url="/footer.do"/>