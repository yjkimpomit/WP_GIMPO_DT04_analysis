<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 설비분류 체계 팝업 화면 --%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup tabs" data-tabs>
    <h1 class="page-content__heading visually-hidden">설비마스터</h1>

    <ul class="nav nav-tabs" id="pills-tab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active" id="pills-home-tab-${treeTabIdx}" data-bs-toggle="pill" data-bs-target="#tree-tab-${treeTabIdx}" type="button" role="tab" aria-controls="tree-tab-${treeTabIdx}" aria-selected="true">기능위치</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-system-tab-${treeTabIdx}" data-bs-toggle="pill" data-bs-target="#system-tab-${treeTabIdx}" type="button" role="tab" aria-controls="system-tab-${treeTabIdx}" aria-selected="false">계통</button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link" id="pills-category-tab-${treeTabIdx}" data-bs-toggle="pill" data-bs-target="#category-tab-${treeTabIdx}" type="button" role="tab" aria-controls="category-tab-${treeTabIdx}" aria-selected="false">종류</button>
        </li>
    </ul>

    <div class="tab-content" id="pills-tabContent">
        <div class="tab-pane fade show active" id="tree-tab-${treeTabIdx}" role="tabpanel" aria-labelledby="pills-home-tab-${treeTabIdx}" tabindex="0">
            <div class="jstree-box" role="tree" tabindex="0" aria-label="기능위치 영역">
                <!-- 기능위치 트리메뉴 -->
                <div id="facTree1-${treeTabIdx}" class="ztree"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="system-tab-${treeTabIdx}" role="tabpanel" aria-labelledby="pills-system-tab-${treeTabIdx}" tabindex="0">
            <div class="jstree-box" role="tree" tabindex="0" aria-label="계통 영역">
                <!-- 개발: 계통 트리메뉴 -->
                <div id="facTree2-${treeTabIdx}" class="ztree"></div>
            </div>
        </div>
        <div class="tab-pane fade" id="category-tab-${treeTabIdx}" role="tabpanel" aria-labelledby="pills-category-tab-${treeTabIdx}" tabindex="0">
            <div class="jstree-box" role="tree" tabindex="0" aria-label="종류 영역">
                <!-- 개발: 종류 트리메뉴 -->
                <div id="facTree3-${treeTabIdx}" class="ztree"></div>
            </div>
        </div>
    </div>
    
</main>

<%-- tree list view --%>
<script>
    var packageTreeTabIdx = "-${treeTabIdx}";
</script>
<script src="${pageContext.request.contextPath}/resources/user/js/tree/facility-package-LST.js"></script>
</body>
<c:import url="/footer.do"/>