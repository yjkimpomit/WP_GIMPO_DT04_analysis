<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 정구인 차장님 사번 --%>
<c:set var="accessUserId" value="16161357"/>

<script>
    var isMobile = (checkDevice !== "pc");
    /*$(document).ready(function () {
        // 모바일인 경우
        if (isMobile) {
            $('[data-class="cctv"]').closest('li').hide();
            $('[data-class="global-search"]').closest('li').hide();
        } else {
            $('[data-class="cctv"]').closest('li').show();
        }
    });*/
</script>
<%--
<button type="button" class="layout-toggle header-icon" onclick="toggleHeader();">
    <span>실시간정보</span>
</button>

<button type="button" id="toggle-button" class="layout-toggle menu-icon" onclick="globalMenu();">
    <span>메뉴열기</span>
</button>--%>

<div class="gnb__head">
    <h1 class="gnb__brand">
        <div class="logo"><img src="${pageContext.request.contextPath}/resources/user/images/logo.svg" alt="" aria-hidden="true"><span class="gnb__brand-text">김포열병합 디지털트윈</span></div>
    </h1>
    <button type="button" id="toggle-button" class="menu-icon" onclick="globalMenu();">
        <span>메뉴열기</span>
    </button>
</div>

<nav id="menuList" class="gnb">
    <ul class="gnb-main depth-1">
        <c:if test="${device ne 'pc'}">
            <li>
                <div class="menu-item">
                    <button type="button" onclick="fnOpenPopup('/dashboard/appMain.do', $(this));" class="menu-link d1" data-class="app-service" data-title="서비스 바로가기"><span class="menu-text">서비스 바로가기</span></button>
                </div>
                <div class="menu-box">
                    <strong>서비스 바로가기</strong>
                </div>
            </li>
        </c:if>

        <c:if test="${device eq 'pc'}">
            <%--<li>
                <div class="menu-item">
                    <button type="button" onclick="fnOpenPopup('/dashboard/index.do', $(this))" class="menu-link d1" data-class="dashboard" data-title="대시보드"><span class="menu-text">대시보드</span></button>
                </div>
                <div class="menu-box">
                    <strong>대시보드</strong>
                </div>
            </li>--%>
        </c:if>
        <li>
            <div class="menu-item">
                <div class="menu-link d1" data-class="data"><span class="menu-text">연계자료</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-data" aria-label="연계자료 하위메뉴 열기"></button>
            </div>
            <div class="menu-box" id="menu-data">
                <strong>연계자료</strong>
                <ul class="depth-2">
                    <li>
                        <button type="button" onclick="fnOpenPopupFacilityMenu('/facility/index.do', $(this))" class="menu-link d2" data-class="facility" data-title="설비정보"><span class="menu-text">설비정보</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/drawing/equipPnidGroup.do', $(this))" class="menu-link d2" data-class="pnid" data-title="P&ID"><span class="menu-text">P&ID</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/drawing/equipDataparcPopup.do', $(this))" class="menu-link d2" data-class="dataparc" data-title="dataPARC"><span class="menu-text">dataPARC</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/panorama/index.do', $(this))" data-class="panorama" class="menu-link d2" data-title="파노라마"><span class="menu-text">파노라마</span></button>
                    </li>
                </ul>
            </div>
        </li>
        <li>
            <div class="menu-item">
                <div class="menu-link d1" data-class="diagnosis"><span class="menu-text">설비진단</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-diagnosis" aria-label="설비진단 하위메뉴 열기"></button>
            </div>
            <div class="menu-box" id="menu-diagnosis">
                <strong>설비진단</strong>
                <ul class="depth-2">
                    <li>
                        <a href="#" target="_blank" class="menu-link d2 external-link" aria-label="두케어 새 창 열기"><span>두케어</span></a>
                    </li>
                    <li>
                        <a href="#" target="_blank" class="menu-link d2 external-link" aria-label="표준복합 새 창 열기"><span>표준복합</span></a>
                    </li>
                    <li>
                        <a href="#" target="_blank" class="menu-link d2 external-link" aria-label="가상시뮬레이션 새 창 열기"><span>가상시뮬레이션</span></a>
                    </li>
                </ul>
            </div>
        </li>
        
        <li>
            <div class="menu-item">
                <div class="menu-link d1" data-class="safety"><span class="menu-text">안전관리</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-safety" aria-label="안전관리 하위메뉴 열기"></button>
            </div>
            <div class="menu-box" id="menu-safety">
                <strong>안전관리</strong>
                <ul class="depth-2">
                    <li>
                        <button type="button" onclick="fnOpenPopup('/dailySafety/index.do?tabIdx=0', $(this))" class="menu-link d2" data-title="일일안전현황"><span>일일안전현황</span></button>
                        <ul class="depth-3">
                            <li>
                                <button type="button" onclick="fnOpenPopup('/dailySafety/index.do?tabIdx=0', $(this))" class="menu-link d3" data-title="일일안전현황"><span>일일안전작업현황</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/dailySafety/index.do?tabIdx=1', $(this))" class="menu-link d3" data-title="일일안전현황"><span>경상오더</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/dailySafety/index.do?tabIdx=2', $(this))" class="menu-link d3" data-title="일일안전현황"><span>공사오더</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/dailySafety/index.do?tabIdx=3', $(this))" class="menu-link d3" data-title="일일안전현황"><span>공사오더(OH)</span></button>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('', $(this))" class="menu-link d2" data-title="위치-건강 모니터링"><span>위치/건강 모니터링</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/cctv/index.do', $(this))" class="menu-link d2" data-title="AI-CCTV"><span>AI-CCTV</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('', $(this))" class="menu-link d2" data-title="피지컬-AI"><span>피지컬 AI</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('', $(this))" class="menu-link d2" data-title="AI-모바일"><span>AI 모바일</span></button>
                    </li>
                </ul>
            </div>
        </li>
        <li>
            <div class="menu-item">
                <div class="menu-link d1" data-class="geni"><span class="menu-text">GENi</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-geni" aria-label="GENi 하위메뉴 열기"></button>
            </div>
            <div class="menu-box" id="menu-geni">
                <strong>GENi</strong>
                <ul class="depth-2">
                    <li>
                        <button type="button" onclick="fnOpenPopup('/tmStatus/index.do?tabIdx=0', $(this))" class="menu-link d2" data-title="TM현황"><span>TM현황</span></button>
                        <ul class="depth-3">
                            <li>
                                <button type="button" onclick="fnOpenPopup('/tmStatus/index.do?tabIdx=0', $(this))" class="menu-link d3" data-title="TM현황"><span>작업요청 확정</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/tmStatus/index.do?tabIdx=1', $(this))" class="menu-link d3" data-title="TM현황"><span>다발 TM현황</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/tmStatus/index.do?tabIdx=2', $(this))" class="menu-link d3" data-title="TM현황"><span>미결 TM현황</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/tmStatus/index.do?tabIdx=3', $(this))" class="menu-link d3" data-title="TM현황"><span>작업요청 건수</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/tmStatus/index.do?tabIdx=4', $(this))" class="menu-link d3" data-title="TM현황"><span>작업요청 처리현황</span></button>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/redTag/index.do?tabIdx=0', $(this))" class="menu-link d2" data-title="작업현황"><span>작업현황<sub>Red TAG</sub></span></button>
                        <ul class="depth-3">
                            <li>
                                <button type="button" onclick="fnOpenPopup('/redTag/index.do?tabIdx=0', $(this))" class="menu-link d3" data-title="작업현황"><span>Red Tag 발행</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/redTag/index.do?tabIdx=1', $(this))" class="menu-link d3" data-title="작업현황"><span>Red Tag 관리대장</span></button>
                            </li>
                        </ul>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=0', $(this))" class="menu-link d2" data-title="예방점검현황"><span>예방점검현황</span></button>
                        <ul class="depth-3">
                            <li>
                                <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=0', $(this))" class="menu-link d3" data-title="예방점검현황"><span>정비비용 고장경향 분석</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=1', $(this))" class="menu-link d3" data-title="예방점검현황"><span>점검 보고서</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=2', $(this))" class="menu-link d3" data-title="예방점검현황"><span>점검 결과</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=3', $(this))" class="menu-link d3" data-title="예방점검현황"><span>점검 결과(chart)</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=4', $(this))" class="menu-link d3" data-title="예방점검현황"><span>이상 점검 결과</span></button>
                            </li>
                            <li>
                                <button type="button" onclick="fnOpenPopup('/prevention/index.do?tabIdx=5', $(this))" class="menu-link d3" data-title="예방점검현황"><span>미점검 일정</span></button>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
        </li>
        <li>
            <div class="menu-item">
                <button type="button" onclick="fnOpenPopup('', $(this))" class="menu-link d1" data-class="ar-site" data-title="AR 현장점검"><span class="menu-text">AR 현장점검</span></button>
            </div>
            <div class="menu-box">
                <strong>AR 현장점검</strong>
            </div>
        </li>
        <%--<li>
            &lt;%&ndash;<div class="menu-item">
                <button type="button" onclick="fnOpenPopup('/earlywarning/index.do', $(this))" class="menu-link d1" data-class="alarm" data-title="조기경보"><span class="menu-text">조기경보</span></button>
            </div>
            <div class="menu-box">
                <strong>조기경보</strong>
            </div>&ndash;%&gt;

            <div class="menu-item">
                <div class="menu-link d1" data-class="alarm"><span class="menu-text">조기경보</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="early-warning" aria-label="조기경보 하위메뉴 열기"></button>
            </div>
            <div class="menu-box active" id="early-warning">
                <strong>조기경보</strong>
                <ul class="depth-2">
                    <li>
                        <button type="button" onclick="fnOpenPopup('/earlywarning/index.do', $(this))" class="menu-link d2" data-class="alarm" data-title="조기경보"><span>조기경보</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/earlywarning/alarmHistory.do', $(this))" class="menu-link d2" data-class="alarm" data-title="조기경보 이력"><span>조기경보 이력</span></button>
                    </li>
                </ul>
            </div>
        </li>
        <li class="pc-only">
            <button type="button" onclick="fnLogsheetOepn()" class="menu-link d2" data-class="qrcode" data-title="로그시트"><span class="menu-text">로그시트</span></button>
        </li>
        <%--<li class="pc-only">
            <button type="button" onclick="fnOpenPopup('/logsheet/logsheetCheck.do?data=WtBHsKsCN7', $(this))" class="menu-link d2" data-class="qrcode" data-title="로그시트"><span class="menu-text">로그시트 테스트</span></button>
        </li>--%>
        <%--<li>
            <div class="menu-item">
                <button type="button" onclick="fnOpenPopup('/cctv/index.do', $(this))" class="menu-link d1" data-class="cctv" data-title="CCTV"><span class="menu-text">CCTV</span></button>
            </div>
            <div class="menu-box">
                <strong>CCTV</strong>
            </div>
        </li>
        <li>
            <div class="menu-item">
                <div class="menu-link d1" data-class="drawing"><span class="menu-text">설비검색</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-drawing" aria-label="설비검색 하위메뉴 열기"></button>
            </div>
            <div class="menu-box" id="menu-drawing">
                <strong>설비검색</strong>
                <ul class="depth-2">
                    <li>
                        <button type="button" onclick="fnOpenPopup('/drawing/index.do?tabIdx=0', $(this))" class="menu-link d2" data-title="설비검색"><span>제어로직</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/drawing/index.do?tabIdx=1', $(this))" class="menu-link d2" data-title="설비검색"><span>3D</span></button>
                    </li>
                    &lt;%&ndash;<li>
                        <button type="button" class="menu-link d2" data-title="설비검색"><span>Tag List</span></button>
                    </li>&ndash;%&gt;
                    &lt;%&ndash;<li>
                        <button type="button" onclick="fnOpenPopup('/drawing/index.do?tabIdx=2', $(this))" class="menu-link d2" data-title="설비검색"><span>Tag List</span></button>
                    </li>&ndash;%&gt;
                    <li>
                        <button type="button" onclick="fnOpenPopup('/drawing/index.do?tabIdx=2', $(this))" class="menu-link d2" data-title="설비검색"><span>P&ID</span></button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/drawing/index.do?tabIdx=3', $(this))" class="menu-link d2" data-title="설비검색"><span>DataPARC</span></button>
                    </li>
                </ul>
            </div>
        </li>--%>
        <%--<li class="mobile-only">
            <div class="menu-item">
                <button type="button" onclick="fnLogsheetOepn()" class="menu-link d1" data-class="qrcode" data-title="로그시트"><span class="menu-text">로그시트</span></button>
            </div>
            <div class="menu-box">
                <strong>로그시트</strong>
            </div>
        </li>--%>
        <%--<li>
            <div class="menu-item">
                <div class="menu-link d1" data-class="service">
                    <span class="menu-text">개선요청</span>
                    &lt;%&ndash;  새로운 글이 있는 경우에만 표시 start &ndash;%&gt;
                    <c:if test="${count > 0}"><span class="icon-new">N</span></c:if>
                    &lt;%&ndash;  새로운 글이 있는 경우에만 표시 end &ndash;%&gt;
                </div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-service" aria-label="개선요청 하위메뉴 열기"></button>
            </div>
            <div class="menu-box" id="menu-service">
                <strong>개선요청</strong>
                <ul class="depth-2">
                    <li>
                        <button type="button" onclick="fnOpenPopup('/serviceinfo/index.do?tabIdx=0', $(this))" class="menu-link d2" data-title="개선요청">
                            <span>개선요청</span>
                            &lt;%&ndash;  새로운 글이 있는 경우에만 표시 start &ndash;%&gt;
                            <c:if test="${impCount > 0}"><span class="icon-count">${impCount}</span></c:if>
                            &lt;%&ndash;  새로운 글이 있는 경우에만 표시 end &ndash;%&gt;
                        </button>
                    </li>
                    <li>
                        <button type="button" onclick="fnOpenPopup('/serviceinfo/index.do?tabIdx=1', $(this))" class="menu-link d2" data-title="개선요청">
                            <span>공지사항</span>
                            &lt;%&ndash;  새로운 글이 있는 경우에만 표시 start &ndash;%&gt;
                            <c:if test="${noticeCount > 0}"><span class="icon-count">${noticeCount}</span></c:if>
                            &lt;%&ndash;  새로운 글이 있는 경우에만 표시 end &ndash;%&gt;
                        </button>
                    </li>

                    <c:if test="${sessionScope.loginInfo.iui_user_id eq accessUserId}">
                        <li>
                            <button type="button" onclick="fnOpenPopup('/serviceinfo/index.do?tabIdx=2', $(this))" class="menu-link d2" data-title="개선요청">
                                <span>서비스 설정</span>
                            </button>
                        </li>
                    </c:if>
                </ul>
            </div>
        </li>--%>
        <%--<li>
            <div class="menu-item">
                &lt;%&ndash;<div type="button" onclick="fnOpenPopup('', $(this))" class="menu-link d1" data-class="outbound" data-title="WA"><span class="menu-text">WA</span></div>&ndash;%&gt;
                <button type="button" onclick="alert('준비중입니다.')" class="menu-link d1" data-class="outbound" data-title="WA"><span class="menu-text">WA</span></button>
            </div>
            <div class="menu-box">
                <strong>WA</strong>
            </div>
        </li>--%>
        <%--<li class="pc-only">
            <div class="menu-item">
                <button type="button" onclick="fnViewAdminPage()" class="menu-link d1" data-class="site-manager" data-title="관리자"><span class="menu-text">관리자</span></button>
            </div>
            <div class="menu-box">
                <strong>관리자</strong>
            </div>
        </li>--%>
    </ul>

    <%--<c:if test="${eqOrgNo eq '5100'}">
        <ul class="gnb-operation depth-1">
            <li class="operation-control" onclick="fnOpDataBoxToggle('#_OPERATION_GT_');" style="display: none;">
                <div class="menu-item">
                    <button type="button" class="menu-link d1" data-class="operation-info"><span class="menu-text">운전정보 GT</span></button>
                </div>
                <div class="menu-box">
                    <strong>운전정보 GT</strong>
                </div>
            </li>
            <li class="operation-control" onclick="fnOpDataBoxToggle('#_OPERATION_TBBD9_3F_');" style="display: none;">
                <div class="menu-item">
                    <button type="button" class="menu-link d1" data-class="operation-info"><span class="menu-text">운전정보 TBBD9_3F</span></button>
                </div>
                <div class="menu-box">
                    <strong>운전정보 TBBD9_3F</strong>
                </div>
            </li>
            <li class="operation-control" onclick="fnOpDataBoxToggle('#_OPERATION_HRSG_');" style="display: none;">
                <div class="menu-item">
                    <button type="button" class="menu-link d1" data-class="operation-info"><span class="menu-text">운전정보 HRSG</span></button>
                </div>
                <div class="menu-box">
                    <strong>운전정보 HRSG</strong>
                </div>
            </li>
        </ul>
    </c:if>--%>

    <%--<ul class="gnb-tabs depth-1">
        <li class="tabs-control">
            <div class="menu-item">
                <button type="button" onclick="fnWinPopAllClose()" class="menu-link d1" data-class="close-tabs"><span class="menu-text">모든 탭 닫기</span></button>
            </div>
            <div class="menu-box">
                <strong>모든 탭 닫기</strong>
            </div>
        </li>
        <li class="tabs-control">
            <div class="menu-item">
                <button type="button" onclick="fnWinPopMinimize()" class="menu-link d1" data-class="minimize-tabs"><span class="menu-text">모든 탭 최소</span></button>
            </div>
            <div class="menu-box">
                <strong>모든 탭 최소</strong>
            </div>
        </li>
    </ul>--%>

    <%--<ul class="gnb-counter depth-1">
        <li class="nav-counter">
            <div class="menu-item">
                <div class="menu-link d1" data-class="visitors"><span class="visually-hidden">방문자정보</span></div>
                <button type="button" class="open-icon" aria-expanded="false" aria-controls="menu-visitors" aria-label="방문자정보 하위메뉴 열기"></button>
            </div>
            <div class="menu-box has-counter-box" id="menu-visitors">
                <div class="counter-title">
                    <strong>방문자 정보</strong>
                    <c:if test="${sessionScope.loginInfo.iui_user_id eq accessUserId}">
                        <button type="button" class="btn-sm btn-log" onclick="fnWinOpenLogVisit($(this))" data-title="방문자 조회">조회</button>
                    </c:if>
                </div>
                <div class="counter-box">
                    <div class="cb-total">
                        <strong>전체 방문자수</strong>
                        <span><fmt:formatNumber value="${visitTotalCount}" type="number"/>명</span>
                    </div>
                    <div class="cb-today">
                        <strong>오늘 방문자수</strong>
                        <span><fmt:formatNumber value="${visitTodayCount}" type="number"/>명</span>
                    </div>
                </div>
            </div>
        </li>

        &lt;%&ndash;<li>
            <button type="button" onclick="fnOpenPopup('/apc/index.do', $(this))" class="menu-link d1" data-class="apc" data-title="APC"><span>APC</span></button>
        </li>&ndash;%&gt;
    </ul>--%>
</nav>
