<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script>
    function wolCodeDetail(no, desc) {
        window.parent.$('#woNoOption').val(no);
        window.parent.$('#woNoInput').val(desc);

        window.parent.$(".winbox.app-winbox.app-winbox--detail.focus").find(".wb-close").trigger("click");
    }

    var totalPage = ${paginationInfo.totalPageCount};

    <%-- 검색 결과 리스트 페이징 처리 --%>

    function fnWoPageMove(f) {
        var currentPage = parseInt($("#detailWoCurrentPage").val());

        if (f === 'P') {
            if (currentPage == 1) {
                alert("처음 페이지입니다.");
                return false;
            }
            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage == totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }
            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#detailWoCurrentPage").val(totalPage);
                return false;
            }
        }

        $("#detailWoCurrentPage").val(currentPage);

        $.ajax({
            type: "get"
            , url: "/common/wolList.do?pageIndex=" + currentPage
            , data: $("#form_search_woresult1").serialize()
            , dataType: "html"
            , success: function (data) {
                $("#_VIEW_WO_RESULTS_LIST").html(data);
            }
            , error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
        });
    }
</script>

<%-- 페이징 --%>
<div class="title-box">
    <h5 class="title05">조회결과 <small>(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h5>

    <div>
        <div class="page-move">
            <label for="detailWoCurrentPage" class="visually-hidden">이동할 페이지</label>
            <input type="number" id="detailWoCurrentPage" class="form-control page" value="<c:out value='${paginationInfo.currentPageNo}'/>">
            <span class="px-1">/</span>
            <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="btn btn-secondary" onclick="fnWoPageMove('M')">이동</button>
        </div>
        
        <div class="buttons">
            <button type="button" class="btn btn-outline-primary" onclick="fnWoPageMove('P')">이전</button>
            <button type="button" class="btn btn-outline-primary" onclick="fnWoPageMove('N')">다음</button>
        </div>
    </div>
</div>
<div class="table-responsive">
    <table class="data-table data-table--list data-table--interactive" aria-label="오더종류-데이터">
        <thead>
        <tr>
            <th scope="col" data-field="오더종류">오더종류</th>
            <th scope="col" data-field="작업오더">작업오더</th>
            <th scope="col" data-field="상태">상태</th>
            <th scope="col" data-field="작업명">작업명</th>
            <th scope="col" data-field="감독부서">감독부서</th>
            <th scope="col" data-field="감독자">감독자</th>
            <th scope="col" data-field="작업종료일">작업종료일</th>
        </tr>
        </thead>
        <tbody>
        <%-- 데이터가 없을 경우 --%>
        <c:if test="${fn:length(list) == 0}">
            <tr>
                <th colspan="7">
                    <div class="no-data">
                        조회된 데이터가 없습니다.
                    </div>
                </th>
            </tr>
        </c:if>
        <c:forEach var="data" items="${list}" varStatus="status">
            <tr onclick="wolCodeDetail('${data.woNo}','${data.woDesc}')">
                <td data-field="오더종류">${data.woCategoryNm}</td>
                <td data-field="작업오더">${data.woNo}</td>
                <td data-field="상태">${data.woStatus}</td>
                <td data-field="작업명">${data.woDesc}</td>
                <td data-field="감독부서">${data.deptNm}</td>
                <td data-field="감독자">${data.planByNm}</td>
                <td data-field="작업종료일">
                    <c:choose>
                        <c:when test="${fn:length(data.requestDate) == 0}">
                            ${data.requestDate}
                        </c:when>
                        <c:when test="${fn:length(data.requestDate) != 0}">
                            <c:out value='${fn:substring(data.requestDate, 0, 4)}-'/><c:out value='${fn:substring(data.requestDate, 4, 6)}-'/><c:out value='${fn:substring(data.requestDate, 6, 8)}'/>
                        </c:when>
                    </c:choose>
                </td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>