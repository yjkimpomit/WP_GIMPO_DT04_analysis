<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<!-- 메뉴 클릭시 열리는 팝업 : bPopup -->--%>
<div class="modal fade external-popup" id="externalPopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content" id="popupContentView">

            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle"></h2>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="modalBodyContent">
                <%--<!-- 모달 페이지 로드 -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 메뉴 클릭시 열리는 팝업 : bPopup -->--%>
<div class="modal fade external-popup" id="externalPopup2" tabindex="-1">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content" id="popupContentView2">

            <div class="modal-header">
                <h2 class="modal-title" id="modalTitle2"></h2>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="modalBodyContent2">
                <%--<!-- 모달 페이지 로드 -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 감독부서 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchReqTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">감독부서 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="reqTree1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 요청부서 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchReqDeptTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">요청부서 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="reqDeptTree1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 운전부서 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchopDeptTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">운전부서 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="opDeptTree1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 정비부서 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchmainDeptTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04" id="searchmainDeptTreeTitle"></h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="searchmainDeptTreeContent">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="mainDeptTree1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 설계부서 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchdesignDeptTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04" id="searchdesignDeptTreeTitle"></h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="searchdesignDeptTreeContent">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="designDeptTree1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 설비종류 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchFacilityTypeTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">설비종류 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="facilityType1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 설비기능위치번호 검색시 열리는 팝업 : 트리박스만 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type1" id="searchFacilityLocTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">기능위치번호 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body">
                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                <div class="jstree-box">
                    <div id="facilityLoc1" class="ztree"></div>
                </div>
                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
            </div>
        </div>
    </div>
</div>

<%--<!-- 검색박스내 사용자/점검자/감독자 검색시 열리는 팝업 : 트리박스 + 테이블 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type2" id="searchItemPopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <%--<!-- 요청자,감독자,점검자 공통 값 저장 -->--%>
                <input id="chkTitleTree" type="hidden" value="">
                <h5 class="title04" id="searchItemTitle"></h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="searchItemContent">

                <div class="panel-box">
                    <div class="side-panel left">
                        <div class="d-flex justify-content-between d-xl-block">
                            <p class="info-message">부서를 선택해주세요.</p>
                            <div>
                                <input class="form-check-input" type="checkbox" value="" id="id_code1">
                                <label class="form-check-label" for="id_code1">전출자 포함</label>
                            </div>
                        </div>

                        <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                        <div class="jstree-box">
                            <div id="divisionTree2" class="ztree"></div>
                        </div>
                        <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
                    </div>
                    <div class="contents-panel">
                        <div class="table-responsive" id="userDetailList">
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<%--<!-- 설비검색 팝업 : 팝업내 검색박스 + 트리박스 + 테이블 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type3" id="searchFacilityPopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04" id="searchFacilityTitle">설비검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="searchFacilityContent">
                <%--<!-- 검색영역 -->--%>
                <div class="search-box" aria-label="설비마스터-검색">
                    <form id="form_search_result1" method="post" autocomplete="off">
                        <div class="row">
                            <div class="col-md-12 col-lg-4 col-xxl-6 ">
                                <span class="form-label" id="equipType">설비종류</span>
                                <div class="row g-2" aria-labelledby="equipType">
                                    <div class="col">
                                        <label class="visually-hidden" for="equipTypeOption">설비종류 검색</label>
                                        <input class="form-control form-control--search" id="equipTypeOption" name="eqType" placeholder="설비종류" onclick="searchFacilityTypeTreePopup($(this));">
                                    </div>
                                    <div class="col">
                                        <label class="visually-hidden" for="equipTypeInput">설비종류</label>
                                        <input class="form-control" type="text" value="" id="equipTypeInput" disabled="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 col-lg-8 col-xxl-6 ">
                                <span class="form-label" id="equipNameOptions">설비명</span>
                                <div class="row g-2" aria-labelledby="equipNameOptions">
                                    <div class="col-12 col-md">
                                        <label class="visually-hidden" for="equipNameOption">설비명 선택1</label>
                                        <input class="form-control" id="equipNameOption" name="searchKeywordTo">
                                    </div>
                                    <div class="col-auto">
                                        <div class="form-check form-check-inline text-center px-1">
                                            <input class="form-check-input" type="radio" value="0" id="rbAnd" name="searchCondition">
                                            <label class="form-check-label" for="rbAnd">AND</label>
                                        </div>
                                    </div>
                                    <div class="col-auto">
                                        <div class="form-check form-check-inline text-center px-1">
                                            <input class="form-check-input" type="radio" value="1" name="searchCondition" id="rbOr" checked>
                                            <label class="form-check-label" for="rbOr">OR</label>
                                        </div>
                                    </div>
                                    <div class="col-12 col-md">
                                        <label class="visually-hidden" for="equipNameOption2">설비명 선택2</label>
                                        <input class="form-control" id="equipNameOption2" name="searchKeywordFrom">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-12 col-lg-4 col-xxl-6 mb-3">
                                <span class="form-label" id="fnLocation">기능위치번호</span>
                                <div class="row g-2" aria-labelledby="fncLocation">
                                    <div class="col">
                                        <label class="visually-hidden" for="fnLocationOption">기능위치번호 검색</label>
                                        <input class="form-control form-control--search" id="fnLocationOption" name="locNo" onclick="searchFacilityLocTreePopup($(this));">
                                    </div>
                                    <div class="col">
                                        <label class="visually-hidden" for="fnLocationInput">기능위치번호</label>
                                        <input class="form-control" type="text" value="" id="fnLocationInput" disabled="">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md col-lg col-xxl mb-3">
                                <label class="form-label" for="facType">설비구분</label>
                                <select class="form-select" id="facType">
                                    <option value="----------------------------------">----------------------------------</option>
                                </select>
                            </div>

                            <div class="col-md col-lg col-xxl mb-3">
                                <label class="form-label" for="tagNo">TagNo</label>
                                <input class="form-control" id="tagNo" type="text" name="tagNo">
                            </div>

                            <div class="col col-md-auto mb-3">
                                <button type="button" class="btn btn-primary" onclick="fnFacilityDetailSearch()">
                                    <span class="icon icon-search"></span>
                                    <span>검색</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <%-- 맨 아래 3개의 js 사용 --%>
                <div class="panel-box">
                    <div class="side-panel left">
                        <ul class="nav nav-pills nav-sm nav-justified" id="pills-tab2" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="nav-link active" id="pills-home-tab2" data-bs-toggle="pill" data-bs-target="#tree-tab2" type="button" role="tab" aria-controls="tree-tab2" aria-selected="true">기능위치</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-system-tab2" data-bs-toggle="pill" data-bs-target="#system-tab2" type="button" role="tab" aria-controls="system-tab2" aria-selected="false">계통</button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button class="nav-link" id="pills-category-tab2" data-bs-toggle="pill" data-bs-target="#category-tab2" type="button" role="tab" aria-controls="category-tab2" aria-selected="false">종류</button>
                            </li>
                        </ul>

                        <div class="tab-content" id="pills-tabContent2">
                            <div class="tab-pane fade show active" id="tree-tab2" role="tabpanel" aria-labelledby="pills-home-tab2" tabindex="0">
                                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                                <div class="jstree-box">
                                    <div id="facilityMaster1" class="ztree"></div>
                                </div>
                                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
                            </div>
                            <div class="tab-pane fade" id="system-tab2" role="tabpanel" aria-labelledby="pills-system-tab2" tabindex="0">
                                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                                <div class="jstree-box">
                                    <div id="facilityMaster2" class="ztree"></div>
                                </div>
                                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
                            </div>
                            <div class="tab-pane fade" id="category-tab2" role="tabpanel" aria-labelledby="pills-category-tab2" tabindex="0">
                                <%--<!-- 트리메뉴 데이터 들어가는 영역 START -->--%>
                                <div class="jstree-box">
                                    <div id="facilityMaster3" class="ztree"></div>
                                </div>
                                <%--<!-- 트리메뉴 데이터 들어가는 영역 END -->--%>
                            </div>
                        </div>
                    </div>
                    <div class="contents-panel" id="facilityMasterList">
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<%--<!-- 점검종류 팝업 -->--%>
<div class="modal fade search-popup type4" id="searchResultPopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04" id="searchResultTitle">점검종류 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="searchResultContent">
                <%--<!-- 검색결과 리스트 -->--%>
                <div class="search-box" aria-label="점검종류-검색">
                    <form id="form_search_result2" method="post" autocomplete="off">
                        <div class="row">
                            <div class="col-md-4">
                                <label class="form-label" for="inspectorTypeCode">CODE</label>
                                <input class="form-control" id="inspectorTypeCode" name="code">
                            </div>
                            <div class="col-md">
                                <label class="form-label" for="inspectorTypeDesc">DESCRIPTION</label>
                                <input class="form-control" id="inspectorTypeDesc" name="description">
                            </div>

                            <div class="col-md-auto">
                                <button type="button" class="btn btn-primary" onclick="fnCodeSearch()">
                                    <span class="icon icon-search"></span>
                                    <span>검색</span>
                                </button>
                            </div>
                        </div>
                    </form>
                </div>

                <div class="table-responsive" id="codeDetailList">

                </div>
            </div>
        </div>
    </div>
</div>

<%--<!-- W/O 검색 팝업 : 팝업내 검색박스 + 테이블 나오는 팝업 bPopup -->--%>
<div class="modal fade search-popup type5" id="searchWoTreePopup" tabindex="-1">
    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-sm-down modal-xl">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">W/O 검색</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body" id="woSearchListForm">

            </div>
        </div>
    </div>
</div>

<%--<!-- VLC 설치팝업 -->--%>
<div class="modal fade detail-box" tabindex="-1" id="cctvInstall">
    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">
                    설치파일 안내
                </h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body">
                <h4 class="my-2">VLC가 설치되어 있지 않습니다.</h4>
                <p>설치 파일을 다운로드 받아 설치한 뒤에 CCTV를 확인할 수 있습니다.</p>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-primary" onclick="downloadCctvView()">
                    <span class="icon icon-download"></span>
                    <span>설치파일 다운로드</span>
                </button>
            </div>
        </div>
    </div>
</div>

<%--<!-- CCTV 이미지 대체 영역 -->--%>
<div class="modal fade detail-box" tabindex="-1" id="cctvImg">
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header visually-hidden">
                <h5 class="title04">
                   CCTV
                </h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body p-0">
                <div class="cctv-mockup">
                    <div class="cm-header">
                        <div class="cctv-close close"></div>
                    </div>
                    <div class="cm-body">
                        <img src="${pageContext.request.contextPath}/resources/user/images/sample/cctv-img.png" alt="CCTV" class="img-fluid" />
                    </div>
                    <div class="cm-footer"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<%--<!-- 감독부서 및 요청부서 팝업 트리 정보 -->--%>
<script src="${pageContext.request.contextPath}/resources/user/js/tree/search-division-dept.js"></script>

<%--<!-- 기능위치번호 및 설비종류 팝업 트리 정보 -->--%>
<script src="${pageContext.request.contextPath}/resources/user/js/tree/search-facility-location.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/tree/search-facility-system.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/tree/search-facility-type.js"></script>
