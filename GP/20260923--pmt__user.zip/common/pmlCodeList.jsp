<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script>
    function codeDetail(code, desc) {
        window.parent.$('#inspectorTypeOption').val(code);
        window.parent.$('#inspectorTypeInput').val(desc);

        window.parent.$(".winbox.app-winbox.app-winbox--detail.focus").find(".wb-close").trigger("click");
    }
</script>

<!-- 예방점검현황 - 점검코드 리스트 -->
<table class="data-table data-table--list data-table--interactive" aria-label="점검종류-결과">
    <thead>
    <tr>
        <th scope="col" data-field="CODE">CODE</th>
        <th scope="col" data-field="DESC">DESCRIPTION</th>
    </tr>
    </thead>
    <tbody>
    <%-- 데이터가 없을 경우 --%>
    <c:if test="${fn:length(list) == 0}">
        <tr>
            <th colspan="2">
                <div class="no-data">
                    조회된 데이터가 없습니다.
                </div>
            </th>
        </tr>
    </c:if>
    <c:forEach var="data" items="${list}" varStatus="status">
        <tr onclick="codeDetail('${data.code}','${data.description}')">
            <th data-field="CODE" scope="row">${data.code}</th>
            <td data-field="DESC">${data.description}</td>
        </tr>
    </c:forEach>
    </tbody>
</table>
