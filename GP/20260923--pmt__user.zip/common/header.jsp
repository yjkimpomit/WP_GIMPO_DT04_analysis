<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#1A1E26">
    <title>서부발전 김포열병합 DT</title>

    <meta name="description" content="서부발전 김포열병합 DT 서비스 제공">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <%-- <!-- favicon --> --%>
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.ico" sizes="any">
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.svg" type="image/svg+xml">

    <%-- <!-- toastchart --> --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/toastchart/toastui-chart.min.css">

    <%-- alert --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/jquery/confirm/jquery-confirm.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/jquery/confirm/jquery-confirm.override.css">

    <%--
        * js에 사용할 변수 선언
        * 모바일 체크
        * 사업소, 호기 정보
        * IDMS 페이지 <---> 3D MODEL
    --%>
    <script>
        // check device
        var checkDevice = "${device}";
        var eqOrgNo = "${sessionScope.eqOrgNo}";
        var hoki = "${sessionScope.hoki}";
        var _isIdmsPage = false;
    </script>

    <%-- <!-- js --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery-3.6.1.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/common.js?t=${System.currentTimeMillis()}"></script>

    <%-- <!-- toastchart --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/toastchart/toastui-chart.min.js"></script>

    <%-- <!-- chartjs --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/chart/chart.umd.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/chart/chartjs-adapter-date-fns.bundle.min.js"></script>

    <%-- ztree --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/ztree/css/metroStyle/metroStyle.css" type="text/css">
    <script src="${pageContext.request.contextPath}/resources/user/js/ztree/js/jquery.ztree.all.min.js"></script>

    <%-- <!-- 부트스트랩 JS --> --%>
    <%--<script src="${pageContext.request.contextPath}/resources/user/js/bootstrap/popper.min.js"></script>--%>
    <script src="${pageContext.request.contextPath}/resources/user/js/bootstrap/bootstrap.bundle.min.js"></script>

    <%-- daterangepicker --%>
    <link rel="stylesheet" type="text/css" media="all" href="${pageContext.request.contextPath}/resources/user/js/daterangepicker/daterangepicker.css"/>
    <script src="${pageContext.request.contextPath}/resources/user/js/daterangepicker/moment/moment-with-locales.min.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/daterangepicker/daterangepicker.js"></script>

    <%-- <!-- bPopup --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery.bpopup.min.js"></script>

    <%-- winbox js --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/winbox/winbox.min.css">
    <script src="${pageContext.request.contextPath}/resources/user/js/winbox/winbox.min.js"></script>

    <%-- alert --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/confirm/jquery-confirm.min.js"></script>

    <%-- <!-- WP stylesheet --> --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/css/winbox-content.css?t=${System.currentTimeMillis()}">
    <script src="${pageContext.request.contextPath}/resources/user/js/common/components.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/common/data-table-detail.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/common/tree-explorer.js"></script>
    
    <script src="${pageContext.request.contextPath}/resources/user/js/temp-clear-date-inputs.js"></script>
</head>
