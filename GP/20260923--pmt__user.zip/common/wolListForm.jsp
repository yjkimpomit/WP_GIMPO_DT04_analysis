<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script>
    setDateS();
    //W/O 상세 검색
    fnWoDetailSearch();
</script>

<div class="search-box" aria-label="WO-검색">
    <form id="form_search_woresult1" method="post" autocomplete="off">
        <div class="row">
            <div class="col-lg-6 col-xl-4">
                <label class="form-label" for="orderType">오더종류</label>
                <select class="form-select" id="orderType" name="woCategory">
                    <option value="">----------------------------------</option>
                    <option value="CURRENT">경상오더</option>
                    <option value="PROJECT">공사오더</option>
                </select>
            </div>
            <div class="col-lg-6 col-xl-4">
                <span class="form-label" id="supervisor">감독자</span>
                <div class="row g-2" aria-labelledby="supervisor">
                    <div class="col">
                        <label class="visually-hidden" for="supvorOption">감독자 검색</label>
                        <input class="form-control form-control--search" id="supvorOption" name="planBy" onclick="searchItemPopup($(this));">
                    </div>
                    <div class="col">
                        <label class="visually-hidden" for="supvorInput">감독자</label>
                        <input class="form-control" type="text" value="" id="supvorInput" disabled="">
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-xl-4">
                <span class="form-label" id="supvDept">감독부서</span>
                <div class="row g-2" aria-labelledby="supvDept">
                    <div class="col">
                        <label class="visually-hidden" for="supvDeptOption">감독부서 검색</label>
                        <input class="form-control form-control--search" id="supvDeptOption" name="deptNo" onclick="searchReqTreePopup($(this));">
                    </div>
                    <div class="col">
                        <label class="visually-hidden" for="supvDeptInput">감독부서명</label>
                        <input class="form-control" type="text" value="" id="supvDeptInput" disabled="">
                    </div>
                </div>
            </div>

            <div class="col-lg-6 col-xl-4">
                <label class="form-label" for="workOrderName">작업오더명</label>
                <input class="form-control" type="text" id="workOrderName" value="" name="woDesc" placeholder="오더명 입력">
            </div>

            <div class="col-lg-6 col-xl-4">
                <span class="form-label" id="designDatePeriod">설계일</span>
                <div class="row g-2 period-box" aria-labelledby="designDatePeriod">
                    <div class="col">
                        <label class="visually-hidden" for="designDateStart">시작일</label>
                        <input type="date" class="form-control" id="designDateStart" name="searchPeriodStart">
                    </div>
                    <div class="col-auto">
                        <span class="form-control-plaintext text-center">~</span>
                    </div>
                    <div class="col">
                        <label class="visually-hidden" for="designDateEnd">종료일</label>
                        <input type="date" class="form-control" id="designDateEnd" name="searchPeriodEnd">
                    </div>
                </div>
            </div>

            <div class="col-lg col-xl">
                <label class="form-label" for="state">상태</label>
                <select class="form-select" id="state" name="woStatus">
                    <option value="">--------------------------</option>
                    <option value="설계중">설계중</option>
                    <option value="감독부서승인중">감독부서승인중</option>
                    <option value="작업허가승인중">작업허가승인중</option>
                    <option value="작업중">작업중</option>
                    <option value="작업완결승인중">작업완결승인중</option>
                    <option value="운전부서완료확인중">운전부서완료확인중</option>
                    <option value="작업종결승인중">작업종결승인중</option>
                    <option value="작업종결">작업종결</option>
                    <option value="정산완료">정산완료</option>
                    <option value="작업취소">작업취소</option>
                </select>
            </div>

            <div class="col col-lg-auto">
                <button type="button" class="btn btn-primary" onclick="fnWoDetailSearch()">
                    <span class="icon icon-search"></span>
                    <span>검색</span>
                </button>
            </div>
        </div>
    </form>
</div>

<%-- data-grid : 결과 리스트 뷰 --%>
<div id="_VIEW_WO_RESULTS_LIST">
</div>