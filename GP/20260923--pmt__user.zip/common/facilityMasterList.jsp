<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<script>
    var totalPage = ${paginationInfo.totalPageCount};

    function equipCodeDetail(no, desc) {
        window.parent.$('#equipNoOption').val(no);
        window.parent.$('#equipNoInput').val(desc);

        //검색 form 초기화
        if ($('#form_search_result1').length) { $('#form_search_result1')[0].reset(); }
        $("#facilityMasterList").html('');
        fnInitLocation();

        //tab 초기화
        $('#pills-tab2 li button').removeClass('active');
        $('#pills-tab2 li button').first().addClass('active');
        $('#pills-tabContent2 div').removeClass('active');
        $('#pills-tabContent2 div').first().addClass('active show');

        window.parent.$(".winbox.app-winbox.app-winbox--detail.focus").find(".wb-close").trigger("click");
    }
</script>

<%-- 페이징 --%>
<div class="result-header">
    <h2 class="result-header__title">조회결과<span class="result-header__count">(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</span></h2>
    
    <div class="result-header__actions">
        <nav class="pagination" aria-label="페이지 이동">
            <input type="number" id="detailCurrentPage" class="form-control form-control--page" aria-label="이동할 페이지 번호" value="<c:out value='${paginationInfo.currentPageNo}'/>">
            <span aria-hidden="true">/</span>
            <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="button button--neutral" onclick="fnfacilityDetailPageMove('M')">이동</button>
            <button type="button" class="button button-neutral" onclick="fnfacilityDetailPageMove('P')">이전</button>
            <button type="button" class="button button-neutral" onclick="fnfacilityDetailPageMove('N')">다음</button>
            <input type="hidden" id="chkItemNo" value="<c:out value='${chkItemNo}'/>">
            <input type="hidden" id="chkItemVal" value="<c:out value='${chkItemVal}'/>">
        </nav>
    </div>
</div>

<div class="result-table">
    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="설비마스터-데이터">
            <thead>
            <tr>
                <th scope="col" data-field="사업소">사업소</th>
                <th scope="col" data-field="호기">호기</th>
                <th scope="col" data-field="설비번호">설비번호</th>
                <th scope="col" data-field="설비명">설비명</th>
                <th scope="col" data-field="위치번호">위치번호</th>
                <th scope="col" data-field="위치명">위치명</th>
            </tr>
            </thead>
            <tbody>
            <%-- 데이터가 없을 경우 --%>
            <c:if test="${fn:length(list) == 0}">
                <tr>
                    <th colspan="6">
                        <div class="no-data">
                            조회된 데이터가 없습니다.
                        </div>
                    </th>
                </tr>
            </c:if>
            <c:forEach var="data" items="${list}" varStatus="status">
                <tr onclick="equipCodeDetail('${data.equipNo}','${data.description}')">
                    <td data-field="사업소">${data.eqOrgNm}</td>
                    <td data-field="호기">${data.hokiNm}</td>
                    <td data-field="설비번호">${data.equipNo}</td>
                    <td data-field="설비명">${data.description}</td>
                    <td data-field="위치번호">${data.locNo}</td>
                    <td data-field="위치명">${data.locNm}</td>
                </tr>
            </c:forEach>
            </tbody>
        </table>
    </div>
</div>
