<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 개선요청 > 개선요청 조회 결과 리스트 --%>
<script>
    var totalPage = ${paginationInfo.totalPageCount};
</script>

<%-- 조회결과 --%>
<div class="title-box">
    <h4 class="title03">조회결과<small>(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h4>

    <div>
        <div class="page-move">
            <label for="currentPage" class="visually-hidden">이동할 페이지</label>
            <input type="number" id="currentPage" class="form-control page" value="<c:out value='${paginationInfo.currentPageNo}'/>">
            <span class="px-1">/</span>
            <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="btn btn-secondary" onclick="fnPageMove('M')">이동</button>
        </div>
        
        <div class="buttons">
            <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('P')">이전</button>
            <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('N')">다음</button>
            <%-- 앱 로그인 체크 --%>
            <%--<c:if test="${sessionScope.loginInfo.iui_isadmin ne '999'}">
                <button type="button" class="btn btn-primary btn-file-download" onclick="fnExcelDownload()">엑셀 다운로드</button>
            </c:if>--%>
        </div>
    </div>
</div>

<!-- data-grid -->
<div class="table-responsive" style="height: 350px;">
    <table class="data-table data-table--list data-table--interactive" aria-label="개선사항-조회결과">
        <thead>
        <tr>
            <th scope="col" data-field="순번">순번</th>
            <th scope="col" data-field="구분">구분</th>
            <th scope="col" data-field="제목">제목</th>
            <th scope="col" data-field="작성자">작성자</th>
            <th scope="col" data-field="부서명">부서명</th>
            <th scope="col" data-field="상태">상태</th>
            <th scope="col" data-field="등록일">등록일</th>
        </tr>
        </thead>
        <tbody>
        <%-- 데이터가 없을 경우 --%>
        <c:if test="${empty list}">
            <tr>
                <th colspan="7">
                    <div class="no-data">
                        조회된 데이터가 없습니다.
                    </div>
                </th>
            </tr>
        </c:if>

        <c:set var="newCount" value=""/>

        <c:forEach var="data" items="${list}" varStatus="status">
            <tr class="_TR_DATA" onclick="fnShowDetail($(this), ${data.iiiIdx})">
                <th scope="row" data-field="순번">${paginationInfo.totalRecordCount - ((paginationInfo.currentPageNo-1) * paginationInfo.recordCountPerPage + status.index)}</th>
                <td data-field="구분">
                    <c:choose>
                        <c:when test="${data.category eq 'IM'}">개선사항</c:when>
                        <c:when test="${data.category eq 'ID'}">아이디어</c:when>
                    </c:choose>
                </td>
                <td data-field="제목">${data.title}</td>
                <td data-field="작성자" class="ws-reset ws-start">${data.userName}</td>
                <td data-field="부서명" class="ws-reset ws-start">${data.deptName}</td>
                <td data-field="상태">
                    <c:choose>
                        <c:when test="${data.state eq 'S'}"><span class="text-primary">접수대기</span> <c:set var="newCount" value="${newCount + 1}"/></c:when>
                        <c:when test="${data.state eq 'R'}">검토중</c:when>
                        <c:when test="${data.state eq 'P'}">처리중</c:when>
                        <c:when test="${data.state eq 'C'}">처리완료</c:when>
                        <c:when test="${data.state eq 'F'}">처리불가</c:when>
                        <c:when test="${data.state eq 'L'}">향후적용</c:when>
                    </c:choose>
                </td>
                <td data-field="등록일">${fn:substring(data.timecreated, 0, 16)}</td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>

<div class="buttons">
	<button type="button" class="btn btn-primary" onclick="fnPageMove('P')">이전</button>
	<button type="button" class="btn btn-primary" onclick="fnPageMove('N')">다음</button>
</div>