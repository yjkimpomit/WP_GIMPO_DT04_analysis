<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 개선요청 > 개선요청 조회 결과 리스트 --%>
<script>
    var totalPage = ${paginationInfo.totalPageCount};
</script>

<%-- 조회결과 --%>
<div class="title-box">
    <h4 class="title03">조회결과<small>(전체 <fmt:formatNumber value="${listCount}" type="number"/>건)</small></h4>

    <div>
        <div class="page-move">
            <label for="currentPage" class="visually-hidden">이동할 페이지</label>
            <input type="number" id="currentPage" class="form-control page" value="<c:out value='${paginationInfo.currentPageNo}'/>">
            <span class="px-1">/</span>
            <span class="total"><fmt:formatNumber value="${paginationInfo.totalPageCount}" type="number"/></span>
            <button type="button" class="btn btn-secondary" onclick="fnPageMove('M')">이동</button>
        </div>
        
        <div class="buttons">
            <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('P')">이전</button>
            <button type="button" class="btn btn-outline-primary" onclick="fnPageMove('N')">다음</button>
            <%-- 앱 로그인 체크 --%>
            <%--<c:if test="${sessionScope.loginInfo.iui_isadmin ne '999'}">
                <button type="button" class="btn btn-primary btn-file-download" onclick="fnExcelDownload()">엑셀 다운로드</button>
            </c:if>--%>
        </div>
    </div>
</div>

<!-- data-grid -->
<div class="table-responsive" style="height: 350px;">
    <table class="data-table data-table--list data-table--interactive" aria-label="공지사항-리스트">
        <thead>
        <tr>
            <th scope="col" data-field="번호">번호</th>
            <th scope="col" data-field="제목">제목</th>
            <th scope="col" data-field="공지기간">공지기간</th>
            <th scope="col" data-field="작성자">작성자</th>
            <th scope="col" data-field="등록일">등록일</th>
        </tr>
        </thead>
        <tbody>
        <%-- 데이터가 없을 경우 --%>
        <c:if test="${empty list}">
            <tr>
                <th colspan="5">
                    <div class="no-data">
                        조회된 데이터가 없습니다.
                    </div>
                </th>
            </tr>
        </c:if>
        
        <%--<!-- 최상위일때 class="is-top-level" -->
        <!-- 신규등록된 글일때 class="is-new" -->--%>
        <c:set var="newCount" value=""/>

        <c:forEach var="data" items="${list}" varStatus="status">
            <c:set var="trClass" value=""/>

            <c:choose>
                <c:when test="${data.isActive eq '2'}">
                    <c:set var="newCount" value="${newCount + 1}"/>
                    <c:set var="trClass" value="is-top-level"/>
                </c:when>
                <c:otherwise>
                    <c:if test="${data.isActive eq '1'}">
                        <c:set var="newCount" value="${newCount + 1}"/>
                        <c:set var="trClass" value="is-new"/>
                    </c:if>
                </c:otherwise>
            </c:choose>

            <tr class="${trClass} _TR_DATA" onclick="fnShowDetail($(this), ${data.iniIdx})">
                <td data-field="순번">${paginationInfo.totalRecordCount - ((paginationInfo.currentPageNo-1) * paginationInfo.recordCountPerPage + status.index)}</td>
                <td data-field="제목">${data.title}</td>
                <td data-field="공지기간">${data.startDate} ~ ${data.endDate}</td>
                <td data-field="작성자">${data.userName}</td>
                <td data-field="등록일">${fn:substring(data.timecreated, 0, 10)}</td>
            </tr>
        </c:forEach>
        </tbody>
    </table>
</div>

<div class="buttons">
	<button type="button" class="btn btn-primary" onclick="fnPageMove('P')">이전</button>
	<button type="button" class="btn btn-primary" onclick="fnPageMove('N')">다음</button>
</div>