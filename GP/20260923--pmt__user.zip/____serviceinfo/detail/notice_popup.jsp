<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>

<c:if test="${not empty noticeList}">
    <% pageContext.setAttribute("newLineChar", "\n"); %>
    <%--<!-- 공지팝업 -->--%>
    <%--<div class="noticePopup popup-layer open" id="_NOTI_POPUP_DIV_">--%>
    <%-- VIEW POPUP PAGE --%>
    <div class="noticePopup-contents">
        <c:forEach var="data" items="${noticeList}" varStatus="status">
            <c:set var="divClass" value="d-none"/>
            <c:if test="${status.index == 0}"><c:set var="divClass" value=""/></c:if>

            <div class="_DIV_NOTI_ ${divClass}" id="_NOTI_${status.count}">
                <div class="noticePopup-title">
                    <span><c:out value="${data.title}" escapeXml="true"/></span>
                </div>
                <div class="noticePopup-text">
                        <%-- 개발 : 공지내용 들어가는 영역 start --%>
                    <c:out value="${fn:replace(data.content, newLineChar, '<br>')}" escapeXml="false"/>
                        <%-- 공지내용 들어가는 영역 end --%>
                </div>
            </div>
        </c:forEach>
    </div>

    <div class="noticePopup-footer">
        <div class="popup-links" id="pagination">
                <%-- 페이지 부분 --%>
        </div>
        <div>
            <div class="form-check form-check-inline">
                <input class="form-check-input me-2" type="checkbox" id="checkViewToday" value="1">
                <label class="form-check-label" for="checkViewToday">오늘 하루 이창 열지 않기</label>
            </div>
            <button type="button" class="btn-close" title="닫기" onclick="closeThisPopup(this);"></button>
        </div>
    </div>
    <%--</div>--%>

    <script src="${pageContext.request.contextPath}/resources/user/js/pagination/jquery.twbsPagination.min.js"></script>
    <script>
        $('#pagination').twbsPagination({
            totalPages: ${fn:length(noticeList)},
            visiblePages: 3,
            onPageClick: function (event, page) {
                $('._DIV_NOTI_').addClass('d-none');
                $('#_NOTI_' + page).removeClass('d-none');
            }
        });
    </script>
</c:if>