<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 개선요청 > 개선요청 등록/수정 화면 팝업 --%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="searchResultPopup">
    <h1 class="page-content__heading visually-hidden">개선요청 등록/수정</h1>

    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-fullscreen-lg-down modal-lg modal-xl">
        <div class="modal-content">

            <div class="modal-header">
                <h5 class="title04" id="dailyRiskEntryLabel">개선요청</h5>
            </div>

            <div class="modal-body" id="dailyRiskEntryContent">
                <div class="alert alert-primary required">
                    <p class="text-primary">
                        <strong class="text-danger">*</strong> 표시는 필수입력 항목입니다.
                    </p>
                </div>
                <form method="post" id="improvementsInputForm" name="improvementsInputForm" autocomplete="off" action="javascript:fnSaveImprovements()">
                    <input type="hidden" id="mode" name="mode" value="${improvementsVO.mode}"/>
                    <input type="hidden" id="iiiIdx" name="iiiIdx" value="${improvementsVO.iiiIdx}"/>

                    <div class="table-responsive">
                        <table class="data-table--list data-table--interactive" aria-label="개선사항-등록/수정">
                            <colgroup>
                                <col style="width: 8rem;">
                                <col style="width: calc(50vw - 8rem);">
                                <col style="width: 8rem;">
                                <col style="width: calc(50vw - 8rem);">
                            </colgroup>
                            <tbody>
                            <c:choose>
                                <c:when test="${improvementsVO.mode eq 'I'}">
                                    <c:set var="readOnly" value=""/>
                                    <c:set var="disabled" value=""/>

                                    <tr>
                                        <th scope="row">* 구분</th>
                                        <td colspan="3">
                                            <div class="row g-2">
                                                <div class="col">
                                                    <label for="category" class="visually-hidden">* 구분</label>
                                                    <select class="form-select" id="category" name="category" required>
                                                        <option value="">선택</option>
                                                        <option value="IM">개선사항</option>
                                                        <option value="ID">아이디어</option>
                                                    </select>
                                                </div>
                                                <div class="col">
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">* 제목</th>
                                        <td colspan="3">
                                            <label for="title" class="visually-hidden">제목</label>
                                            <input type="text" class="form-control" placeholder="" id="title" name="title" required maxlength="100" autocomplete="off">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">* 내용</th>
                                        <td colspan="3">
                                            <label for="content" class="visually-hidden">내용</label>
                                            <textarea class="form-control" style="height: 300px" id="content" name="content" required autocomplete="off"></textarea>
                                        </td>
                                    </tr>
                                </c:when>
                                <c:otherwise>
                                    <tr>
                                        <th scope="row">작성자</th>
                                        <td>${data.userName}</td>
                                        <th scope="row">부서명</th>
                                        <td>${data.deptName}</td>
                                    </tr>
                                    <tr>
                                        <th scope="row">구분</th>
                                        <td>
                                            <div class="row g-2">
                                                <div class="col">
                                                    <c:choose>
                                                        <c:when test="${data.category eq 'IM'}">개선사항</c:when>
                                                        <c:when test="${data.category eq 'ID'}">아이디어</c:when>
                                                    </c:choose>
                                                </div>
                                                <div class="col">
                                                </div>
                                            </div>
                                        </td>
                                        <th scope="row">등록일</th>
                                        <td>${fn:substring(data.timecreated, 0, 16)}</td>
                                    </tr>

                                    <%-- 접수중이면 수정가능 그외는 수정 불가능 처리 --%>
                                    <c:set var="readOnly" value=""/>
                                    <c:if test="${data.state ne 'S'}">
                                        <c:set var="readOnly" value="readonly"/>
                                    </c:if>

                                    <%-- 보기모드 --%>
                                    <tr>
                                        <th scope="row">* 제목</th>
                                        <td colspan="3">
                                            <label for="title" class="visually-hidden">제목</label>
                                            <input type="text" class="form-control _USER_UPDATE" placeholder="" id="title" name="title" required readonly maxlength="100" value="${data.title}">
                                        </td>
                                    </tr>
                                    <tr>
                                        <th scope="row">* 내용</th>
                                        <td colspan="3">
                                            <label for="content" class="visually-hidden">내용</label>
                                            <textarea class="form-control _USER_UPDATE" style="height: 120px" id="content" name="content" required readonly>${data.content}</textarea>
                                        </td>
                                    </tr>

                                    <c:if test="${not empty replyList}">
                                        <tr>
                                            <th scope="row">처리 내용</th>
                                            <td colspan="3">
                                                <c:forEach var="reply" items="${replyList}" varStatus="statusReply">
                                                    <textarea class="form-control" style="height: 120px" id="content" name="content" required readonly>${reply.comment}</textarea>
                                                </c:forEach>
                                            </td>
                                        </tr>
                                    </c:if>

                                    <tr>
                                        <th scope="row">처리상태</th>
                                        <td colspan="3">
                                            <div class="row g-2">
                                                <div class="col">
                                                    <c:choose>
                                                        <c:when test="${data.state eq 'S'}">접수대기</c:when>
                                                        <c:when test="${data.state eq 'R'}">검토중</c:when>
                                                        <c:when test="${data.state eq 'P'}">처리중</c:when>
                                                        <c:when test="${data.state eq 'C'}">처리완료</c:when>
                                                        <c:when test="${data.state eq 'F'}">처리불가</c:when>
                                                        <c:when test="${data.state eq 'L'}">향후적용</c:when>
                                                    </c:choose>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                                </c:otherwise>
                            </c:choose>

                            <%-- 처리 부분 --%>
                            <c:if test="${improvementsVO.mode eq 'U'}">
                                <%-- 관리자 : 0123 --%>
                                <tr class="_TR_REPLY_PWD d-none">
                                    <th scope="row" class="bg-warning-subtle">* 비밀번호</th>
                                    <td colspan="3" class="bg-warning-subtle">
                                        <label for="txtPwd" class="visually-hidden">비밀번호</label>
                                        <input type="password" class="form-control" placeholder="비밀번호를 입력하세요" id="txtPwd" maxlength="20" autocomplete="off" onkeydown="fnCheckPwd(event)">
                                    </td>
                                </tr>

                                <%-- 답글내용 등록/수정 부분 --%>
                                <c:choose>
                                    <c:when test="${not empty replyList}">
                                        <tr class="_TR_REPLY d-none">
                                            <th scope="row" class="bg-warning-subtle">* 처리 내용</th>
                                            <td colspan="3" class="bg-warning-subtle">
                                                <label for="comment" class="visually-hidden">처리 내용</label>
                                                <c:forEach var="reply" items="${replyList}" varStatus="statusReply">
                                                    <textarea class="form-control _COMMENT" style="height: 120px" id="comment" name="comment">${reply.comment}</textarea>
                                                </c:forEach>
                                            </td>
                                        </tr>

                                        <%-- 처리 상태 --%>
                                        <tr class="_TR_REPLY d-none">
                                            <th scope="row" class="bg-warning-subtle">* 처리상태</th>
                                            <td colspan="3" class="bg-warning-subtle">
                                                <div class="row g-2">
                                                    <div class="col">
                                                        <label for="state" class="visually-hidden">* 처리상태</label>
                                                        <select class="form-select" id="state" name="state" required>
                                                            <option value="S" <c:if test="${data.state eq 'S'}">selected="selected"</c:if>>접수대기</option>
                                                            <option value="R" <c:if test="${data.state eq 'R'}">selected="selected"</c:if>>검토중</option>
                                                            <option value="P" <c:if test="${data.state eq 'P'}">selected="selected"</c:if>>처리중</option>
                                                            <option value="C" <c:if test="${data.state eq 'C'}">selected="selected"</c:if>>처리완료</option>
                                                            <option value="F" <c:if test="${data.state eq 'F'}">selected="selected"</c:if>>처리불가</option>
                                                            <option value="F" <c:if test="${data.state eq 'L'}">selected="selected"</c:if>>향후적용</option>
                                                        </select>
                                                    </div>
                                                    <div class="col">
                                                        <button class="btn btn-danger" type="button" id="btnReplySave" onclick="fnSaveReply()">답변 저장</button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </c:when>
                                    <c:otherwise>
                                        <%-- 코멘트가 없으면 --%>
                                        <tr class="_TR_REPLY d-none">
                                            <th scope="row" class="bg-warning-subtle">* 처리 내용</th>
                                            <td colspan="3" class="bg-warning-subtle">
                                                <label for="comment" class="visually-hidden">처리 내용</label>
                                                <textarea class="form-control _COMMENT" style="height: 120px" id="comment" name="comment"></textarea>
                                            </td>
                                        </tr>

                                        <%-- 처리 상태 --%>
                                        <tr class="_TR_REPLY d-none">
                                            <th scope="row" class="bg-warning-subtle">* 처리상태</th>
                                            <td colspan="3" class="bg-warning-subtle">
                                                <div class="row g-2">
                                                    <div class="col">
                                                        <label for="state" class="visually-hidden">* 처리상태</label>
                                                        <select class="form-select" id="state" name="state" required>
                                                            <option value="S" <c:if test="${data.state eq 'S'}">selected="selected"</c:if>>접수대기</option>
                                                            <option value="R" <c:if test="${data.state eq 'R'}">selected="selected"</c:if>>검토중</option>
                                                            <option value="P" <c:if test="${data.state eq 'P'}">selected="selected"</c:if>>처리중</option>
                                                            <option value="C" <c:if test="${data.state eq 'C'}">selected="selected"</c:if>>처리완료</option>
                                                            <option value="F" <c:if test="${data.state eq 'F'}">selected="selected"</c:if>>처리불가</option>
                                                            <option value="F" <c:if test="${data.state eq 'L'}">selected="selected"</c:if>>향후적용</option>
                                                        </select>
                                                    </div>
                                                    <div class="col">
                                                        <button class="btn btn-danger" type="button" id="btnReplySave" onclick="fnSaveReply()">답변 저장</button>
                                                    </div>
                                                </div>
                                            </td>
                                        </tr>
                                    </c:otherwise>
                                </c:choose>
                            </c:if>
                            </tbody>
                        </table>
                    </div>

                    <div class="buttons">
                        <c:choose>
                            <c:when test="${improvementsVO.mode eq 'I'}">
                                <%-- 등록 --%>
                                <button class="btn btn-primary" type="submit" id="btnSubmit">등록</button>
                            </c:when>
                            <c:when test="${(sessionScope.loginInfo.iui_user_id eq data.userId) and (improvementsVO.mode eq 'U') and (data.state eq 'S')}">
                                <%-- 수정시 저장하는 버튼 --%>
                                <button class="btn btn-danger d-none _USER_UPDATE_SAVE_BTN" type="submit" id="btnSave">저장</button>
                                <%-- 수정 --%>
                                <button class="btn btn-primary _USER_UPDATE_BTN" type="button" onclick="fnModifyImprovements()">수정</button>
                                <button class="btn btn-secondary" type="button" onclick="fnPopDataRemove('${data.iiiIdx}')">삭제</button>
                            </c:when>
                        </c:choose>

                        <c:set var="accessUserId" value="16161357"/>
                        <c:if test="${sessionScope.loginInfo.iui_user_id eq accessUserId and improvementsVO.mode eq 'U'}">
                            <%-- 관리자 --%>
                            <button class="btn btn-danger" type="button" id="btnReply" onclick="fnPopDataReply()">답변</button>
                        </c:if>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
    <%-- /* 개선사항 > 등록/수정 처리 */ --%>
    function fnSaveImprovements() {
        try {
            isCheckFormat = false;

            $('#improvementsInputForm input[required]').each(function () {
                var $input = $(this);
                var name = $input.attr('name');
                var value = $input.val();

                if (!name) return; // name 속성이 없으면 건너뜀

                if (value === '') {
                    isCheckFormat = true;
                    return false;
                } else {
                    isCheckFormat = false;
                }
            });

            if (isCheckFormat) {
                alert("필수항목을 확인해 주시기 바랍니다.");
                return false;
            }
        } catch (e) {
            alert("필수항목을 확인해 주시기 바랍니다.");
            return false;
        }

        $('#improvementsInputForm :input').prop('disabled', false);

        if (confirm("내용을 저장하시겠습니까?")) {
            $.ajax({
                type: "post"
                , url: "/improvements/improvementsSave.do"
                , data: $("#improvementsInputForm").serialize()
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        $("#_DATA_FORM_POPUP .close").click();
                        fnSearchList();
                    } else {
                        alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주십시오.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주십시오.");
                }
                , complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }

    <%-- /* 개선사항 > 삭제 처리 */ --%>
    function fnPopDataRemove(idx) {
        if(confirm("삭제하시겠습니까?")) {
            $.ajax({
                type: "post"
                , url: "/improvements/improvementsSave.do"
                , data: {mode: "D", iiiIdx: idx}
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        $("#_DATA_FORM_POPUP .close").click();
                        fnSearchList();
                    } else {
                        alert("오류가 발생했습니다.\n잠시 후 다시 시도하시기 바랍니다.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                }
                , complete: function (data) {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }

    function fnModifyImprovements() {
        $("._TR_REPLY_PWD").addClass('d-none');
        $("#btnReply").prop('disabled', false);
        $("._TR_REPLY").addClass('d-none');

        $("._USER_UPDATE_BTN").addClass('d-none');
        $("._USER_UPDATE_SAVE_BTN").removeClass('d-none');
        $("._USER_UPDATE").prop('readonly', false);
    }

    function fnPopDataReply() {
        $("._USER_UPDATE_BTN").removeClass('d-none');
        $("._USER_UPDATE_SAVE_BTN").addClass('d-none');
        $("._USER_UPDATE").prop('readonly', true);

        $("#btnReply").prop('disabled', true);
        $("._TR_REPLY_PWD").removeClass('d-none');
        $("#txtPwd").focus();
    }

    function fnCheckPwd(e) {
        if (e.key === "Enter" || e.keyCode === 13) {
            e.preventDefault();

            $.ajax({
                type: "post"
                , url: "/improvements/checkPwd.do"
                , data: {userPwd: e.target.value}
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        $("._TR_REPLY_PWD").addClass('d-none');
                        $("._TR_REPLY").removeClass('d-none');
                    } else {
                        alert("비밀번호가 일치하지 않습니다.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                }
                , complete: function (data) {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }

    function fnSaveReply() {
        if (confirm("처리 내용을 저장하시겠습니까?")) {
            $.ajax({
                type: "post"
                , url: "/improvements/saveComment.do"
                , data: $("#improvementsInputForm").serialize()
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        alert("정상적으로 처리되었습니다.");
                        $("#_DATA_FORM_POPUP .close").click();
                        fnSearchList();
                    } else {
                        alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                }
                , complete: function (data) {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }
</script>
</body>
<c:import url="/footer.do"/>