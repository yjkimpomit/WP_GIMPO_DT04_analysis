<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 개선요청 > 공지사항 등록/수정 화면 팝업 --%>

<c:import url="/header.do"/>

<body>
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<main class="winbox-layout page-content page-content--popup" id="searchResultPopup">
    <h1 class="page-content__heading visually-hidden">공지사항</h1>

    <div class="modal-dialog modal-dialog-centered modal-dialog-scrollable modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="title04">공지사항</h5>
            </div>

            <div class="modal-body">
                <div class="alert alert-primary required">
                    <p class="text-primary"><strong class="text-danger">*</strong> 표시는 필수입력 항목입니다.</p>
                </div>

                <form method="post" id="noticeInputForm" name="noticeInputForm" autocomplete="off" action="javascript:fnSaveNotice()">
                    <input type="hidden" id="mode" name="mode" value="${noticeVO.mode}"/>
                    <input type="hidden" id="iniIdx" name="iniIdx" value="${noticeVO.iniIdx}"/>

                    <div class="table-responsive">
                        <table class="data-table data-table--list data-table--interactive" aria-label="공지사항-등록/수정">
                            <colgroup>
                                <col style="width: 8rem;">
                                <col style="width: calc((50% - 8rem));">
                                <col style="width: 8rem;">
                                <col style="width: calc((50% - 8rem));">
                            </colgroup>
                            <tbody>
                            <tr>
                                <th scope="row">* 구분</th>
                                <td>
                                    <label for="category" class="visually-hidden">* 구분</label>
                                    <select class="form-select" id="category" name="category" required="">
                                        <option value="N">공지</option>
                                    </select>
                                </td>
                                <th scope="row">최상위 등록</th>
                                <td>
                                    <div class="form-check form-check-inline">
                                        <input class="form-check-input" type="checkbox" name="topType" id="isTopLevel" value="1" <c:if test="${data.topType > 0}">checked</c:if>>
                                        <label class="form-check-label" for="isTopLevel">
                                            최상위 등록
                                        </label>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">* 공지기간</th>
                                <td colspan="3">
                                    <div class="row g-2">
                                        <div class="col">
                                            <label class="visually-hidden" for="startDate">시작일</label>
                                            <input type="date" class="form-control icon-calendar" id="startDate" name="startDate" value="${data.startDate}" required>
                                        </div>
                                        <div class="col-auto">
                                            <span class="form-control-plaintext text-center">~</span>
                                        </div>
                                        <div class="col">
                                            <label class="visually-hidden" for="endDate">종료일</label>
                                            <input type="date" class="form-control icon-calendar" id="endDate" name="endDate" value="${data.endDate}" required>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">* 제목</th>
                                <td colspan="3">
                                    <label for="title" class="visually-hidden">제목</label>
                                    <%-- 모바일 최대 글자수 24 --%>
                                    <input type="text" class="form-control" placeholder="제목은 최대 24까지 입력가능합니다" id="title" name="title" value="${data.title}" required="" maxlength="24" autocomplete="off">
                                </td>
                            </tr>
                            <tr>
                                <th scope="row">* 내용</th>
                                <td colspan="3">
                                    <label for="content" class="visually-hidden">내용</label>
                                    <textarea class="form-control" style="height: 200px" id="content" name="content" required="" autocomplete="off">${data.content}</textarea>
                                </td>
                            </tr>
                            </tbody>
                        </table>
                    </div>

                    <div class="buttons">
                        <c:choose>
                            <c:when test="${noticeVO.mode eq 'I'}">
                                <%-- 등록 --%>
                                <button class="btn btn-primary" type="submit" id="btnSubmit">등록</button>
                            </c:when>
                            <c:when test="${(sessionScope.loginInfo.iui_user_id eq data.userId) and (noticeVO.mode eq 'U')}">
                                <%-- 수정 --%>
                                <button class="btn btn-primary" type="submit">수정</button>
                                <button class="btn btn-secondary" type="button" onclick="fnPopDataRemove('${data.iniIdx}')">삭제</button>
                            </c:when>
                        </c:choose>
                        <button class="btn btn-secondary close" type="button" onclick="fnPopCloseThis()">취소</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</main>

<script>
    <%-- /* 개선사항 > 등록/수정 처리 */ --%>
    function fnSaveNotice() {
        try {
            isCheckFormat = false;

            $('#noticeInputForm input[required]').each(function () {
                var $input = $(this);
                var name = $input.attr('name');
                var value = $input.val();

                if (!name) return; // name 속성이 없으면 건너뜀

                if (value === '') {
                    isCheckFormat = true;
                    return false;
                } else {
                    isCheckFormat = false;
                }
            });

            if (isCheckFormat) {
                alert("필수항목을 확인해 주시기 바랍니다.");
                return false;
            }
        } catch (e) {
            alert("필수항목을 확인해 주시기 바랍니다.");
            return false;
        }

        $('#noticeInputForm :input').prop('disabled', false);

        if (confirm("내용을 저장하시겠습니까?")) {
            $.ajax({
                type: "post"
                , url: "/notice/noticeSave.do"
                , data: $("#noticeInputForm").serialize()
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        $("#addNoticePopup .close").click();
                        fnSearchList();
                    } else {
                        alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주십시오.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주십시오.");
                }
                , complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }

    <%-- /* 개선사항 > 삭제 처리 */ --%>
    function fnPopDataRemove(idx) {
        if(confirm("삭제하시겠습니까?")) {
            $.ajax({
                type: "post"
                , url: "/notice/noticeSave.do"
                , data: {mode: "D", iniIdx: idx}
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        $("#addNoticePopup .close").click();
                        fnSearchList();
                    } else {
                        alert("오류가 발생했습니다.\n잠시 후 다시 시도하시기 바랍니다.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                }
                , complete: function (data) {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }

    function fnPopCloseThis() {
        window.parent.$(".winbox.app-winbox.app-winbox--detail.focus").find(".wb-close").trigger("click");
    }
</script>
</body>
<c:import url="/footer.do"/>