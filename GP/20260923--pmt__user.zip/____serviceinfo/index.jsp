<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<%-- <!-- 로딩박스 --> --%>
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<%-- 개선사항 > 개선사항 메인 팝업 --%>
<div class="container-service">

    <%--<!-- tab-menu -->--%>
    <ul class="nav nav-tabs" id="serviceTab" role="tablist">
        <li class="nav-item" role="presentation">
            <button class="nav-link active _TAB_PAGE" id="feedbackTab" data-bs-toggle="tab" data-bs-target="#feedbackTabPane" type="button" role="tab" aria-controls="feedbackTabPane" aria-selected="true" data-page="/improvements/improvements.do">
                개선사항
                <span class="icon-new" id="_IMP_COUNT">${impCount}</span>
            </button>
        </li>
        <li class="nav-item" role="presentation">
            <button class="nav-link _TAB_PAGE" id="noticeTab" data-bs-toggle="tab" data-bs-target="#noticeTabPane" type="button" role="tab" aria-controls="noticeTabPane" aria-selected="false" data-page="/notice/notice.do">
                공지사항
                <span class="icon-new" id="_NOTI_COUNT">${notiCount}</span>
            </button>
        </li>

        <%-- 정구인 차장님 사번 --%>
        <c:set var="accessUserId" value="16161357"/>
        <c:if test="${sessionScope.loginInfo.iui_user_id eq accessUserId}">
            <li class="nav-item" role="presentation">
                <button class="nav-link _TAB_PAGE" id="settingTab" data-bs-toggle="tab" data-bs-target="#settingTabPane" type="button" role="tab" aria-controls="settingTabPane" aria-selected="false" data-page="/groupset/setting.do">
                    서비스 설정
                </button>
            </li>
        </c:if>
    </ul>

    <%--<!-- tab content -->--%>
    <div class="tab-content" id="serviceTabContent">

        <%--<!-- 개선사항 -->--%>
        <div class="tab-pane fade show active _TAB_CONTENT" id="feedbackTabPane" role="tabpanel" aria-labelledby="feedbackTab" tabindex="0">
            <c:import url="/improvements/improvements.do"/>
        </div>

        <%--<!-- 공지사항 -->--%>
        <div class="tab-pane fade _TAB_CONTENT" id="noticeTabPane" role="tabpanel" aria-labelledby="noticeTab" tabindex="0">
            <%--<c:import url="/notice/notice.do"/>--%>
        </div>

        <%--<!-- 서비스 설정 -->--%>
        <div class="tab-pane fade _TAB_CONTENT" id="settingTabPane" role="tabpanel" aria-labelledby="settingTab" tabindex="0">
            <%--<c:import url="/notice/notice.do"/>--%>
        </div>
    </div>

</div>

<script>
    $(document).ready(function () {
        // 탭 인덱스 (기본 0)
        var rawIdx = '${empty improvementsVO.tabIdx ? 0 : improvementsVO.tabIdx}';
        var tabIdx = parseInt(rawIdx);
        var $tabs = $('._TAB_PAGE');

        // view content
        function fnLoadTabContent($btn) {
            // 대상 탭 버튼/패널
            var targetContentId = $btn.attr('data-bs-target');
            var targetUrl = $btn.attr('data-page');
            if (!targetContentId || !targetUrl) return;

            $('._TAB_CONTENT').empty();

            $.ajax({
                url: targetUrl,
                type: "POST",
                dataType: "html",
                beforeSend: function () {
                    $("#loadingBar").css("display", "");
                },
                success: function (data) {
                    $(targetContentId).html(data);
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        }

        // 탭 클릭 시: Bootstrap 탭 전환 + Ajax 로딩
        $('._TAB_PAGE').on('click', function (e) {
            e.preventDefault();

            // Bootstrap 탭 활성화 보장 : common.js에서 공통으로 사용
            fnSetCommonBootstrapTab($(this));

            // 데이터 로딩
            fnLoadTabContent($(this));
        });

        // 페이지 로딩시 tabIndex 실행
        var $initial = $tabs.eq(tabIdx);
        if ($initial.length) {
            // BS 탭 전환 후 컨텐츠 로드
            if (window.bootstrap && typeof window.bootstrap.Tab === 'function') {
                new bootstrap.Tab($initial[0]).show();
            }
            $initial.trigger('click');
        }
    });
</script>

</body>
<c:import url="/footer.do"/>
