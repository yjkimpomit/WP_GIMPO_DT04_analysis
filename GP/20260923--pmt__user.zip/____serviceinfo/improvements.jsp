<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%-- 개선요청 > 개선요청 리스트 팝업 --%>
<div class="title-box">
    <h3 class="title02">개선요청</h3>
</div>

<div class="search-box">
    <form id="searchImprovementsForm" autocomplete="off" action="javascript:fnSearchList();">
        <input type="hidden" name="pageIndex" id="pageIndex" value="${improvementsVO.pageIndex}">
        <input type="hidden" id="ColList" name="ColList" value=""/>
        <div class="row">
            <div class="col-md-auto">
                <label class="form-label" for="category">구분</label>
                <select class="form-select" aria-label="구분 선택" id="category" name="category">
                    <option value="">전체</option>
                    <option value="IM">개선요청</option>
                    <option value="ID">아이디어</option>
                </select>
            </div>
            <div class="col-md-auto">
                <label class="form-label" for="category">상태</label>
                <select class="form-select" aria-label="상태 선택" id="state" name="state">
                    <option value="">전체</option>
                    <option value="S">접수대기</option>
                    <option value="R">검토중</option>
                    <option value="P">처리중</option>
                    <option value="C">처리완료</option>
                    <option value="F">처리불가</option>
                    <option value="L">향후적용</option>
                </select>
            </div>
            <div class="col-md col-lg-4 col-xxl-3">
                <label class="form-label" for="keyword">검색</label>
                <input class="form-control" type="text" id="keyword" name="searchKeyword" placeholder="제목, 작성자, 부서명 검색" autocomplete="off"/>
            </div>
            <div class="col col-md-auto">
                <button type="button" class="btn btn-primary" onclick="fnSearchList()">
                    <span class="icon icon-search"></span>
                    <span>검색</span>
                </button>
            </div>
            <div class="col col-md-auto">
                <button type="button" class="btn btn-primary" onclick="fnAddFormPop('', 0)">
                    <span class="icon icon-edit"></span>
                    <span>등록하기</span>
                </button>
            </div>
        </div>
    </form>
</div>

<%--<!-- 등록 Start -->--%>
<div class="modal fade" id="_DATA_FORM_POPUP" tabindex="-1">
    <%-- 등록 팝업창 위치 : /improvementsForm.jsp --%>
</div>
<%--<!-- 등록 End -->--%>

<%--<!-- data list -->--%>
<div id="_DATA_LIST">
    <%-- 검색결과 리스트 : /detail/improvements_list.jsp --%>
</div>
<%--<!-- data list End -->--%>

<script>
    function fnSearchList() {
        $.ajax({
            type: "POST"
            , url: "/improvements/improvementsList.do"
            , data: $("#searchImprovementsForm").serialize()
            , dataType: "html"
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (data) {
                $("#_DATA_LIST").html(data);
            }
            , error: function () {
                alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    fnSearchList();

    <%-- /* 등록/수정 팝업 */ --%>
    function fnAddFormPop(row, idx) {
        var mode = "I";
        var title = "개선사항 등록";

        if (idx > 0) {
            mode = "U";
            title = "개선사항 수정";
        }

        // active class
        $("._TR_DATA").removeClass("active");
        $(row).addClass("active");

        var data = "?iiiIdx=" + idx + "&mode=" + mode;
        var url = "/improvements/improvementsForm.do";

        var box = new WinBox(title, {
            url: url,
            width: Math.min(1400, window.innerWidth - 20) + "px",
            height: Math.min(window.innerHeight - 20, window.innerHeight - 20) + "px",
            x: "center",
            y: "center",
            modal: true,
            oncreate: fnEnableModalInteraction,
            focus: true,
            class: ["app-winbox", "app-winbox--detail"],
            position: "center",
            onresize: function (w, y) {
                if (this.min) return;
                this.move("center", "center");
            },
            onclose: function () {
            }
        });
    }

    <%-- 페이지 이동 부분 --%>
    function fnPageMove(f) {
        var currentPage = parseInt($("#currentPage").val());

        if (f === 'P') {
            if (currentPage === 1) {
                alert("처음 페이지입니다.");
                return false;
            }
            currentPage = currentPage - 1;
        } else if (f === 'N') {
            if (currentPage === totalPage) {
                alert("마지막 페이지입니다.");
                return false;
            }
            currentPage = currentPage + 1;
        } else if (f === 'M') {
            if (currentPage > totalPage) {
                alert("마지막 페이지는 " + totalPage + "입니다. 이 페이지를 초과할 수 없습니다.");
                $("#currentPage").val(totalPage);
                return false;
            }
        }

        $("#currentPage").val(currentPage);

        $("#searchImprovementsForm #pageIndex").val(currentPage);
        fnSearchList();
    }

    <%-- /* 리스트에서 상세 팝업 */ --%>
    function fnShowDetail(row, idx) {
        fnAddFormPop(row, idx);
    }

    <%-- /* 엑셀 다운로드 */ --%>
    function fnExcelDownload() {
        $.ajax({
            type: "POST"
            , url: "/improvements/improvementsExcelDownload.do"
            , data: $("#searchImprovementsForm").serialize()
            , xhrFields: {
                responseType: 'blob'  // 응답을 Blob 형식으로 받기
            }
            , beforeSend: function () {
                $("#loadingBar").css("display", "");
            }
            , success: function (response, status, xhr) {
                //현재 날짜 가져오기
                var currentDate = new Date();
                var formattedDate = currentDate.getFullYear() + '-' +
                    (currentDate.getMonth() + 1).toString().padStart(2, '0') + '-' +
                    currentDate.getDate().toString().padStart(2, '0');

                // Blob을 사용하여 파일 다운로드 처리
                var blob = response;
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = "개선사항_" + formattedDate + ".xlsx";
                link.click();  // 다운로드 트리거
            }
            , error: function (request, status, error) {
                alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            }
            , complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }

    <%-- /* 개선사항 > 삭제 처리 */ --%>
    function fnPopDataRemove(idx) {
        if(confirm("삭제하시겠습니까?")) {
            $.ajax({
                type: "post"
                , url: "/improvements/improvementsSave.do"
                , data: {mode: "D", iiiIdx: idx}
                , dataType: "json"
                , beforeSend: function () {
                    $("#loadingBar").css("display", "");
                }
                , success: function (data) {
                    if (data.result > 0) {
                        $("#_DATA_FORM_POPUP .close").click();
                        fnSearchList();
                    } else {
                        alert("오류가 발생했습니다.\n잠시 후 다시 시도하시기 바랍니다.");
                    }
                }
                , error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                }
                , complete: function (data) {
                    $("#loadingBar").css("display", "none");
                }
            });
        }
    }
</script>
