<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#FFFFFF">
    <title>서부발전 김포열병합 DT</title>
    <meta name="description" content="서부발전 김포열병합 DT 제공">

    <!-- favicon -->
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.ico" sizes="any">
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.svg" type="image/svg+xml">
    <!-- WP stylesheet -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/css/login.css">
</head>

<body>
<h1>서부발전 <span>김포열병합 DT</span></h1>

<div class="login-panel">
    <div class="login-box">

        <h2 class="title">로그인</h2>
        <form class="login-form" id="frmLogin">
            <fieldset>
                <label class="visually-hidden-focusable" for="txtUserId">아이디</label>
                <input class="form-control icon-account" type="text" id="txtUserId" value="pomit" name="iui_user_id" autocomplete="off" placeholder="아이디를 입력하여 주십시요." aria-describedby="IdHelp"/>
            </fieldset>
            <fieldset>
                <label class="visually-hidden-focusable" for="txtUserPwd">비밀번호</label>
                <input class="form-control icon-lock" type="password" value="pomit!9400" id="txtUserPwd" name="iui_user_pwd" autocomplete="off" placeholder="비밀번호를 입력하여 주십시요.">
            </fieldset>

            <!--<small id="IdHelp" id="errTxt" class="form-text text-muted">아이디 정책에 대한 메세지가 표시됩니다.</small> -->
            <div id="errTxt" class="err-box"></div>

            <div class="form-check mb-3">
                <input class="form-check-input" type="checkbox" id="idKeep" name="idKeep" value="1"/>
                <label class="form-check-label" for="idKeep">아이디 저장</label>
            </div>
            <button class="button button--primary" type="button" onclick="loginProcess();" title="로그인">로그인</button>
        </form>
    </div>
</div>

<!-- Scripts -->
<script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery-3.6.1.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery-ui.js"></script>

<script>
    function setCookie(cookieName, value, exdays) {
        var exdate = new Date();
        exdate.setDate(exdate.getDate() + exdays);
        var cookieValue = escape(value) + ((exdays == null) ? "" : "; expires=" + exdate.toGMTString());
        document.cookie = cookieName + "=" + cookieValue;
    }

    function deleteCookie(cookieName) {
        var expireDate = new Date();
        expireDate.setDate(expireDate.getDate() - 1);
        document.cookie = cookieName + "=" + "; expires=" + expireDate.toGMTString();
    }

    function getCookie(cookieName) {
        cookieName = cookieName + "=";
        var cookieData = document.cookie;
        var start = cookieData.indexOf(cookieName);
        var cookieValue = "";

        if (start !== -1) {
            start += cookieName.length;

            var end = cookieData.indexOf(";", start);
            if (end === -1) end = cookieData.length;
            cookieValue = cookieData.substring(start, end);
        }

        return unescape(cookieValue);
    }

    function loginProcess() {
        $("#errTxt").empty();

        var flg = true;
        var errorMsg = "";

        if ($("input[name='iui_user_id']").val() === "") {
            flg = false;
            errorMsg += "<span>아이디를 입력하여 주십시요.</span>";
        }

        if ($("input[name='iui_user_pwd']").val() === "") {
            flg = false;
            errorMsg += "<span>비밀번호를 입력하여 주십시요.</span>";
        }

        if (flg) {
            var formData = $("#frmLogin").serialize();

            $.ajax({
                url: "/loginProcess.do",
                type: "POST",
                data: formData,
                dataType: "json",
                success: function (data) {
                    var result = data.result;
                    var resultMsg = data.resultMsg;
                    var moveUrl = data.moveUrl;

                    if (result !== 1) {
                        $("#errTxt").html("<span>" + resultMsg + "</span>");
                        $("input[name='eui_user_id']").val("");
                        $("input[name='eui_user_pwd']").val("");
                    } else {
                        location.href = moveUrl;
                    }
                },
                error: function (request, status, error) {
                    alert("오류가 발생했습니다.\n잠시 후 다시 시도해 주시기 바랍니다.");
                }
            });
        } else {
            $("#errTxt").html(errorMsg);
        }
    }
	
	//로그인버튼 엔터키 적용
	$("input[name='iui_user_id'], input[name='iui_user_pwd']").on("keydown", function (e) {
		if (e.key === "Enter") {
			e.preventDefault();
			loginProcess();
		}
	});

    $(document).ready(function () {
        var cookieId = getCookie("saveUserId");

        $("input[name='iui_user_id']").val(cookieId);

        if ($("input[name='iui_user_id']").val() !== "") {
            $("#idKeep").prop("checked", true);
        }

        $("#idKeep").change(function () {
            if ($("#idKeep").is(":checked")) {
                var targetUserId = $("input[name='iui_user_id']").val();
                if (targetUserId !== "") {
                    setCookie("saveUserId", targetUserId, 30);
                } else {
                    alert("ID 입력 후 저장버튼을 선택하여 주십시요.");
                    $("#idKeep").prop("checked", false);
                }
            } else {
                deleteCookie("saveUserId");
            }
        });

        $("input[name='iui_user_id']").keyup(function () {
            if ($("#idKeep").is(":checked")) {
                var saveUserId = $("input[name='iui_user_id']").val();
                setCookie("saveUserId", targetUserId, 30);
            }
        });

        $("input[name='iui_user_id'],input[name='iui_user_pwd']").on('keypress', function (e) {
            if (e.keyCode === '13') {
                loginProcess();
            }
        });

        $("#txtUserPwd").on('keypress', function (e) {
            if(e.keyCode === 13) {
                loginProcess();
            }
        });
    });
</script>

</body>
</html>
