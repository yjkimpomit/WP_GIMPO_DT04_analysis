<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<%--<c:import url="/header.do"/>--%>

<%-- 개발참고: 인덱스화면과 서브화면은 서로 다른 각각의 css 를 불러옵니다. --%>

<!DOCTYPE html>
<html lang="ko">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#FFFFFF">
    <title>서부발전 김포열병합 DT</title>

    <meta name="description" content="서부발전 김포열병합 DT 서비스 제공">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">

    <%-- <!-- favicon --> --%>
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.ico" sizes="any">
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.svg" type="image/svg+xml">

    <%-- <!-- toastchart --> --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/toastchart/toastui-chart.min.css">

    <%-- alert --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/jquery/confirm/jquery-confirm.min.css">
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/jquery/confirm/jquery-confirm.override.css">

    <%--
        * js에 사용할 변수 선언
        * 모바일 체크
        * 사업소, 호기 정보
        * IDMS 페이지 <---> 3D MODEL
    --%>
    <script>
		// check device
		var checkDevice = "${device}";
		var eqOrgNo = "${sessionScope.eqOrgNo}";
		var hoki = "${sessionScope.hoki}";
		var _isIdmsPage = false;
    </script>

    <%-- <!-- slick js --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery-3.6.1.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/common.js?t=${System.currentTimeMillis()}"></script>

    <%-- <!-- toastchart --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/toastchart/toastui-chart.min.js"></script>

    <%-- <!-- chartjs --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/chart/chart.umd.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/chart/chartjs-adapter-date-fns.bundle.min.js"></script>

    <%-- ztree --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/ztree/css/metroStyle/metroStyle.css" type="text/css">
    <script src="${pageContext.request.contextPath}/resources/user/js/ztree/js/jquery.ztree.all.min.js"></script>

    <%-- <!-- 부트스트랩 JS --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/bootstrap/popper.min.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/bootstrap/bootstrap.bundle.min.js"></script>

    <%-- daterangepicker --%>
    <link rel="stylesheet" type="text/css" media="all" href="${pageContext.request.contextPath}/resources/user/js/daterangepicker/daterangepicker.css"/>
    <script src="${pageContext.request.contextPath}/resources/user/js/daterangepicker/moment/moment-with-locales.min.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/daterangepicker/daterangepicker.js"></script>

    <%-- <!-- bPopup --> --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery.bpopup.min.js"></script>

    <%-- winbox js --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/js/winbox/winbox.min.css">
    <script src="${pageContext.request.contextPath}/resources/user/js/winbox/winbox.min.js"></script>

    <%-- alert --%>
    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/confirm/jquery-confirm.min.js"></script>

    <%-- <!-- WP stylesheet --> --%>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/css/index.css?t=${System.currentTimeMillis()}">
    <script src="${pageContext.request.contextPath}/resources/user/js/index/menu.js"></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/index/header-search.js" defer></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/index/header-realtime-panel.js" defer></script>
    <script src="${pageContext.request.contextPath}/resources/user/js/index/header-model-tree.js" defer></script>
</head>

<body class="main">

<!-- 모바일 최소화 창 도킹 -->
<section data-winbox-dock aria-label="최소화된 창" hidden>
    <button type="button" aria-expanded="false" aria-controls="winbox-minimized-list">최소화된 창 0개</button>
    <ul id="winbox-minimized-list" aria-label="최소화된 창 목록" hidden></ul>
</section>

<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<!-- top 로드 -->
<c:import url="/top.do"/>

<%-- 상단 대시보드 정보 : restApi 연결 --%>
<script src="${pageContext.request.contextPath}/resources/user/js/main/main_operation_info.js?t=${System.currentTimeMillis()}"></script>

<!-- 메뉴파일(left) 로드 -->
<div class="left-box">
    <c:import url="/left.do"/>
</div>

<script src="${pageContext.request.contextPath}/resources/user/js/unity/unityUtil.js"></script>
<script src="${pageContext.request.contextPath}/resources/user/js/unity/webUtil.js"></script>

<div id="unity-container" class="model-viewer">
    <%--<div id="model-tree-panel" class="model-tree" hidden style="position: absolute; top: auto; right: 16px; width: 320px; height: 240px; background-color: rgba(255, 0, 125, 0.6);">Toggle Tester</div>
    <div style="width:360px; height: 320px; background-color: rgba(255, 0, 125, 0.6); margin: 48px auto;">model-viewer tester</div>--%>
    <iframe src="${pageContext.request.contextPath}/3djs/index.html" width="100%" height="100%" title="3d model"></iframe>
</div>

<%-- <!-- 3D모델 사용가이드 --> --%>
<div class="popup unity-guide" style="display: none;">
    <div class="popup-header">
        <strong class="title">3D모델 사용가이드</strong>
        <button type="button" class="btn-close" title="가이드박스 닫기" onclick="closeControlGuide();"></button>
    </div>
    <div class="popup-body">
        <!-- 터치기반인 경우 -->
        <div class="finger-control">
            <div class="item01">
                <strong>회전</strong>
                <p>한 손가락 터치로 회전</p>
            </div>
            <div class="item02">
                <strong>확대/축소</strong>
                <p>두 손가락 터치로 확대/축소</p>
            </div>
            <div class="item03">
                <strong>이동</strong>
                <p>세 손가락 터치로 이동</p>
            </div>
        </div>
        <!-- 터치기반 아닌 경우 -->
        <div class="mouse-control">
            <div class="item01">
                <strong>회전</strong>
                <p>마우스 좌측 버튼 클릭 & 드래그로 회전</p>
            </div>
            <div class="item02">
                <strong>확대/축소</strong>
                <p>마우스 휠로 스크롤</p>
            </div>
            <div class="item03">
                <strong>이동</strong>
                <p>마우스 휠 클릭 & 드래그로 이동</p>
            </div>
            <div class="item04">
                <strong>SITE 퀵 메뉴</strong>
                <p>마우스 오른쪽 클릭</p>
            </div>
            <div class="item05">
                <strong>숨긴 설비 보기</strong>
                <p>키보드 Ctrl + Z 키로 제어</p>
            </div>
            <div class="item06">
                <strong>설비 다시 숨기기</strong>
                <p>키보드 Ctrl + Shift + Z 키로 제어</p>
            </div>
        </div>
    </div>
    <%--
        <div class="popup-footer">
            이 창은 5초후 자동으로 사라집니다. 이 팝업을 다시 보려면 하단의 <span class="icon-help">헬프</span> 버튼을 클릭해 주세요.
        </div>--%>
</div>

<%--
* 앱에서 사용하는 서비스 바로가기 화면 뷰
--%>
<%--<c:if test="${device ne 'pc'}">
    <c:set var="accessUserId" value="16161357"/>
    <div class="app-frame" id="_DASHBOARD">
            &lt;%&ndash; VIEW DASHBOARD &ndash;%&gt;
    </div>

    <script>
        function fnloadDashboard() {
            $.ajax({
                url: "/dashboard/appMain.do"
                , type: "POST"
                , dataType: "html"
                , beforeSend: function () {
                    $("#loadingBar").show();
                }
                , success: function (data) {
                    $("#_DASHBOARD").html(data);
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").hide();
                }
            });
        }

        $(function () {
            fnloadDashboard();
        });
    </script>
</c:if>--%>
<%-- 앱에서 사용하는 서비스 바로가기 화면 끝 --%>

<%--<!-- CCTV 뷰 이미지 대체 영역 -->--%>
<div class="modal fade detail-box" tabindex="-1" id="cctvImg" hidden>
    <div class="modal-dialog modal-dialog-centered modal-xl">
        <div class="modal-content">
            <div class="modal-header visually-hidden">
                <h5 class="title04">CCTV</h5>
                <button type="button" class="btn close">
                    <span class="icon icon-close"></span><span>닫기</span>
                </button>
            </div>

            <div class="modal-body p-0">
                <div class="cctv-mockup">
                    <div class="cm-header">
                        <div class="cctv-close close"></div>
                    </div>
                    <div class="cm-body">
                        <img src="${pageContext.request.contextPath}/resources/user/images/sample/cctv-img.png" alt="CCTV" class="img-fluid"/>
                    </div>
                    <div class="cm-footer"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<%--<!-- 공지팝업 -->--%>
<%--<c:if test="${not empty noticeList}">
    <div class="noticePopup popup-layer" id="_NOTI_POPUP_DIV_" style="display: none;">
            &lt;%&ndash; VIEW POPUP PAGE &ndash;%&gt;
        <c:import url="/notice/noticePopup.do"/>
    </div>
</c:if>--%>

<%--<!-- toast-popup -->--%>
<div aria-live="polite" aria-atomic="true">
    <div class="toast-container" id="_EARLY_WARNING_ALARM_POPUP">
        <%--
            class="toast show bg-danger-subtle"
            사용가능한 클래스: bg-attention-subtle, bg-danger-subtle, bg-info-subtle, bg-warning-subtle, bg-success-subtle
        --%>
        <%--<div class="toast bg-danger-subtle" role="alert" aria-live="assertive" aria-atomic="true">
            <div class="toast-header">
                <!-- <strong class="badge bg-danger">9호기</strong> -->
                <strong class="me-auto">조기 경보</strong>
                <small class="time">발생시각: 2025-12-08 00:00:00</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="닫기"></button>
            </div>
            <div class="toast-body">
                순환펌프 유량이 기준치의 60% 이하로 떨어졌습니다. 냉각계통 점검이 필요합니다.
            </div>
        </div>--%>
    </div>
    <%-- TOAST POPUP --%>
</div>
<%--<!-- toast-popup end -->--%>

<%-- 조기경보 내역 알람 --%>
<%--
toast toast-alert show : 알람이 보여야 할때 show 사용
사용가능한 클래스: bg-attention-subtle, bg-danger-subtle, bg-info-subtle, bg-warning-subtle, bg-success-subtle
data-bs-autohide="false" : 사라지지 않는 속성
data-bs-dismiss="toast" : 클릭시 해당토스트 사라짐
--%>
<div class="toast toast-alert bg-attention-subtle _TOAST_EARLYWARNING_ALARM" role="alert" aria-live="assertive" aria-atomic="true" data-bs-autohide="false">
    <div class="d-flex">
        <div class="toast-body" data-bs-dismiss="toast" onclick="fnOpenPopup('/earlywarning/alarmHistory.do', $(this))" data-title="조기경보" aria-label="조기경보 이력화면으로 이동">
            <span class="icon-popup"></span>
            <span class="text-message">조기경보 알림이 <strong id="_ALARM_COUNT">0</strong>건 있습니다.</span>
        </div>
        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="toast" aria-label="Close"></button>
    </div>
</div>

<%-- cookie js --%>
<script src="${pageContext.request.contextPath}/resources/user/js/cookie/cookie.min.js"></script>

<script>
    $(function () {
        var target;

        if (isMobile) {
            /* work icon list */
            target = $('<input type="hidden" id="_openDashboardPopup" data-title="서비스 바로가기"/>');
            fnOpenPopup('/dashboard/appMain.do', target);
        } else {
            /* Dashboard View Open */
            //target = $('<input type="hidden" id="_openDashboardPopup" data-title="대시보드"/>');
            //fnOpenPopup('/dashboard/index.do', target);

            /* 통합 검색 팝업 창 */
            target = $('<input type="hidden" id="_openSearchPop" data-title="통합검색"/>');
            //fnOpenPopupGlobalSearch("/search/index.do", target);
        }

        /* 공지사항 팝업 */
        <c:if test="${not empty noticeList}">
        if (Cookies.get('notice_view_today') !== 'Y') {
            $("#_NOTI_POPUP_DIV_").addClass('open');
        }
        </c:if>

        /* 조기경보 알람 */
        var socket;
        var reconnectTimer;
        var reconnectDelay = 5000;
        var maxReconnectDelay = 60000;
        var websocketStarted = false;

        function fnShowAlarmToast(message) {
            $.ajax({
                type: "POST",
                url: "/earlywarning/alarmPopup.do",
                data: {message: message},
                dataType: "html",
                success: function (data) {
                    $("#_EARLY_WARNING_ALARM_POPUP").append(data);
                }
            });
        }

        function connectWebSocket() {
            if (socket && (socket.readyState === WebSocket.OPEN || socket.readyState === WebSocket.CONNECTING)) {
                return;
            }

            var wsProtocol = window.location.protocol === "https:" ? "wss://" : "ws://";
            var contextPath = "${pageContext.request.contextPath}";
            socket = new WebSocket(wsProtocol + window.location.host + contextPath + "/alarm-websocket");

            socket.onopen = function () {
                reconnectDelay = 5000;
                //console.log("### [WS] WebSocket Connected");
            };

            socket.onmessage = function (event) {
                var alarmData = event.data;
                fnShowAlarmToast(alarmData);
            };

            socket.onclose = function () {
                socket = null;
                //console.log("### [WS] WebSocket Disconnected. Retrying in 5s...");
                clearTimeout(reconnectTimer);
                reconnectTimer = setTimeout(function () {
                    connectWebSocket();
                }, reconnectDelay);
                reconnectDelay = Math.min(reconnectDelay * 2, maxReconnectDelay);
            };

            socket.onerror = function (err) {
                console.error("### [WS] WebSocket Error:", err);
                if (socket) {
                    socket.close();
                }
            };
        }

        function startWebSocket() {
            if (websocketStarted || !("WebSocket" in window)) {
                return;
            }
            websocketStarted = true;
            connectWebSocket();
        }

        window.addEventListener("load", function () {
            if ("requestIdleCallback" in window) {
                requestIdleCallback(startWebSocket, {timeout: 3000});
            } else {
                setTimeout(startWebSocket, 1000);
            }
        });

        window.addEventListener("beforeunload", function () {
            clearTimeout(reconnectTimer);
            if (socket) {
                socket.onclose = null;
                socket.close();
            }
        });
        /* 조기경보 알람 끝 */

        /*
        // 30초마다 메모리 상태 체크
        */
        function fnCheckMemory() {
            setInterval(function () {
                if (performance.memory) {
                    var used = performance.memory.usedJSHeapSize / 1024 / 1024;
                    if (used > 1500) { // 1.5GB 초과 시
                        //console.log("##### 현재 사용 중인 메모리: " + used.toFixed(2) + " MB");

                        $('.wb-title').each(function () {
                            if ("설비상세정보".includes($(this).text())) {
                                // 첫번째의 멀티뷰 화면을 자동 닫음 처리
                                $(this).closest('.wb-header').find('.wb-close').trigger('click');
                                return false;
                            }
                        });
                    }
                }
            }, 30 * 1000);
        }

        fnCheckMemory();

        /* ALARM COUNT CHECK TIME : 1hour */
        function fnEarlywarningAlarmCount() {
            $.ajax({
                url: "/earlywarning/alarmCount.do",
                type: "POST",
                dataType: "json",
                success: function (data) {
                    if (data.result > 0) {
                        $("#_ALARM_COUNT").text(data.count);
                        //$("._TOAST_EARLYWARNING_ALARM").removeClass("d-none");
                    } else {
                        //$("._TOAST_EARLYWARNING_ALARM").addClass("d-none");
                    }
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    var count = $("#_ALARM_COUNT").text();

                    if (count === "" || count === "0") {
                        //$("._TOAST_EARLYWARNING_ALARM").addClass("d-none");
                    } else {
                        //$("._TOAST_EARLYWARNING_ALARM").removeClass("d-none");
                    }
                }
            });
        }

        setInterval(function () {
            fnEarlywarningAlarmCount();
        }, 60 * 60 * 1000);

        fnEarlywarningAlarmCount();

        <%-- 앱에서 실행 : 3d model preloading
        /*if (checkDevice !== "pc") {
            window.Android.preloadShowUnityActivity(eqOrgNo, hoki);
        }*/ --%>

        window.addEventListener("focus", function () {
            setRenderActive("true");
        });

        window.addEventListener("click", function () {
            setRenderActive("true");
        });

        document.addEventListener("visibilitychange", function () {
            if (document.hidden) {
                setRenderActive("false");
            } else {
                setRenderActive("true");
            }
        });
    });
</script>


</body>
<c:import url="/footer.do"/>
