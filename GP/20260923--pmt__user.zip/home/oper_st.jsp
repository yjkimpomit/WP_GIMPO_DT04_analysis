<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!-- 운전정보-ST -->
<%--<div id="_OPERATION_TBBD9_3F_" class="op-box" style="display: none;">--%>
<div class="op-box-header">
    <h3>TBBD9_3F 운전정보</h3>
    <div class="buttons">
        <button type="button" class="btn minimize" title="축소" onclick="fnOpDataBoxToggle('#_OPERATION_TBBD9_3F_');"></button>
    </div>
</div>
<div class="op-box-body">

    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="운전정보-TBBD9-3F">
            <colgroup>
                <col style="width: 8rem;">
                <col style="width: 4rem;">
                <col>
            </colgroup>
            <thead>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">구분</th>
                <th scope="col" data-field="호기">3F</th>
            </tr>
            </thead>
            <!-- ST -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opSTacc1">
                    3F
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opSTacc1" data-bs-parent="#opSTacc1">
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">출력</th>
                <td data-field="호기" id="_ST_DATA_1">${stList.data_1}</td>
            </tr>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">속도</th>
                <td data-field="호기" id="_ST_DATA_2">${stList.data_2}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">Rotor Position</th>
                <th scope="row" data-field="구분">#A</th>
                <td data-field="호기" id="_ST_DATA_3">${stList.data_3}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">#B</th>
                <td data-field="호기" id="_ST_DATA_4">${stList.data_4}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">#C</th>
                <td data-field="호기" id="_ST_DATA_5">${stList.data_5}</td>
            </tr>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">HP Casing Expansion</th>
                <td data-field="호기" id="_ST_DATA_6">${stList.data_6}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">Diff Expansion</th>
                <th scope="row" data-field="구분">HIP</th>
                <td data-field="호기" id="_ST_DATA_7">${stList.data_7}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">LP</th>
                <td data-field="호기" id="_ST_DATA_8">${stList.data_8}</td>
            </tr>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">HP Inlet Metal Temp</th>
                <td data-field="호기" id="_ST_DATA_9">${stList.data_9}</td>
            </tr>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">Eccentricity</th>
                <td data-field="호기" id="_ST_DATA_10">${stList.data_10}</td>
            </tr>
            </tbody>
            <!-- Steam Temp Condition -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opSTacc2">
                    Steam Temp Condition
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opSTacc2" data-bs-parent="#opSTacc2">
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">HP Inlet Steam</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_11">${stList.data_11}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="호기" id="_ST_DATA_12">${stList.data_12}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">IP Inlet Steam</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_13">${stList.data_13}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="호기" id="_ST_DATA_14">${stList.data_14}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">LP Inlet Steam</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_15">${stList.data_15}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="호기" id="_ST_DATA_16">${stList.data_16}</td>
            </tr>
            </tbody>
            <!-- Lube Oil Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opSTacc3">
                    Lube Oil Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opSTacc3" data-bs-parent="#opSTacc3">
            <tr>
                <th scope="row" data-field="구분">Lube Oil</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_17">${stList.data_17}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">BRG Oil</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_18">${stList.data_18}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">Tank</th>
                <th scope="row" data-field="구분">유위</th>
                <td data-field="호기" id="_ST_DATA_19">${stList.data_19}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="호기" id="_ST_DATA_20">${stList.data_20}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">진공도</th>
                <td data-field="호기" id="_ST_DATA_21">${stList.data_21}</td>
            </tr>
            </tbody>
            <!-- EH Oil Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opSTacc4">
                    EH Oil Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opSTacc4" data-bs-parent="#opSTacc4">
            <tr>
                <th scope="row" data-field="구분">EH Oil</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_22">${stList.data_22}</td>
            </tr>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">Emergency Trip Oil Pr</th>
                <td data-field="호기" id="_ST_DATA_23">${stList.data_23}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">Tank</th>
                <th scope="row" data-field="구분">유위</th>
                <td data-field="호기" id="_ST_DATA_24">${stList.data_24}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="호기" id="_ST_DATA_25">${stList.data_25}</td>
            </tr>
            </tbody>
            <!-- Seal Oil Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opSTacc5">
                    Seal Oil Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opSTacc5" data-bs-parent="#opSTacc5">
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">차압</th>
                <td data-field="호기" id="_ST_DATA_26">${stList.data_26}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">수소</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="호기" id="_ST_DATA_27">${stList.data_27}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">순도</th>
                <td data-field="호기" id="_ST_DATA_28">${stList.data_28}</td>
            </tr>
            </tbody>
        </table>
    </div>
</div>
<%--</div>--%>
<!-- 운전정보-ST end -->
