<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!-- 운전정보-HRSG -->
<%--<div id="_OPERATION_HRSG_" class="op-box" style="display: none;">--%>
<div class="op-box-header">
    <h3>HRSG 운전정보</h3>
    <div class="buttons">
        <%--<button type="button" class="btn maximize" title="확장" onclick="maxi_opDataBox('#_OPERATION_HRSG_');" style="display: none;"></button>--%>
        <button type="button" class="btn minimize" title="축소" onclick="fnOpDataBoxToggle('#_OPERATION_HRSG_');"></button>
    </div>
</div>
<div class="op-box-body">

    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="운전정보-HRSG">
            <colgroup>
                <col style="width: 8rem;">
                <col style="width: 4rem;">
                <col style="width: 4rem;">
                <col>
            </colgroup>
            <thead>
            <tr>
                <th scope="colgroup" colspan="2" data-field="구분">구분</th>
                <th scope="col" data-field="1호기">1호기</th>
                <th scope="col" data-field="2호기">2호기</th>
            </tr>
            </thead>
            <!-- HRSG -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="4" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opHRSGacc1">
                    HRSG
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opHRSGacc1" data-bs-parent="#opHRSGacc1">
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">FWT</th>
                <th scope="row" data-field="구분">수위</th>
                <td data-field="공용설비" colspan="2" id="_HRSG_DATA_1">${hrsgList.data_1}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="공용설비" colspan="2" id="_HRSG_DATA_2">${hrsgList.data_2}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="공용설비" colspan="2" id="_HRSG_DATA_3">${hrsgList.data_3}</td>
            </tr>
            </tbody>
            <!-- HP Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="4" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opHRSGacc2">
                    HP Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opHRSGacc2" data-bs-parent="#opHRSGacc2">
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">ECO</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_4">${hrsgList.data_4}</td>
                <td data-field="2호기" id="_HRSG_DATA_5">${hrsgList.data_5}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_6">${hrsgList.data_6}</td>
                <td data-field="2호기" id="_HRSG_DATA_7">${hrsgList.data_7}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_8">${hrsgList.data_8}</td>
                <td data-field="2호기" id="_HRSG_DATA_9">${hrsgList.data_9}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">TCA</th>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_10">${hrsgList.data_10}</td>
                <td data-field="2호기" id="_HRSG_DATA_11">${hrsgList.data_11}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">LCV<br>Position</th>
                <th scope="row" data-field="구분">HP(L)</th>
                <td data-field="1호기" id="_HRSG_DATA_12">${hrsgList.data_12}</td>
                <td data-field="2호기" id="_HRSG_DATA_13">${hrsgList.data_13}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">HP(s)</th>
                <td data-field="1호기" id="_HRSG_DATA_14">${hrsgList.data_14}</td>
                <td data-field="2호기" id="_HRSG_DATA_15">${hrsgList.data_15}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">Drum</th>
                <th scope="row" data-field="구분">수위</th>
                <td data-field="1호기" id="_HRSG_DATA_16">${hrsgList.data_16}</td>
                <td data-field="2호기" id="_HRSG_DATA_17">${hrsgList.data_17}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_18">${hrsgList.data_18}</td>
                <td data-field="2호기" id="_HRSG_DATA_19">${hrsgList.data_19}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도(물)</th>
                <td data-field="1호기" id="_HRSG_DATA_20">${hrsgList.data_20}</td>
                <td data-field="2호기" id="_HRSG_DATA_21">${hrsgList.data_21}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">SH</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_22">${hrsgList.data_22}</td>
                <td data-field="2호기" id="_HRSG_DATA_23">${hrsgList.data_23}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_24">${hrsgList.data_24}</td>
                <td data-field="2호기" id="_HRSG_DATA_25">${hrsgList.data_25}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_26">${hrsgList.data_26}</td>
                <td data-field="2호기" id="_HRSG_DATA_27">${hrsgList.data_27}</td>
            </tr>
            </tbody>
            <!-- IP Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="4" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opHRSGacc3">
                    IP Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opHRSGacc3" data-bs-parent="#opHRSGacc3">
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">ECO</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_28">${hrsgList.data_28}</td>
                <td data-field="2호기" id="_HRSG_DATA_29">${hrsgList.data_29}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_30">${hrsgList.data_30}</td>
                <td data-field="2호기" id="_HRSG_DATA_31">${hrsgList.data_31}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_32">${hrsgList.data_32}</td>
                <td data-field="2호기" id="_HRSG_DATA_33">${hrsgList.data_33}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">FGH</th>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_34">${hrsgList.data_34}</td>
                <td data-field="2호기" id="_HRSG_DATA_35">${hrsgList.data_35}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_36">${hrsgList.data_36}</td>
                <td data-field="2호기" id="_HRSG_DATA_37">${hrsgList.data_37}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">LCV</th>
                <th scope="row" data-field="구분">Position</th>
                <td data-field="1호기" id="_HRSG_DATA_38">${hrsgList.data_38}</td>
                <td data-field="2호기" id="_HRSG_DATA_39">${hrsgList.data_39}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">Drum</th>
                <th scope="row" data-field="구분">수위</th>
                <td data-field="1호기" id="_HRSG_DATA_40">${hrsgList.data_40}</td>
                <td data-field="2호기" id="_HRSG_DATA_41">${hrsgList.data_41}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_42">${hrsgList.data_42}</td>
                <td data-field="2호기" id="_HRSG_DATA_43">${hrsgList.data_43}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도(물)</th>
                <td data-field="1호기" id="_HRSG_DATA_44">${hrsgList.data_44}</td>
                <td data-field="2호기" id="_HRSG_DATA_45">${hrsgList.data_45}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">IP SH</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_46">${hrsgList.data_46}</td>
                <td data-field="2호기" id="_HRSG_DATA_47">${hrsgList.data_47}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_48">${hrsgList.data_48}</td>
                <td data-field="2호기" id="_HRSG_DATA_49">${hrsgList.data_49}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_50">${hrsgList.data_50}</td>
                <td data-field="2호기" id="_HRSG_DATA_51">${hrsgList.data_51}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="2" data-field="구분">HRH</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_52">${hrsgList.data_52}</td>
                <td data-field="2호기" id="_HRSG_DATA_53">${hrsgList.data_53}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_54">${hrsgList.data_54}</td>
                <td data-field="2호기" id="_HRSG_DATA_55">${hrsgList.data_55}</td>
            </tr>
            </tbody>
            <!-- LP Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="4" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opHRSGacc4">
                    LP Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opHRSGacc4" data-bs-parent="#opHRSGacc4">
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">ECO</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_56">${hrsgList.data_56}</td>
                <td data-field="2호기" id="_HRSG_DATA_57">${hrsgList.data_57}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_58">${hrsgList.data_58}</td>
                <td data-field="2호기" id="_HRSG_DATA_59">${hrsgList.data_59}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_60">${hrsgList.data_60}</td>
                <td data-field="2호기" id="_HRSG_DATA_61">${hrsgList.data_61}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">LCV</th>
                <th scope="row" data-field="구분">Position</th>
                <td data-field="1호기" id="_HRSG_DATA_62">${hrsgList.data_62}</td>
                <td data-field="2호기" id="_HRSG_DATA_63">${hrsgList.data_63}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">Drum</th>
                <th scope="row" data-field="구분">수위</th>
                <td data-field="1호기" id="_HRSG_DATA_64">${hrsgList.data_64}</td>
                <td data-field="2호기" id="_HRSG_DATA_65">${hrsgList.data_65}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_66">${hrsgList.data_66}</td>
                <td data-field="2호기" id="_HRSG_DATA_67">${hrsgList.data_67}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도(물)</th>
                <td data-field="1호기" id="_HRSG_DATA_68">${hrsgList.data_68}</td>
                <td data-field="2호기" id="_HRSG_DATA_69">${hrsgList.data_69}</td>
            </tr>
            <tr>
                <th scope="rowgroup" rowspan="3" data-field="구분">SH</th>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_HRSG_DATA_70">${hrsgList.data_70}</td>
                <td data-field="2호기" id="_HRSG_DATA_71">${hrsgList.data_71}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_HRSG_DATA_72">${hrsgList.data_72}</td>
                <td data-field="2호기" id="_HRSG_DATA_73">${hrsgList.data_73}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">유량</th>
                <td data-field="1호기" id="_HRSG_DATA_74">${hrsgList.data_74}</td>
                <td data-field="2호기" id="_HRSG_DATA_75">${hrsgList.data_75}</td>
            </tr>
            </tbody>
        </table>
    </div>

</div>
<%--</div>--%>
<!-- 운전정보-HRSG end -->
