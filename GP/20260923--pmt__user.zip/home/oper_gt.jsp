<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!-- 운전정보-GT -->
<%--<div id="_OPERATION_GT_" class="op-box">--%>
<div class="op-box-header">
    <h3>GT 운전정보</h3>
    <div class="buttons">
        <%--<button type="button" class="btn maximize" title="확장" onclick="maxi_opDataBox('#_OPERATION_GT_');" style="display: none;"></button>--%>
        <button type="button" class="btn minimize" title="축소" onclick="fnOpDataBoxToggle('#_OPERATION_GT_');"></button>
    </div>
</div>
<div class="op-box-body">

    <div class="table-responsive">
        <table class="data-table data-table--list data-table--interactive" aria-label="운전정보-GT">
            <colgroup>
                <col style="width: 8rem;">
                <col style="width: 4rem;">
                <col>
            </colgroup>
            <thead>
            <tr>
                <th scope="col" data-field="구분">구분</th>
                <th scope="col" data-field="1호기">1호기</th>
                <th scope="col" data-field="2호기">2호기</th>
            </tr>
            </thead>
            <!-- GT -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc1">
                    GT
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc1" data-bs-parent="#opGTacc1">
            <tr>
                <th scope="row" data-field="구분">출력</th>
                <td data-field="1호기" id="_GT_DATA_1">${gtList.data_1}</td>
                <td data-field="2호기" id="_GT_DATA_2">${gtList.data_2}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">속도</th>
                <td data-field="1호기" id="_GT_DATA_3">${gtList.data_3}</td>
                <td data-field="2호기" id="_GT_DATA_4">${gtList.data_4}</td>
            </tr>
            </tbody>
            <!-- 압축기 -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc2">
                    압축기
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc2" data-bs-parent="#opGTacc2">
            <tr>
                <th scope="row" data-field="구분">필터차압</th>
                <td data-field="1호기" id="_GT_DATA_5">${gtList.data_5}</td>
                <td data-field="2호기" id="_GT_DATA_6">${gtList.data_6}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">입구온도</th>
                <td data-field="1호기" id="_GT_DATA_7">${gtList.data_7}</td>
                <td data-field="2호기" id="_GT_DATA_8">${gtList.data_8}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">출구온도</th>
                <td data-field="1호기" id="_GT_DATA_9">${gtList.data_9}</td>
                <td data-field="2호기" id="_GT_DATA_10">${gtList.data_10}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">출구압력</th>
                <td data-field="1호기" id="_GT_DATA_11">${gtList.data_11}</td>
                <td data-field="2호기" id="_GT_DATA_12">${gtList.data_12}</td>
            </tr>
            </tbody>
            <!-- 연소기 점화 시간 -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc3">
                    연소기 점화 시간
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc3" data-bs-parent="#opGTacc3">
            <tr>
                <th scope="row" data-field="구분">#1(A)</th>
                <td data-field="1호기" id="_GT_DATA_13">${gtList.data_13}</td>
                <td data-field="2호기" id="_GT_DATA_14">${gtList.data_14}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">#1(B)</th>
                <td data-field="1호기" id="_GT_DATA_15">${gtList.data_15}</td>
                <td data-field="2호기" id="_GT_DATA_16">${gtList.data_16}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">#16(A)</th>
                <td data-field="1호기" id="_GT_DATA_17">${gtList.data_17}</td>
                <td data-field="2호기" id="_GT_DATA_18">${gtList.data_18}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">#16(B)</th>
                <td data-field="1호기" id="_GT_DATA_19">${gtList.data_19}</td>
                <td data-field="2호기" id="_GT_DATA_20">${gtList.data_20}</td>
            </tr>
            </tbody>
            <!-- BPT -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc4">
                    BPT
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc4" data-bs-parent="#opGTacc4">
            <tr>
                <th scope="row" data-field="구분">평균</th>
                <td data-field="1호기" id="_GT_DATA_21">${gtList.data_21}</td>
                <td data-field="2호기" id="_GT_DATA_22">${gtList.data_22}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">최대</th>
                <td data-field="1호기" id="_GT_DATA_23">${gtList.data_23}</td>
                <td data-field="2호기" id="_GT_DATA_24">${gtList.data_24}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">최소</th>
                <td data-field="1호기" id="_GT_DATA_25">${gtList.data_25}</td>
                <td data-field="2호기" id="_GT_DATA_26">${gtList.data_26}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">최대편차</th>
                <td data-field="1호기" id="_GT_DATA_27">${gtList.data_27}</td>
                <td data-field="2호기" id="_GT_DATA_28">${gtList.data_28}</td>
            </tr>
            </tbody>
            <!-- EXH -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc5">
                    EXH
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc5" data-bs-parent="#opGTacc5">
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_GT_DATA_29">${gtList.data_29}</td>
                <td data-field="2호기" id="_GT_DATA_30">${gtList.data_30}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_GT_DATA_31">${gtList.data_31}</td>
                <td data-field="2호기" id="_GT_DATA_32">${gtList.data_32}</td>
            </tr>
            </tbody>
            <!-- Lube Oil Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc6">
                    Lube Oil Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc6" data-bs-parent="#opGTacc6">
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_GT_DATA_33">${gtList.data_33}</td>
                <td data-field="2호기" id="_GT_DATA_34">${gtList.data_34}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_GT_DATA_35">${gtList.data_35}</td>
                <td data-field="2호기" id="_GT_DATA_36">${gtList.data_36}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">진공도</th>
                <td data-field="1호기" id="_GT_DATA_37">${gtList.data_37}</td>
                <td data-field="2호기" id="_GT_DATA_38">${gtList.data_38}</td>
            </tr>
            </tbody>
            <!-- Control Oil Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc7">
                    Control Oil Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc7" data-bs-parent="#opGTacc7">
            <tr>
                <th scope="row" data-field="구분">압력</th>
                <td data-field="1호기" id="_GT_DATA_39">${gtList.data_39}</td>
                <td data-field="2호기" id="_GT_DATA_40">${gtList.data_40}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">온도</th>
                <td data-field="1호기" id="_GT_DATA_41">${gtList.data_41}</td>
                <td data-field="2호기" id="_GT_DATA_42">${gtList.data_42}</td>
            </tr>
            </tbody>
            <!-- Seal Oil Section -->
            <tbody>
            <tr>
                <th scope="colgroup" colspan="3" data-bs-toggle="collapse" aria-expanded="true" data-bs-target="#opGTacc8">
                    Seal Oil Section
                </th>
            </tr>
            </tbody>
            <tbody class="collapse show" id="opGTacc8" data-bs-parent="#opGTacc8">
            <tr>
                <th scope="row" data-field="구분">차압</th>
                <td data-field="1호기" id="_GT_DATA_43">${gtList.data_43}</td>
                <td data-field="2호기" id="_GT_DATA_44">${gtList.data_44}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">수소압력</th>
                <td data-field="1호기" id="_GT_DATA_45">${gtList.data_45}</td>
                <td data-field="2호기" id="_GT_DATA_46">${gtList.data_46}</td>
            </tr>
            <tr>
                <th scope="row" data-field="구분">수소순도</th>
                <td data-field="1호기" id="_GT_DATA_47">${gtList.data_47}</td>
                <td data-field="2호기" id="_GT_DATA_48">${gtList.data_48}</td>
            </tr>
            </tbody>
        </table>
    </div>

</div>
<%--</div>--%>
<!-- 운전정보-GT end -->

