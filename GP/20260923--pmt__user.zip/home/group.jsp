<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>

<!DOCTYPE html>
<html lang="ko">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="theme-color" content="#FFFFFF">
    <title>서부발전 김포열병합 그룹선택</title>

    <meta name="description" content="서부발전 김포열병합 서비스 제공">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- favicon -->
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.ico" sizes="any">
    <link rel="icon" href="${pageContext.request.contextPath}/resources/user/images/favicon.svg" type="image/svg+xml">

    <script src="${pageContext.request.contextPath}/resources/user/js/jquery/jquery-3.6.1.js"></script>

    <!-- WP stylesheet -->
    <link rel="stylesheet" href="${pageContext.request.contextPath}/resources/user/css/select-group.css">

    <script>
        function fnGoIndex(val) {
            /* test */
            /*if(val === '5100') {
                location.href = "http://localhost:9000/index.do";
            }
            else {
                var urlParam = "eqOrgNo=" + val + "&userId=

            ${sessionScope.loginInfo.iui_user_id}";
                location.replace("/extSso.do?" + urlParam);
            }*/

            $("#form #eqOrgNo").val(val);
            $("#form").submit();
        }
    </script>
</head>
<body>
<form name="form" id="form" method="post" action="${pageContext.request.contextPath}/index.do">
    <input type="hidden" name="eqOrgNo" id="eqOrgNo" value="5100">
</form>

<div class="logo">
    <div class="bi">
        <span class="visually-hidden-focusable">서부발전</span>
        <strong class="branch">김포열병합 DT</strong>
    </div>
</div>

<%-- 순서 바꾸기 : 태안 사원이 로그인 했을 경우 --%>
<%--<c:set var="order" value=""/>
<c:if test="${sessionScope.loginInfo.eqOrgNo eq '5000'}">
    <c:set var="order" value="style='order:2'"/>
</c:if>--%>

<section class="map-section">
    <div class="map-stage" id="mapStage">
        <div class="map-area">
            <img class="map-image" src="${pageContext.request.contextPath}/resources/user/images/group/map.png" alt="지도 이미지"/>

            <div class="map-overlay">
                <!-- 샘플 좌표: 실제 지도 기준으로 수정 -->

                <div class="hotspot info-left" style="--x: 28%;--y: 14%;" data-name="김포발전본부">
                    <button type="button" class="pin" onclick="fnGoIndex('5900')" aria-label="김포발전본부 정보 열기"></button>
                    <span class="pin-label">김포발전본부</span>

                    <div class="info-box" role="dialog" aria-label="김포발전본부 정보">
                        <div class="info-box__panel">
                            <div class="info-box__content">

                                <!-- 좌측 이미지 -->
                                <div class="info-box__media">
                                    <img src="${pageContext.request.contextPath}/resources/user/images/group/plant-sample.png" alt="김포발전본부 이미지">
                                </div>

                                <!-- 우측 텍스트 -->
                                <div class="info-box__main">
                                    <div class="info-box__header">
                                        <div class="info-box__title-wrap">
                                            <a href="javascript:" onclick="fnGoIndex('5900')">
                                                <h3 class="info-box__title">김포발전본부 <span class="icon-url" title="김포 iPOS 이동"></span></h3>
                                                <p class="info-box__sub">열병합발전소</p>
                                            </a>
                                        </div>
                                        <button type="button" class="info-box__close" aria-label="정보 닫기"></button>
                                    </div>
                                    <div class="info-box__body">
                                        <div class="info-box__item">
                                            <span class="info-box__label">설비용량</span>
                                            <span class="info-box__value">510<small>MW</small>(GT 357<small>MW</small> /
													ST 161<small>MW</small>), <br>열 281<small>Gcal/h</small></span>
                                        </div>
                                        <!-- <div class="info-box__item">
                                            <span class="info-box__label">발전연료</span>
                                            <span class="info-box__value">LNG</span>
                                        </div> -->
                                        <div class="info-box__item">
                                            <span class="info-box__label">추진단계</span>
                                            <span class="info-box__value">구축대기</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <%-- class="hotspot is-unbuilt" 이면 info-box 안 보이도록 설정되어 있음 --%>
                <div class="hotspot info-right" style="--x: 32%;--y: 18%;" data-name="서인천발전본부">
                    <button type="button" class="pin disabled" aria-label="서인천발전본부 정보 열기"></button>
                    <span class="pin-label">서인천발전본부 - 미구축</span>

                    <div class="info-box" role="dialog" aria-label="서인천발전본부 정보">
                        <div class="info-box__panel">
                            <div class="info-box__content">

                                <!-- 좌측 이미지 -->
                                <div class="info-box__media">
                                    <img src="${pageContext.request.contextPath}/resources/user/images/group/plant-sample.png" alt="서인천발전본부 이미지">
                                </div>

                                <!-- 우측 텍스트 -->
                                <div class="info-box__main">
                                    <div class="info-box__header">
                                        <div class="info-box__title-wrap">
                                            <h3 class="info-box__title">서인천발전본부</h3>
                                            <p class="info-box__sub">‘녹색기업’인증 친환경발전소</p>
                                        </div>
                                        <button type="button" class="info-box__close" aria-label="정보 닫기"></button>
                                    </div>
                                    <div class="info-box__body">
                                        <!-- <div class="info-box__item">
                                            <span class="info-box__label">설비용량<small>(신재생 제외)</small></span>
                                            <span class="info-box__value">1,861.8 (1,800)<small>MW</small></span>
                                        </div>
                                        <div class="info-box__item">
                                            <span class="info-box__label">발전연료</span>
                                            <span class="info-box__value">LNG,연료전지,태양광</span>
                                        </div> -->
                                        <div class="info-box__item">
                                            <span class="info-box__label">추진단계</span>
                                            <span class="info-box__value">미구축</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="hotspot info-left" style="--x: 18.5%;--y: 29%;" data-name="태안발전본부">
                    <button type="button" class="pin" onclick="fnGoIndex('5000')" aria-label="태안발전본부 정보 열기"></button>
                    <span class="pin-label">태안발전본부</span>

                    <div class="info-box" role="dialog" aria-label="태안발전본부 정보">
                        <div class="info-box__panel">
                            <div class="info-box__content">

                                <!-- 좌측 이미지 -->
                                <div class="info-box__media">
                                    <img src="${pageContext.request.contextPath}/resources/user/images/group/plant-ta.png" alt="태안발전본부 이미지">
                                </div>

                                <!-- 우측 텍스트 -->
                                <div class="info-box__main">
                                    <div class="info-box__header">
                                        <div class="info-box__title-wrap">
                                            <a href="javascript:" onclick="fnGoIndex('5000')">
                                                <h3 class="info-box__title">태안발전본부 <small>(9, 10호기)</small> <span class="icon-url" title="태안 iPOS 이동"></span></h3>
                                                <p class="info-box__sub">최첨단 자동제어설비 발전소</p>
                                            </a>
                                        </div>
                                        <button type="button" class="info-box__close" aria-label="정보 닫기"></button>
                                    </div>
                                    <div class="info-box__body">
                                        <div class="info-box__item">
                                            <span class="info-box__label">설비용량</span>
                                            <span class="info-box__value">각 1,050<small>MW</small></span>
                                        </div>
                                        <div class="info-box__item">
                                            <span class="info-box__label">추진단계</span>
                                            <span class="info-box__value">구축완료</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="hotspot info-right" style="--x: 33.5%;--y: 24.5%;" data-name="평택발전본부">
                    <button type="button" class="pin" aria-label="평택발전본부 정보 열기" onclick="fnGoIndex('5100')"></button>
                    <span class="pin-label">평택발전본부</span>

                    <div class="info-box" role="dialog" aria-label="평택발전본부 정보">
                        <div class="info-box__panel">
                            <div class="info-box__content">

                                <!-- 좌측 이미지 -->
                                <div class="info-box__media">
                                    <img src="${pageContext.request.contextPath}/resources/user/images/group/plant-pt.png" alt="평택발전본부 이미지">
                                </div>

                                <!-- 우측 텍스트 -->
                                <div class="info-box__main">
                                    <div class="info-box__header">
                                        <div class="info-box__title-wrap">
                                            <a href="javascript:" onclick="fnGoIndex('5100')">
                                                <h3 class="info-box__title">평택발전본부 <small>복합 #2</small> <span
                                                        class="icon-url" title="평택 iPOS 이동"></span></h3>
                                                <p class="info-box__sub">천연가스 발전소</p>
                                            </a>
                                        </div>
                                        <button type="button" class="info-box__close" aria-label="정보 닫기"></button>
                                    </div>
                                    <div class="info-box__body">
                                        <div class="info-box__item">
                                            <span class="info-box__label">설비용량</span>
                                            <span class="info-box__value">868.5<small>MW</small></span>
                                        </div>
                                        <div class="info-box__item">
                                            <span class="info-box__label">추진단계</span>
                                            <span class="info-box__value">구축완료</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <%-- class="hotspot is-unbuilt" 이면 info-box 안 보이도록 설정되어 있음 --%>
                <div class="hotspot info-left" style="--x: 30%;--y: 42%;" data-name="군산발전본부">
                    <button type="button" class="pin disabled" aria-label="군산발전본부 정보 열기"></button>
                    <span class="pin-label">군산발전본부 - 미구축</span>
                    <%-- is-unbuilt  --%>
                    <div class="info-box" role="dialog" aria-label="군산발전본부 정보">
                        <div class="info-box__panel">
                            <div class="info-box__content">

                                <!-- 좌측 이미지 -->
                                <div class="info-box__media">
                                    <img src="${pageContext.request.contextPath}/resources/user/images/group/plant-sample.png" alt="군산발전본부 이미지">
                                </div>

                                <!-- 우측 텍스트 -->
                                <div class="info-box__main">
                                    <div class="info-box__header">
                                        <div class="info-box__title-wrap">
                                            <h3 class="info-box__title">군산발전본부</h3>
                                            <p class="info-box__sub">최신형 발전설비를 갖춘 친환경 복합발전소</p>
                                        </div>
                                        <button type="button" class="info-box__close" aria-label="정보 닫기"></button>
                                    </div>
                                    <div class="info-box__body">
                                        <!-- <div class="info-box__item">
                                            <span class="info-box__label">설비용량<small>(신재생 제외)</small></span>
                                            <span class="info-box__value">718.4<small>MW</small></span>
                                        </div>
                                        <div class="info-box__item">
                                            <span class="info-box__label">발전연료</span>
                                            <span class="info-box__value">LNG,태양광</span>
                                        </div> -->
                                        <div class="info-box__item">
                                            <span class="info-box__label">추진단계</span>
                                            <span class="info-box__value">미구축</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <%-- class="hotspot is-unbuilt" 이면 info-box 안 보이도록 설정되어 있음 --%>
                <%--<div class="hotspot info-right" style="--x: 36%;--y: 36%;" data-name="공주발전본부">
                    <button type="button" class="pin disabled" aria-label="공주발전본부 정보 열기"></button>
                    <span class="pin-label">공주발전본부 - 건설중</span>
                    &lt;%&ndash; is-unbuilt  &ndash;%&gt;
                    <div class="info-box" role="dialog" aria-label="공주발전본부 정보">
                        <div class="info-box__panel">
                            <div class="info-box__content">
                                
                                <!-- 좌측 이미지 -->
                                <div class="info-box__media">
                                    <img src="${pageContext.request.contextPath}/resources/user/images/group/plant-sample.png" alt="공주발전본부 이미지">
                                </div>
                                
                                <!-- 우측 텍스트 -->
                                <div class="info-box__main">
                                    <div class="info-box__header">
                                        <div class="info-box__title-wrap">
                                            <h3 class="info-box__title">공주발전본부</h3>
                                            <p class="info-box__sub">중부지역의 최적 공급여건 조성으로 안정적 수익창출 기반 마련을 위한 천연가스발전사업</p>
                                        </div>
                                        <button type="button" class="info-box__close" aria-label="정보 닫기"></button>
                                    </div>
                                    <div class="info-box__body">
                                        <!-- <div class="info-box__item">
                                            <span class="info-box__label">설비용량<small>(신재생 제외)</small></span>
                                            <span class="info-box__value">718.4<small>MW</small></span>
                                        </div>
                                        <div class="info-box__item">
                                            <span class="info-box__label">발전연료</span>
                                            <span class="info-box__value">LNG,태양광</span>
                                        </div> -->
                                        <div class="info-box__item">
                                            <span class="info-box__label">추진단계</span>
                                            <span class="info-box__value">미구축</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        
                        </div>
                    </div>
                </div>--%>

            </div>
        </div>

        <svg class="line-layer" id="lineLayer" aria-hidden="true"></svg>
        <div class="info-layer" id="infoLayer"></div>
    </div>
</section>

<script src="${pageContext.request.contextPath}/resources/user/js/select-group.js"></script>

<%--<div class="container">
    <div class="header-title">
        <h1>안녕하세요. <br>발전소를 선택해 주세요.</h1>
    </div>
    <div class="select-group">
		<div class="bg01 disabled"&lt;%&ndash; ${order}&ndash;%&gt; style="order: 2;">
			&lt;%&ndash;<a href="javascript:" onclick="fnGoIndex('5100')">&ndash;%&gt;
			<a href="javascript:;">
				<h2 class="btn-plant">평택2복합</h2>
			</a>
		</div>
		<div class="bg02" style="order: 1;">
			<a href="javascript:" onclick="fnGoIndex('5000')">
				<h2 class="btn-plant">태안 9,10호기</h2>
			</a>
		</div>
    </div>
</div>--%>

</body>

</html>