<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<c:import url="/header.do"/>

<body class="sub">
<!-- 로딩박스 -->
<div class="loading-box" id="loadingBar" style="display: none;">
    <div class="loader"></div>
</div>

<!-- top 로드 -->
<div class="header-box">
    <div class="header">
        <div class="inner-box">
            <a href="${pageContext.request.contextPath}/index.do" class="logo">
                <div class="bi">
                    <span class="visually-hidden-focusable">서부발전</span>
                    <strong class="branch">평택2복합 <span class="system">i-POS</span></strong>
                    <span class="desc">지능형 발전 운영시스템</span>
                </div>
            </a>
        </div>
    </div>
</div>

<div class="container">
    <div class="container-log">
        <div class="title-box">
            <h2 class="title02">방문자 조회</h2>
        </div>
        <div class="search-box">
            <form id="formLogVisit">
                <input type="hidden" id="ColList" name="ColList" value=""/>
                <div class="row">
                    <div class="col-md-auto">
                        <strong class="form-label">방문자 집계</strong>
                        <div class="form-control-plaintext pe-5">
                            <strong class="icon-groups">전체 </strong><span>방문자수: </span> <strong><fmt:formatNumber value="${totalCount}" type="number"/>명</strong>
                        </div>
                    </div>
                    <div class="col-md-auto">
                        <div class="form-control-plaintext pe-5">
                            <strong class="icon-month">월별 </strong><span>방문자수(${month}): </span> <strong><fmt:formatNumber value="${monthCount}" type="number"/>명</strong>
                        </div>
                    </div>
                    <div class="col-md-auto">
                        <div class="form-control-plaintext pe-5">
                            <strong class="icon-person">오늘</strong><span>의 방문자수: </span> <strong><fmt:formatNumber value="${todayCount}" type="number"/>명</strong>
                        </div>
                    </div>
                    <fieldset class="col-md-auto col-xl-auto col-xxl-4">
                        <legend class="form-label" id="searchPeriod">검색 기간</legend>
                        <div class="row g-2 period-box">
                            <div class="col">
                                <label class="visually-hidden" for="txtSearchStartDate">시작일</label> <input type="date" class="form-control" name="searchStartDate" id="txtSearchStartDate">
                            </div>
                            <div class="col-auto">
                                <span class="form-control-plaintext text-center">~</span>
                            </div>
                            <div class="col">
                                <label class="visually-hidden" for="txtSearchEndDate">종료일</label> <input type="date" class="form-control" name="searchEndDate" id="txtSearchEndDate">
                            </div>
                        </div>
                    </fieldset>

                    <div class="col col-md-auto">
                        <div class="col">
                            <button type="button" class="btn btn-primary" onclick="fnLoadVisitList()">
                                <span class="icon icon-search"></span>
                                <span>검색</span>
                            </button>
                        </div>
                    </div>
                </div>
            </form>
        </div>

        <div class="title-box" id="divSearchResult">
            <h4 class="title03">
                조회결과<small id="searchResultCnt"></small>
            </h4>
            <div class="buttons">
                <%-- 앱 로그인 체크 --%>
                <c:if test="${sessionScope.loginInfo.iui_isadmin ne '999'}">
                    <button type="button" class="btn btn-primary btn-file-download" onclick="fnVisitExcelDownload()">엑셀 다운로드</button>
                </c:if>
            </div>
        </div>

        <div class="table-responsive" id="_DIV_LOG_VISIT_LIST">
            <%-- 데이터 리스트 --%>
        </div>
    </div>
</div>

<script>
    function fnSetDate() {
        //날짜 현재날짜 기준 한 달 전 세팅
        var today = new Date();
        var yyyy = today.getFullYear();
        var mm = ("0" + (today.getMonth() + 1)).slice(-2); // 월은 0부터 시작하므로 +1
        var dd = ("0" + today.getDate()).slice(-2);
        var currentDate = yyyy + "-" + mm + "-" + dd;
        $('#txtSearchEndDate').val(currentDate); // 첫 번째 input에 오늘 날짜 설정

        // 두 번째 input 태그 (한 달 전 날짜로 설정)
        today.setMonth(today.getMonth() - 1); // 현재 날짜 기준 한 달 전으로 설정
        var lastMonthDate = today.getFullYear() + "-"
            + ("0" + (today.getMonth() + 1)).slice(-2) + "-"
            + ("0" + today.getDate()).slice(-2);
        $('#txtSearchStartDate').val(lastMonthDate); // 두 번째 input에 한 달 전 날짜 설정
    }

    function fnLoadVisitList() {
        var flg = true;
        var setErrMsg = "";

        var startDate = $("#txtSearchStartDate").val();
        var endDate = $("#txtSearchEndDate").val();

        if (startDate !== "") {
            if (endDate !== "") {
                //날짜 비교
                var tmpDate_s = new Date($("#txtSearchStartDate").val());
                var tmpDate_e = new Date($("#txtSearchEndDate").val());

                if (tmpDate_s > tmpDate_e) {
                    flg = false;
                    if (setErrMsg !== "") {
                        setErrMsg += "\n";
                    }
                    setErrMsg += "검색 종료일이 검색 시작일보다 앞의 날짜를 입력할 수 없습니다.";
                }
            } else {
                flg = false;
                if (setErrMsg !== "") {
                    setErrMsg += "\n";
                }
                setErrMsg += "검색 종료일을 지정하여 주십시요.";
            }
        } else {
            flg = false;
            if (setErrMsg !== "") {
                setErrMsg += "\n";
            }
            setErrMsg += "검색 시작일을 지정하여 주십시요.";
        }

        if (flg) {
            $.ajax({
                url: "/log/visitList.do",
                type: "POST",
                data: $("#formLogVisit").serialize(),
                dataType: "html",
                beforeSend: function () {
                    $("#loadingBar").css("display", "");
                },
                success: function (data) {
                    if (data !== "") {
                        $("#_DIV_LOG_VISIT_LIST").html(data);
                    }
                },
                error: function (request, status, error) {
                    console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
                },
                complete: function () {
                    $("#loadingBar").css("display", "none");
                }
            });
        } else {
            alert(setErrMsg);
        }
    }

    $(document).ready(function () {
        fnSetDate();
        fnLoadVisitList();
    });
</script>

</body>
<c:import url="/footer.do"/>
