<%@ page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<%@ taglib prefix="ui" uri="http://egovframework.gov/ctl/ui" %>
<%@ taglib prefix="fn" uri="http://java.sun.com/jsp/jstl/functions" %>
<%@ taglib prefix="form" uri="http://www.springframework.org/tags/form" %>
<%@ taglib prefix="fmt" uri="http://java.sun.com/jsp/jstl/fmt" %>

<table class="data-table data-table--list data-table--interactive" aria-label="방문자정보">
    <thead>
    <tr>
        <th scope="col" name="excelCol" data-field="방문일">방문일</th>
        <th scope="col" name="excelCol" data-field="사번">사번</th>
        <th scope="col" name="excelCol" data-field="이름">이름</th>
        <th scope="col" name="excelCol" data-field="부서명">부서명</th>
    </tr>
    </thead>
    <tbody>
    <c:if test="${empty list}">
        <tr>
            <td colspan="4">
                <div class="no-data">
                    데이터가 없습니다.
                </div>
            </td>
        </tr>
    </c:if>

    <c:forEach items="${list}" var="data" varStatus="status">
        <fmt:parseDate value="${data.ilvDate}" var="date" pattern="yyyyMMdd"/>

        <tr>
            <td data-field="방문일"><fmt:formatDate value="${date}" pattern="yyyy-MM-dd"/></td>
            <td data-field="사번">${data.userId}</td>
            <td data-field="이름">${data.userName}</td>
            <td data-field="부서명">${data.userDeptName}</td>
        </tr>
    </c:forEach>
    </tbody>
</table>

<script>
    $("#searchResultCnt").text("(<fmt:formatNumber value="${listCount}" type="number" />명)");

    // 방문자 엑셀 다운로드
    function fnVisitExcelDownload() {
        var excelColList = [];

        $("th[name='excelCol']").each(function () {
            var fieldValue = $(this).data("field");
            excelColList.push(fieldValue);
        });
        $("#ColList").val(excelColList);

        $.ajax({
            type: "POST",
            url: "/log/visitExcelList.do",
            data: $("#formLogVisit").serialize(),
            xhrFields: {
                responseType: 'blob' // 응답을 Blob 형식으로 받기
            },
            beforeSend: function () {
                $("#loadingBar").css("display", "");
            },
            success: function (response, status, xhr) {
                //현재 날짜 가져오기
                var currentDate = new Date();
                var formattedDate = currentDate.getFullYear() + '-'
                    + (currentDate.getMonth() + 1).toString().padStart(2, '0') + '-'
                    + currentDate.getDate().toString().padStart(2, '0');

                // Blob을 사용하여 파일 다운로드 처리
                var blob = response;
                var link = document.createElement('a');
                link.href = URL.createObjectURL(blob);
                link.download = "방문자정보_" + formattedDate + ".xlsx";
                link.click(); // 다운로드 트리거
            },
            error: function (request, status, error) {
                console.log("code:" + request.status + "\n message:" + request.responseText + "\n error:" + error);
            },
            complete: function () {
                $("#loadingBar").css("display", "none");
            }
        });
    }
</script>
